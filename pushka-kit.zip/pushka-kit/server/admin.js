// Private area for the Rabbi: upcoming yahrzeits (only from people who chose to share),
// members, failed payments, and push broadcasts. Switched off unless ADMIN_PASSWORD is set (12+ characters).
'use strict';
const crypto = require('crypto');
const path = require('path');
const express = require('express');
const H = require('../pushka/hebdate.js');
const { ptParts } = require('./scheduler.js');

const COOKIE = 'cl_admin';
const TTL = 12 * 3600e3;

function mountAdmin(app, { funds = {}, store, stripe, password, secret, limit, send, log = console, levelOf, extend = null }) {
  if (!password || password.length < 12) return false;
  const needDb = (req, res, next) => (store ? next() : res.status(503).json({ code: 'not_configured', error: 'The database is not connected yet (DATABASE_URL).' }));
  const mac = (s) => crypto.createHmac('sha256', secret + ':admin').update(s).digest('base64url');
  const issue = () => { const exp = String(Date.now() + TTL); return exp + '.' + mac(exp); };
  const valid = (tok) => {
    if (typeof tok !== 'string') return false;
    const i = tok.indexOf('.'); if (i < 1) return false;
    const exp = tok.slice(0, i), a = Buffer.from(tok.slice(i + 1)), b = Buffer.from(mac(exp));
    return a.length === b.length && crypto.timingSafeEqual(a, b) && Number(exp) > Date.now();
  };
  const cookieOf = (req) => { const m = new RegExp('(?:^|; )' + COOKIE + '=([^;]+)').exec(req.get('cookie') || ''); return m ? m[1] : ''; };
  const same = (a, b) => { const x = crypto.createHash('sha256').update(String(a)).digest(), y = crypto.createHash('sha256').update(String(b)).digest(); return crypto.timingSafeEqual(x, y); };

  const r = express.Router();
  r.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); res.setHeader('X-Robots-Tag', 'noindex'); next(); });
  r.use('/api', express.json({ limit: '10kb' }));
  const authed = (req, res, next) => {
    if (!valid(cookieOf(req))) return res.status(401).json({ code: 'unauthorized', error: 'Please sign in.' });
    if (req.method !== 'GET' && req.get('x-admin') !== '1') return res.status(403).json({ code: 'forbidden', error: 'Forbidden.' });
    next();
  };
  const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((e) => { log.error('admin error:', e && e.message); res.status(500).json({ code: 'server_error', error: 'Something went wrong.' }); });

  r.post('/api/login', limit('admin-login', 8, 15 * 60 * 1000), (req, res) => {
    if (!same(req.body && req.body.password, password)) return res.status(401).json({ code: 'bad_password', error: 'Wrong password.' });
    res.setHeader('Set-Cookie', `${COOKIE}=${issue()}; Path=/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=${TTL / 1000}`);
    res.json({ ok: true });
  });
  r.post('/api/logout', (req, res) => { res.setHeader('Set-Cookie', `${COOKIE}=; Path=/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=0`); res.json({ ok: true }); });
  r.get('/api/me', authed, (req, res) => res.json({ ok: true }));

  async function upcoming(days, now = new Date()) {
    const today = ptParts(now).ymd;
    const [ys, fu] = await Promise.all([store.sharedYahrzeits(), store.listFollowups()]);
    const fmap = new Map(fu.map((f) => [f.yahrzeit_id + '|' + f.occurrence, f]));
    const out = [];
    for (const y of ys) {
      const occ = H.next({ day: y.h_day, month: y.h_month, year: y.h_year }, today); if (!occ) continue;
      const left = H.daysBetween(today, occ.date); if (left > days) continue;
      const f = fmap.get(y.id + '|' + occ.date);
      out.push({ id: y.id, name: y.name, relation: y.relation, notes: y.notes, hebrew: H.label({ day: y.h_day, month: y.h_month }, false), hebrewHe: H.label({ day: y.h_day, month: y.h_month }, true),
        date: occ.date, daysLeft: left, dateNotes: occ.notes || [], member: { name: y.member_name, email: y.email, phone: y.phone, address: y.address },
        followup: { note: f ? f.note : '', done: !!(f && f.done_at) } });
    }
    return out.sort((a, b) => a.daysLeft - b.daysLeft || a.name.localeCompare(b.name));
  }

  r.get('/api/yahrzeits', authed, needDb, wrap(async (req, res) => {
    const days = Math.min(Math.max(parseInt(req.query.days, 10) || 60, 1), 400);
    res.json({ days, items: await upcoming(days) });
  }));
  r.put('/api/followup', authed, needDb, wrap(async (req, res) => {
    const b = req.body || {};
    if (typeof b.yahrzeitId !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(b.occurrence || '')) return res.status(400).json({ code: 'invalid', error: 'Invalid request.' });
    await store.setFollowup(b.yahrzeitId.slice(0, 80), b.occurrence, String(b.note || '').slice(0, 500), b.done === true);
    res.json({ ok: true });
  }));
  r.get('/api/members', authed, needDb, wrap(async (req, res) => {
    res.json({ members: (await store.listMembers()).map((m) => ({ id: m.id, name: m.name, email: m.email, phone: m.phone, shares: m.share_yahrzeits, yahrzeits: m.share_yahrzeits ? m.yahrzeit_count : null, push: m.push_count, cardIssue: m.card_issue, joined: m.created_at })) });
  }));
  r.get('/api/payments', authed, needDb, wrap(async (req, res) => { res.json({ events: await store.listPaymentEvents() }); }));
  r.post('/api/payments/:id/resolve', authed, needDb, wrap(async (req, res) => { await store.resolvePayment(req.params.id); res.json({ ok: true }); }));

  // CSV: cells beginning with = + - @ are prefixed so a spreadsheet never runs them as formulas.
  const cell = (v) => { let s = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  r.get('/api/export.csv', authed, needDb, wrap(async (req, res) => {
    const items = await upcoming(400);
    const head = ['Name', 'Relation', 'Hebrew date', 'Next date', 'Days left', 'Member', 'Email', 'Phone', 'Address', 'Follow-up note', 'Done'];
    const lines = [head.map(cell).join(',')].concat(items.map((i) => [i.name, i.relation, i.hebrew, i.date, i.daysLeft, i.member.name, i.member.email, i.member.phone, i.member.address, i.followup.note, i.followup.done ? 'yes' : ''].map(cell).join(',')));
    res.type('text/csv').set('Content-Disposition', 'attachment; filename="yahrzeits.csv"').send(lines.join('\r\n') + '\r\n');
  }));

  // Everyone who gives monthly, with their level. Names and contact details: this page is private to the Rabbi.
  let clubCache = { at: 0, data: null };
  r.get('/api/donors', authed, wrap(async (req, res) => {
    if (!stripe) return res.status(503).json({ code: 'not_configured', error: 'Stripe is not connected yet.' });
    if (!clubCache.data || Date.now() - clubCache.at > 60 * 1000) {
      const rows = []; let after;
      for (let page = 0; page < 50; page++) {
        const list = await stripe.subscriptions.list({ status: 'active', limit: 100, ...(after ? { starting_after: after } : {}) });
        for (const sb of list.data) {
          const m = sb.metadata || {}; if (m.source !== 'pushka') continue;
          const item = sb.items && sb.items.data && sb.items.data[0], cents = Number(m.gift_cents) || (item && item.price ? item.price.unit_amount : 0);
          let cust = null; try { cust = await stripe.customers.retrieve(typeof sb.customer === 'string' ? sb.customer : sb.customer.id); } catch (e) {}
          rows.push({ id: sb.id, name: (cust && cust.name) || '', email: (cust && cust.email) || '', phone: (cust && cust.phone) || '', fund: m.fund || '', club: m.club === 'yes', level: m.club === 'yes' ? levelOf(cents) : null, monthly: cents / 100, boardName: m.board_name || '', onBoard: m.board_show === 'yes' && !!levelOf(cents), since: (sb.created || 0) * 1000, next: ((sb.current_period_end || (item && item.current_period_end) || 0) * 1000) || null });
        }
        if (!list.has_more || !list.data.length) break; after = list.data[list.data.length - 1].id;
      }
      const order = ['platinum', 'gold', 'silver', 'bronze'], rank = (l) => (l ? order.indexOf(l) : 9);
      rows.sort((a, b) => rank(a.level) - rank(b.level) || b.monthly - a.monthly || a.since - b.since);
      const byLevel = {}; for (const l of order) { const g = rows.filter((x) => x.level === l); byLevel[l] = { count: g.length, monthly: g.reduce((a, x) => a + x.monthly, 0) }; }
      clubCache = { at: Date.now(), data: { donors: rows, byLevel, total: { count: rows.length, monthly: rows.reduce((a, x) => a + x.monthly, 0) } } };
    }
    res.json(clubCache.data);
  }));

  // Announcements shown on every app home screen: a match day, a cause with a progress bar, or an impact note.
  const FUNDS_OK = new Set(['', ...Object.keys(funds)]);
  r.get('/api/funds', authed, (req, res) => res.json({ funds: Object.entries(funds).map(([id, name]) => ({ id, name })) }));
  r.get('/api/announcements', authed, needDb, wrap(async (req, res) => { res.json({ items: await store.getKv('announcements', []) }); }));
  r.put('/api/announcements', authed, needDb, wrap(async (req, res) => {
    const list = req.body && req.body.items; if (!Array.isArray(list) || list.length > 6) return res.status(400).json({ code: 'invalid', error: 'Up to 6 announcements.' });
    const out = [];
    for (const a of list) {
      const title = String(a && a.title || '').trim().slice(0, 80), body = String(a && a.body || '').trim().slice(0, 300);
      if (!title) return res.status(400).json({ code: 'invalid', error: 'Every announcement needs a title.' });
      const kind = ['match', 'cause', 'impact'].includes(a.kind) ? a.kind : 'impact', goal = Math.max(Number(a.goal) || 0, 0), raised = Math.max(Number(a.raised) || 0, 0), fund = FUNDS_OK.has(a.fund) ? a.fund : '';
      const until = /^\d{4}-\d{2}-\d{2}$/.test(a.until || '') ? a.until : '';
      out.push({ id: String(a.id || Math.random().toString(36).slice(2, 10)).replace(/[^A-Za-z0-9_-]/g, '').slice(0, 20), kind, title, body, goal, raised, fund, until });
    }
    await store.setKv('announcements', out); res.json({ ok: true, items: out });
  }));

  r.post('/api/broadcast', authed, limit('broadcast', 10, 60 * 60 * 1000), wrap(async (req, res) => {
    const b = req.body || {}, title = String(b.title || '').trim(), body = String(b.body || '').trim(), url = String(b.url || '/pushka/');
    if (b.confirm !== true) return res.status(400).json({ code: 'confirm', error: 'Please confirm before sending.' });
    if (!title || title.length > 60 || !body || body.length > 200) return res.status(400).json({ code: 'invalid', error: 'Title up to 60 and message up to 200 characters.' });
    if (!/^\/pushka\/[A-Za-z0-9_\-./?=&]*$/.test(url) || url.includes('..')) return res.status(400).json({ code: 'invalid', error: 'Link must stay inside the app.' });
    if (!send) return res.status(503).json({ code: 'not_configured', error: 'Push notifications are not set up yet (VAPID keys).' });
    const subs = await store.listPushSubs(); let sent = 0;
    for (const s of subs) {
      try { await send(s, { title, body, url, tag: 'broadcast' }); sent++; }
      catch (e) { if (e && (e.statusCode === 404 || e.statusCode === 410)) await store.deletePushSub(s.endpoint); }
    }
    res.json({ ok: true, sent, total: subs.length });
  }));

  if (extend) {
    extend(r, { authed, wrap });
    r.get('/kiddush', (req, res) => res.sendFile(path.join(__dirname, 'admin', 'kiddush.html')));
    r.get('/kiddush.js', (req, res) => res.sendFile(path.join(__dirname, 'admin', 'kiddush.js')));
  }
  r.get(['/', '/index.html'], (req, res) => res.sendFile(path.join(__dirname, 'admin', 'index.html')));
  r.get('/admin.js', (req, res) => res.sendFile(path.join(__dirname, 'admin', 'admin.js')));
  r.get('/admin.css', (req, res) => res.sendFile(path.join(__dirname, 'admin', 'admin.css')));
  r.use((req, res) => res.status(404).json({ code: 'not_found', error: 'Not found.' }));
  app.use('/admin', r);
  return true;
}
module.exports = { mountAdmin };
