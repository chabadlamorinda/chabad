'use strict';
module.exports = { SCHEMA: "ALTER TABLE members ADD COLUMN IF NOT EXISTS personalize BOOLEAN NOT NULL DEFAULT TRUE;" };
