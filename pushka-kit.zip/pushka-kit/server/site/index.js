// (The original organisation's website is not part of the kit.)
'use strict';
function mountSite() { return { mountAdmin() {}, notFound: (req, res, next) => next() }; }
module.exports = { mountSite };
