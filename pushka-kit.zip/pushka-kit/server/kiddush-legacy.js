// (The original organisation's one-time import is not part of the kit.)
'use strict';
async function importLegacy() { return 0; }
module.exports = { importLegacy };
