// Chabad of Sampleton — website + "My Pushka" app + Stripe payment API.
//
// Design: stateless. A donor's browser holds a signed token that names their Stripe
// customer (cus_...). Card details never touch this server: Stripe.js collects them and
// Stripe stores them. This server only creates customers, SetupIntents (to save a card),
// and charges the saved card (one-time PaymentIntents and monthly Subscriptions).
//
// Required environment variables:
//   STRIPE_SECRET_KEY       sk_test_... (testing) or sk_live_... (real money)
//   STRIPE_PUBLISHABLE_KEY  pk_test_... or pk_live_...
//   SESSION_SECRET          long random string (Render generates one)
'use strict';

const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { mountMembers } = require('./members.js');
const { mountAdmin } = require('./admin.js');
const { mountAccounts } = require('./accounts.js');
const { createKiddush } = require('./kiddush.js');
const { createCampaigns } = require('./campaign.js');
const { createFinances } = require('./finances.js');
const { mountSite } = require('./site/index.js');

const ROOT = path.join(__dirname, '..');
// <KIT:FUNDS>
const FUND_NAMES = {
  general: 'General Fund',
  chai: 'Chai Club',
  holidays: 'Holiday Programs',
  pledge: 'Pledge',
};
// </KIT:FUNDS>
// Chai Club (monthly donors). A gift of exactly a boundary amount belongs to the higher level.
const CLUB_LEVELS = [['platinum', 72000], ['gold', 36000], ['silver', 18000], ['bronze', 7200]];
const clubLevel = (cents) => { const l = CLUB_LEVELS.find(([, min]) => cents >= min); return l ? l[0] : null; };
const FEE_RATE = 0.035;      // optional "cover the processing fee" add-on
const MIN_CENTS = 100;       // $1
const MAX_CENTS = 1000000;   // $10,000 per gift

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

/**
 * @param {{ stripe: import('stripe').Stripe | null, publishableKey?: string, sessionSecret: string, log?: Pick<Console, 'error'> }} opts
 */
function createApp({ stripe: maybeStripe, publishableKey, sessionSecret, log = console, androidPackage = 'org.samplechabad.pushka', androidSha256 = '', store = null, sendPush = null, vapidPublicKey = '', webhookSecret = '', adminPassword = '', applePayAssoc = '', now = () => new Date(), mailer = null, reminders = false, siteEnv = process.env, facebook = undefined, chatClient = undefined, siteContentDir = undefined }) {
  const stripe = /** @type {import('stripe').Stripe} */ (maybeStripe);
  const kiddush = createKiddush({ store, stripe, log, now, mailer, notifyTo: () => (siteEnv && siteEnv.ADMIN_EMAIL) || (app.locals.site && app.locals.site.content ? (app.locals.site.content().org || {}).email : '') || '' });
  if (reminders) kiddush.startReminders(); // emails unpaid sponsors a reminder after a few days (needs email set up)
  const app = express();
  app.locals.kiddush = kiddush; // (used by tests)
  app.disable('x-powered-by');
  // Compress pages, styles and scripts (about 4x smaller). The chat's live stream is left alone.
  app.use(require('compression')({ filter: (req, res) => !/text\/event-stream/.test(String(res.getHeader('Content-Type') || '')) && require('compression').filter(req, res) }));
  app.set('trust proxy', 1);

  // ---------- tokens ----------
  const mac = (cus) => crypto.createHmac('sha256', sessionSecret).update(cus).digest('base64url');
  const sign = (cus) => cus + '.' + mac(cus);
  const verify = (tok) => {
    if (typeof tok !== 'string' || tok.length > 200) return null;
    const i = tok.lastIndexOf('.');
    if (i < 1) return null;
    const cus = tok.slice(0, i);
    const a = Buffer.from(tok.slice(i + 1)), b = Buffer.from(mac(cus));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    return /^cus_[A-Za-z0-9]+$/.test(cus) ? cus : null;
  };
  // Member tokens (m_...) are a separate namespace so they can never be mistaken for a Stripe customer token.
  const mmac = (id) => crypto.createHmac('sha256', sessionSecret + ':member').update(id).digest('base64url');
  const tokens = {
    verifyCustomer: verify,
    signCustomer: sign,
    signMember: (id) => id + '.' + mmac(id),
    verifyMember(tok) {
      if (typeof tok !== 'string' || tok.length > 100) return null;
      const i = tok.lastIndexOf('.'); if (i < 1) return null;
      const id = tok.slice(0, i), a = Buffer.from(tok.slice(i + 1)), b = Buffer.from(mmac(id));
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
      return /^m_[0-9a-f]{24}$/.test(id) ? id : null;
    },
  };

  // ---------- security headers ----------
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000'); // browsers always use https from now on
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', [
      "default-src 'self'",
      "script-src 'self' https://js.stripe.com",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https://*.stripe.com",
      "connect-src 'self' https://api.stripe.com https://www.hebcal.com",
      "frame-src https://js.stripe.com https://hooks.stripe.com",
      "worker-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
    ].join('; '));
    next();
  });

  // ---------- tiny in-memory rate limiter ----------
  const hits = new Map();
  const limit = (id, max, windowMs) => (req, res, next) => {
    const key = id + '|' + req.ip;
    const now = Date.now();
    const e = hits.get(key);
    if (!e || now > e.reset) hits.set(key, { n: 1, reset: now + windowMs });
    else if (++e.n > max) return res.status(429).json({ code: 'rate_limited', error: 'Too many requests. Please wait a moment.' });
    next();
  };
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (now > v.reset) hits.delete(k); }, 60000).unref();

  // Render switches visitors to a new version only after /healthz answers "ok". So it does not just say "ok": the first
  // time (and again a minute after any failure) it opens the main pages of this very server, in every language, and only
  // when they all work does it say "ok". A change that breaks the pages therefore never goes live: Render keeps the
  // working version running and the deploy is marked failed. After the first success it answers at once.
  const CHECK = ['/', '/learn', '/learn/shiva', '/learn/series/shabbat', '/events', '/shabbat', '/donate', '/help', '/kaddish', '/he/learn', '/ru/events', '/search?q=shabbat'];
  let healthy = false, checking = null, failedAt = 0, lastProblem = '';
  async function selfCheck(port) {
    if (!app.locals.site || !app.locals.site.content) return true; // the app alone (the shareable kit has no website)
    for (const p of CHECK) {
      const r = await fetch('http://127.0.0.1:' + port + p, { redirect: 'manual', headers: { 'user-agent': 'healthz' }, signal: AbortSignal.timeout(20000) }).catch((e) => ({ status: 0, text: async () => String(e && e.message) }));
      const body = r.status === 200 ? await r.text() : '';
      if (r.status >= 400 || r.status === 0 || (r.status === 200 && !/<\/html>\s*$/i.test(body))) { lastProblem = p + ' answered ' + r.status; return false; }
    }
    return true;
  }
  app.get('/healthz', async (req, res) => {
    if (!healthy && !checking && Date.now() - failedAt > 60000) {
      checking = selfCheck(req.socket.localPort).then((ok) => { healthy = ok; if (!ok) { failedAt = Date.now(); log.error('health check failed: ' + lastProblem); } }).catch((e) => { failedAt = Date.now(); lastProblem = String(e && e.message); }).finally(() => { checking = null; });
    }
    if (checking) await checking;
    res.set('Cache-Control', 'no-store');
    return healthy ? res.type('text').send('ok') : res.status(503).type('text').send('not ready: ' + lastProblem);
  });

  // ---------- Stripe webhook (needs the raw request body to check Stripe's signature) ----------
  app.post('/api/stripe/webhook', express.raw({ type: 'application/json', limit: '1mb' }), async (req, res) => {
    if (!stripe || !webhookSecret) return res.status(503).json({ code: 'not_configured', error: 'Webhook is not set up.' });
    let event;
    try { event = stripe.webhooks.constructEvent(req.body, req.get('stripe-signature') || '', webhookSecret); }
    catch (e) { return res.status(400).json({ code: 'bad_signature', error: 'Invalid signature.' }); }
    try { await handleStripeEvent(event); res.json({ received: true }); }
    catch (e) { log.error('webhook error:', event.type, e && e.message); res.status(500).json({ code: 'server_error', error: 'Webhook failed.' }); }
  });
  const tellRabbi = (subject, text) => {
    const to = (siteEnv && siteEnv.ADMIN_EMAIL) || ((((site && site.content && site.content()) || {}).org) || {}).email || '';
    if (mailer && to) Promise.resolve(mailer.send({ to, subject, text })).catch((e) => log.error('notify:', e && e.message));
  };
  // Email the Rabbi when a gift comes in through the app (one email per Stripe event, even if Stripe retries).
  async function notifyGift(event, o, cus) {
    const meta = o.metadata || {}, sub = (o.subscription_details && o.subscription_details.metadata) || (o.lines && o.lines.data && o.lines.data[0] && o.lines.data[0].metadata) || {};
    const isPi = event.type === 'payment_intent.succeeded';
    if (isPi ? meta.source !== 'pushka' : (sub.source || meta.source) !== 'pushka') return;
    const orgEmail = ((((site.content && site.content()) || {}).org) || {}).email, to = (siteEnv && siteEnv.ADMIN_EMAIL) || orgEmail || ''; if (!mailer || !to) return;
    const cents = isPi ? (o.amount_received || o.amount || 0) : (o.amount_paid || 0), email = o.customer_email || o.receipt_email || '';
    if (!(cents > 0) || !(await store.recordPaymentEvent({ id: 'gift_' + event.id, type: 'gift', customerId: cus, email, amount: cents, message: 'Gift received' }))) return;
    await store.resolvePayment('gift_' + event.id);
    const fund = FUND_NAMES[meta.fund || sub.fund] || meta.fund || sub.fund || 'General', monthly = !isPi, club = (sub.club || meta.club) === 'yes';
    const dedication = meta.dedication || sub.dedication || '';
    mailer.send({ to, subject: `Gift received: $${(cents / 100).toFixed(2)}${monthly ? ' monthly' : ''}${club ? ' (Chai Club)' : ''}`, text: `A gift came in through ${(meta.via || sub.via) === 'website' ? 'the website' : 'the My Pushka app'}.\n\nAmount: $${(cents / 100).toFixed(2)}${monthly ? ' (monthly)' : ''}\nFund: ${fund}${club ? '\nChai Club member' : ''}${dedication ? '\nDedication: ' + dedication : ''}${(meta.donor_name || sub.donor_name) ? '\nName: ' + (meta.donor_name || sub.donor_name) : ''}${email ? '\nEmail: ' + email : ''}${(meta.donor_phone || sub.donor_phone) ? '\nPhone: ' + (meta.donor_phone || sub.donor_phone) : ''}${(meta.donor_address || sub.donor_address) ? '\nAddress: ' + (meta.donor_address || sub.donor_address) : ''}${(meta.donor_note || sub.donor_note) ? '\nNote: ' + (meta.donor_note || sub.donor_note) : ''}\n\nSee everything in your Rabbi area: /admin/` }).catch((e) => log.error('gift email failed:', e && e.message));
    // The official receipt, on Chabad's letterhead, to the person who gave on the website (their language). Stripe's own receipt is switched off in Stripe.
    if ((meta.via || sub.via) === 'website') {
      let giverEmail = email, giverName = meta.donor_name || sub.donor_name || '';
      if (!giverEmail && cus && stripe) { try { const c = await stripe.customers.retrieve(cus); giverEmail = (c && !c.deleted && c.email) || ''; giverName = giverName || (c && c.name) || ''; } catch (e) { /* no address: no receipt */ } }
      if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(giverEmail)) {
        const L = ['he', 'ru'].includes(meta.lang || sub.lang) ? (meta.lang || sub.lang) : 'en', org = ((site.content && site.content()) || {}).org || {};
        const base = /^https:\/\/[^/\s]+$/.test(String((siteEnv && siteEnv.PUBLIC_URL) || '').replace(/\/+$/, '')) ? siteEnv.PUBLIC_URL.replace(/\/+$/, '') : 'https://jewishsamplehouse.com';
        const rc = require('./site/receipt.js').receipt({ lang: L, base, org, donor: { name: giverName, address: meta.donor_address || sub.donor_address || '' },
          gift: { cents, fund, fundId: meta.fund || sub.fund || '', dedication, monthly, date: new Date(), number: 'CL-' + new Date().getFullYear() + '-' + String(o.id || event.id).slice(-8).toUpperCase(), note: meta.donor_note || sub.donor_note || '' } });
        mailer.send({ to: giverEmail, subject: rc.subject, text: rc.text, html: rc.html }).catch((e) => log.error('gift receipt failed:', e && e.message));
      }
    }
  }
  async function handleStripeEvent(event) {
    if (!store) return;
    if (await kiddush.onStripeEvent(event)) return; // Kiddush sponsorship checkouts
    const o = event.data && event.data.object || {};
    const cus = typeof o.customer === 'string' ? o.customer : (o.customer && o.customer.id) || null;
    switch (event.type) {
      case 'invoice.payment_failed':
      case 'payment_intent.payment_failed': {
        if (event.type === 'payment_intent.payment_failed' && !(o.metadata && o.metadata.source === 'pushka')) return;
        const msg = event.type === 'invoice.payment_failed' ? 'Monthly gift could not be charged' : ((o.last_payment_error && o.last_payment_error.message) || 'Payment failed');
        const fresh = await store.recordPaymentEvent({ id: event.id, type: event.type, customerId: cus, email: o.customer_email || o.receipt_email || '', amount: o.amount_due || o.amount || 0, message: msg });
        if (fresh && cus) await store.flagCardIssue(cus, msg);
        if (fresh) tellRabbi(`Gift could not be charged: ${o.customer_email || o.receipt_email || cus || ''}`, `${msg}.\nAmount: $${((o.amount_due || o.amount || 0) / 100).toFixed(2)}\nEmail: ${o.customer_email || o.receipt_email || ''}\n\nStripe usually tries again; the donor may need a new card.`);
        return;
      }
      case 'invoice.payment_succeeded':
      case 'invoice.paid':
      case 'payment_intent.succeeded':
        await notifyGift(event, o, cus);
        if (cus && (event.type !== 'payment_intent.succeeded' || (o.metadata && o.metadata.source === 'pushka'))) { await store.clearCardIssue(cus); await store.resolveCustomerPayments(cus); }
        return;
      case 'charge.refunded':
      case 'customer.subscription.deleted':
        await store.recordPaymentEvent({ id: event.id, type: event.type, customerId: cus, email: o.billing_details && o.billing_details.email || '', amount: o.amount_refunded || o.amount || 0, message: event.type === 'charge.refunded' ? 'Gift refunded' : 'Monthly gift ended' });
        // These are informational: mark resolved right away so they do not look like open problems.
        await store.resolvePayment(event.id);
        tellRabbi(event.type === 'charge.refunded' ? `Refund: $${((o.amount_refunded || 0) / 100).toFixed(2)}` : 'A monthly gift was stopped', `${event.type === 'charge.refunded' ? 'A payment was refunded' : 'A monthly gift was cancelled'}.\nEmail: ${(o.billing_details && o.billing_details.email) || ''}\nStripe customer: ${cus || ''}`);
        return;
      default:
    }
  }
  // Apple Pay domain verification file (paste its contents into the APPLE_PAY_ASSOC setting).
  app.get('/.well-known/apple-developer-merchantid-domain-association', (req, res) => (applePayAssoc ? res.type('text').send(applePayAssoc) : res.status(404).type('text').send('Not found')));

  // ---------- sign-in by emailed code and saved pushkas (own parsers, so they are mounted before the general API) ----------
  const accountsOn = mountAccounts(app, { store, mailer, tokens, sessionSecret, limit, log });

  // The website (pages, accounts, RSVPs, SEO files). Mounted before the app's own "/" redirect below
  // and before /api, whose catch-all would otherwise answer /api/site.
  const site = mountSite(app, { store, mailer, secret: sessionSecret, limit, log, env: siteEnv, facebook, reminders, chatClient, contentDir: siteContentDir,
    giving: { club: () => clubBoard(), kiddush: () => kiddush.board() } }); // the weekly email shows the Chai Club honor board and this week's Kiddush
  app.locals.site = site;

  // ---------- API ----------
  const api = express.Router();
  api.use(express.json({ limit: '64kb' }));
  api.use(limit('api', 120, 10 * 60 * 1000));
  api.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

  api.get('/config', (req, res) => {
    res.json({ enabled: !!stripe, publishableKey: stripe ? publishableKey : '', livemode: /^pk_live_/.test(publishableKey || ''), members: !!store, accounts: accountsOn, vapidPublicKey: store && sendPush ? vapidPublicKey : '' });
  });

  const needStripe = (req, res, next) => (stripe ? next() : res.status(503).json({ code: 'not_configured', error: 'Card payments are not set up yet.' }));
  const auth = (req, res, next) => {
    const m = /^Bearer (.+)$/.exec(req.get('authorization') || '');
    const cus = m && verify(m[1]);
    if (!cus) return res.status(401).json({ code: 'unauthorized', error: 'Please add your details again.' });
    req.customerId = cus;
    next();
  };
  const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).catch((err) => handleError(err, res));
  function handleError(err, res) {
    if (err instanceof HttpError || err instanceof kiddush.HttpError) return res.status(err.status).json({ code: err.code, error: err.message });
    if (err && err.type === 'StripeCardError') {
      return res.status(402).json({ code: err.code === 'authentication_required' ? 'authentication_required' : 'card_error', error: err.message || 'Your card was declined.' });
    }
    log.error('payment error:', err && err.type, err && err.code, err && err.message);
    return res.status(500).json({ code: 'server_error', error: 'Something went wrong. Please try again.' });
  }

  const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
  const validEmail = (e) => /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(e) && e.length <= 254;
  function readGift(body) {
    const cents = Math.round(Number(body && body.amount) * 100);
    if (!Number.isFinite(cents) || cents < MIN_CENTS || cents > MAX_CENTS) throw new HttpError(400, 'invalid_amount', 'Please enter an amount between $1 and $10,000.');
    const fund = body.fund;
    if (!Object.prototype.hasOwnProperty.call(FUND_NAMES, fund)) throw new HttpError(400, 'invalid_fund', 'Please choose a fund.');
    const idem = clean(body.idem, 80);
    if (idem.length < 16) throw new HttpError(400, 'invalid_request', 'Missing request id.');
    const fee = body.fee === true;
    const total = fee ? Math.round(cents * (1 + FEE_RATE)) : cents;
    return { cents, total, fee, fund, dedication: clean(body.dedication, 80), idem };
  }
  async function savedCard(customer) {
    const list = await stripe.paymentMethods.list({ customer, type: 'card', limit: 1 });
    return list.data[0] || null;
  }
  const receiptOf = (charge) => (charge && typeof charge === 'object' && charge.receipt_url) || '';
  const cardInfo = (pm) => (pm ? { id: pm.id, brand: pm.card.brand, last4: pm.card.last4, expMonth: pm.card.exp_month, expYear: pm.card.exp_year } : null);

  // Create (or update) the Stripe customer. Returns the signed token the browser keeps.
  api.post('/customer', needStripe, wrap(async (req, res) => {
    const name = clean(req.body && req.body.name, 100), email = clean(req.body && req.body.email, 254).toLowerCase();
    if (!name) throw new HttpError(400, 'invalid_name', 'Please enter your name.');
    if (!validEmail(email)) throw new HttpError(400, 'invalid_email', 'Please enter a valid email address.');
    const phone = clean(req.body && req.body.phone, 30), address = clean(req.body && req.body.address, 200);
    const m = /^Bearer (.+)$/.exec(req.get('authorization') || ''), existing = m && verify(m[1]);
    let id;
    if (existing) { await stripe.customers.update(existing, { name, email, ...(phone ? { phone } : {}), metadata: { address } }); id = existing; }
    else { id = (await stripe.customers.create({ name, email, ...(phone ? { phone } : {}), metadata: { source: 'pushka', address } })).id; }
    res.json({ token: sign(id) });
  }));

  api.post('/setup-intent', needStripe, auth, wrap(async (req, res) => {
    const si = await stripe.setupIntents.create({ customer: req.customerId, allowed_payment_method_types: ['card'], usage: 'off_session', metadata: { source: 'pushka' } });
    res.json({ clientSecret: si.client_secret });
  }));

  api.get('/payment-method', needStripe, auth, wrap(async (req, res) => {
    res.json({ card: cardInfo(await savedCard(req.customerId)) });
  }));

  api.delete('/payment-method', needStripe, auth, wrap(async (req, res) => {
    const list = await stripe.paymentMethods.list({ customer: req.customerId, type: 'card', limit: 20 });
    for (const pm of list.data) await stripe.paymentMethods.detach(pm.id);
    res.json({ ok: true });
  }));

  // After a new card is saved: make it THE card. Monthly gifts switch to it and older cards are removed,
  // so "change card" really changes what gets charged.
  api.post('/payment-method/default', needStripe, auth, wrap(async (req, res) => {
    const list = await stripe.paymentMethods.list({ customer: req.customerId, type: 'card', limit: 20 });
    const newest = list.data.slice().sort((x, y) => (y.created || 0) - (x.created || 0))[0];
    if (!newest) throw new HttpError(400, 'no_card', 'Please add a card first.');
    await stripe.customers.update(req.customerId, { invoice_settings: { default_payment_method: newest.id } });
    for (const sub of await activeSubs(req.customerId)) await stripe.subscriptions.update(sub.id, { default_payment_method: newest.id });
    for (const pm of list.data) if (pm.id !== newest.id) await stripe.paymentMethods.detach(pm.id);
    res.json({ card: cardInfo(newest) });
  }));

  // One-time gift: charge the saved card right away (no redirect).
  api.post('/donate', limit('donate', 30, 10 * 60 * 1000), needStripe, auth, wrap(async (req, res) => {
    const g = readGift(req.body);
    const pm = await savedCard(req.customerId);
    if (!pm) throw new HttpError(400, 'no_card', 'Please add a card first.');
    const customer = /** @type {any} */ (await stripe.customers.retrieve(req.customerId));
    try {
      const pi = await stripe.paymentIntents.create({
        amount: g.total, currency: 'usd', customer: req.customerId, payment_method: pm.id,
        off_session: true, confirm: true,
        description: 'My Pushka gift: ' + FUND_NAMES[g.fund],
        receipt_email: customer && !customer.deleted && customer.email ? customer.email : undefined,
        metadata: { source: 'pushka', fund: g.fund, dedication: g.dedication, fee_covered: g.fee ? 'yes' : 'no', gift_cents: String(g.cents) },
        expand: ['latest_charge'],
      }, { idempotencyKey: 'pushka-donate-' + g.idem });
      return res.json({ status: pi.status, id: pi.id, receiptUrl: receiptOf(pi.latest_charge) });
    } catch (err) {
      const pi = err && (err.payment_intent || (err.raw && err.raw.payment_intent));
      if (err && err.code === 'authentication_required' && pi && pi.client_secret) {
        return res.json({ status: 'requires_action', id: pi.id, clientSecret: pi.client_secret, paymentMethodId: pm.id });
      }
      throw err;
    }
  }));

  // After the donor completes bank authentication in the browser.
  api.get('/payment/:id', needStripe, auth, wrap(async (req, res) => {
    const pi = await stripe.paymentIntents.retrieve(req.params.id, { expand: ['latest_charge'] });
    if (pi.customer !== req.customerId) throw new HttpError(403, 'forbidden', 'Not allowed.');
    res.json({ status: pi.status, receiptUrl: receiptOf(pi.latest_charge) });
  }));

  async function ensureProduct(fund) {
    const id = 'pushka-monthly-' + fund;
    try { await stripe.products.retrieve(id); }
    catch (e) {
      if (!(e && (e.code === 'resource_missing' || e.statusCode === 404))) throw e;
      try { await stripe.products.create({ id, name: 'Monthly gift: ' + FUND_NAMES[fund], metadata: { source: 'pushka' } }); }
      catch (e2) { if (!(e2 && e2.code === 'resource_already_exists')) throw e2; }
    }
    return id;
  }

  // Monthly gift: a Stripe subscription on the saved card.
  api.post('/subscribe', limit('subscribe', 15, 10 * 60 * 1000), needStripe, auth, wrap(async (req, res) => {
    const g = readGift(req.body);
    const pm = await savedCard(req.customerId);
    if (!pm) throw new HttpError(400, 'no_card', 'Please add a card first.');
    const product = await ensureProduct(g.fund);
    let club = null;
    if (req.body.club) {
      if (g.fund !== 'chai') throw new HttpError(400, 'invalid_fund', 'Please choose a fund.');
      // Any monthly amount is welcome; gifts under $72 simply have no level, so they are not put on the board.
      club = { name: clean(req.body.club.name, 60), show: req.body.club.show === true && !!clubLevel(g.cents) };
      if (club.show && !club.name) throw new HttpError(400, 'invalid_name', 'Please enter the name for the board.');
    }
    const sub = await stripe.subscriptions.create({
      customer: req.customerId, default_payment_method: pm.id,
      items: [{ price_data: { currency: 'usd', product, unit_amount: g.total, recurring: { interval: 'month' } } }],
      off_session: true, payment_behavior: 'error_if_incomplete',
      description: 'My Pushka monthly gift: ' + FUND_NAMES[g.fund],
      metadata: { source: 'pushka', fund: g.fund, dedication: g.dedication, fee_covered: g.fee ? 'yes' : 'no', gift_cents: String(g.cents), ...(club ? { club: 'yes', board_show: club.show ? 'yes' : 'no', board_name: club.show ? club.name : '' } : {}) },
      expand: ['latest_invoice'],
    }, { idempotencyKey: 'pushka-sub-' + g.idem });
    if (club && req.body.replace === true) { // changing level: stop the earlier Chai Club gift(s)
      for (const old of await activeSubs(req.customerId)) if (old.id !== sub.id && old.metadata && old.metadata.club === 'yes') await stripe.subscriptions.cancel(old.id);
    }
    clubCache = { at: 0, data: null };
    res.json({ status: sub.status, id: sub.id, receiptUrl: typeof sub.latest_invoice === 'object' && sub.latest_invoice ? sub.latest_invoice.hosted_invoice_url || '' : '' });
  }));

  // Giving on the website (/donate, /chai-club, sponsor pages): Stripe's secure checkout page, once or monthly.
  // Gifts carry the same details as the app's (source "pushka"), so the honor board, staff screens and receipts treat them alike.
  api.post('/give/checkout', limit('give', 20, 10 * 60 * 1000), needStripe, wrap(async (req, res) => {
    const b = req.body || {}, g = readGift(b), monthly = b.freq === 'monthly', lang = ['he', 'ru'].includes(b.lang) ? b.lang : 'en';
    let club = null;
    if (b.club) {
      if (g.fund !== 'chai' || !monthly) throw new HttpError(400, 'invalid_fund', 'Please choose a fund.');
      club = { name: clean(b.club.name, 60), show: b.club.show === true && !!clubLevel(g.cents) };
      if (club.show && !club.name) throw new HttpError(400, 'invalid_name', 'Please enter the name for the board.');
    }
    const back = /^\/(?!\/)[a-z0-9/._-]{0,120}$/i.test(String(b.back || '')) ? b.back : '/donate';
    const configured = /^https:\/\/[^/\s]+$/.test(String(siteEnv.PUBLIC_URL || '').replace(/\/+$/, '')) ? siteEnv.PUBLIC_URL.replace(/\/+$/, '') : '';
    const base = configured || req.protocol + '://' + req.get('host'), pre = lang === 'en' ? '' : '/' + lang;
    const meta = { source: 'pushka', via: 'website', fund: g.fund, dedication: g.dedication, fee_covered: g.fee ? 'yes' : 'no', gift_cents: String(g.cents), ...(club ? { club: 'yes', board_show: club.show ? 'yes' : 'no', board_name: club.show ? club.name : '' } : {}) };
    const name = (monthly ? 'Monthly gift: ' : 'Gift: ') + FUND_NAMES[g.fund] + (g.dedication ? ' (' + g.dedication + ')' : '');
    // Who is giving: asked on our own form, so a receipt can be emailed and the Rabbi knows whom to thank
    // (Stripe's page does not always ask, for example with some wallets).
    const giver = String(b.donorEmail || '').trim().toLowerCase().slice(0, 200), giverName = clean(b.donorName, 100);
    if (giver && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(giver)) throw new HttpError(400, 'invalid_email', 'Please enter a valid email address.');
    // The website's giving form asks for a name and an email (the official receipt goes there); the app's older form does not send `web`.
    if (b.web && (!giver || !giverName)) throw new HttpError(400, 'details_needed', 'Please enter your name and email address, so we can send your receipt.');
    if (giverName) meta.donor_name = giverName;
    // Optional extras the giver chose to add (kept with the payment in Stripe, and shown to the Rabbi with the gift).
    const extra = { donor_phone: clean(b.donorPhone, 40), donor_address: clean(b.donorAddress, 200), donor_note: clean(b.donorNote, 300) };
    for (const [k, v] of Object.entries(extra)) if (v) meta[k] = v;
    meta.lang = lang;
    const session = await stripe.checkout.sessions.create({
      mode: monthly ? 'subscription' : 'payment', locale: lang === 'en' ? 'auto' : lang,
      ...(giver ? { customer_email: giver } : {}), billing_address_collection: 'auto', ...(monthly ? {} : { customer_creation: 'always' }),
      line_items: [{ quantity: 1, price_data: { currency: 'usd', unit_amount: g.total, ...(monthly ? { product: await ensureProduct(g.fund), recurring: { interval: 'month' } } : { product_data: { name } }) } }],
      ...(monthly ? { subscription_data: { description: 'Monthly gift: ' + FUND_NAMES[g.fund], metadata: meta } } : { submit_type: 'donate', payment_intent_data: { description: name, metadata: meta } }),
      metadata: meta,
      success_url: base + pre + '/donate/thank-you?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: base + pre + back,
    }, { idempotencyKey: 'site-give-' + g.idem });
    if (club) clubCache = { at: 0, data: null };
    res.json({ url: session.url });
  }));

  const subView = (s) => {
    const item = s.items && s.items.data && s.items.data[0];
    const end = s.current_period_end || (item && item.current_period_end) || null;
    return { id: s.id, amount: item && item.price ? item.price.unit_amount / 100 : 0, fund: (s.metadata && s.metadata.fund) || 'general', next: end ? end * 1000 : null, club: !!(s.metadata && s.metadata.club === 'yes'), gift: s.metadata && s.metadata.gift_cents ? Number(s.metadata.gift_cents) / 100 : null, boardName: (s.metadata && s.metadata.board_name) || '', boardShow: !!(s.metadata && s.metadata.board_show === 'yes') };
  };
  async function activeSubs(customer) {
    const list = await stripe.subscriptions.list({ customer, status: 'active', limit: 20 });
    return list.data.filter((s) => s.metadata && s.metadata.source === 'pushka');
  }
  // Public honor board: first names the donor chose to show, grouped by level. Amounts are never shown.
  let clubCache = { at: 0, data: null };
  api.get('/club', limit('club', 60, 10 * 60 * 1000), wrap(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json(await clubBoard());
  }));
  async function clubBoard() {
    if (!stripe) return { members: [], counts: {}, total: 0 };
    if (!clubCache.data || Date.now() - clubCache.at > 5 * 60 * 1000) {
      const members = [], counts = { platinum: 0, gold: 0, silver: 0, bronze: 0 }; let after;
      for (let page = 0; page < 50; page++) {
        const list = await stripe.subscriptions.list({ status: 'active', limit: 100, ...(after ? { starting_after: after } : {}) });
        for (const sb of list.data) {
          const m = sb.metadata || {}; if (m.source !== 'pushka' || m.club !== 'yes') continue;
          const level = clubLevel(Number(m.gift_cents)); if (!level) continue;
          counts[level]++;
          if (m.board_show === 'yes' && m.board_name) members.push({ name: m.board_name, level, since: (sb.created || 0) * 1000 });
        }
        if (!list.has_more || !list.data.length) break; after = list.data[list.data.length - 1].id;
      }
      const rank = (l) => CLUB_LEVELS.findIndex(([id]) => id === l);
      members.sort((a, b) => rank(a.level) - rank(b.level) || a.since - b.since);
      clubCache = { at: Date.now(), data: { members, counts, total: Object.values(counts).reduce((a, b) => a + b, 0) } };
    }
    return clubCache.data;
  }
  // ---- community counter (anonymous: only totals) and announcements the Rabbi writes in the staff area ----
  const mem = { days: new Map(), ann: [] }, today = () => require('./scheduler.js').ptParts(new Date()).ymd;
  api.post('/community/coins', limit('community', 90, 10 * 60 * 1000), wrap(async (req, res) => {
    const n = Math.min(Math.max(parseInt(req.body && req.body.n, 10) || 0, 0), 50), cents = Math.min(Math.max(Math.round(Number(req.body && req.body.cents) || 0), 0), 100000);
    if (n > 0) { if (store) await store.addCommunity(today(), n, cents); else { const d = mem.days.get(today()) || { coins: 0 }; d.coins += n; mem.days.set(today(), d); } }
    res.json({ ok: true });
  }));
  api.get('/community', limit('community-read', 120, 10 * 60 * 1000), wrap(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const since = require('../pushka/hebdate.js').addDays(today(), -6);
    let coins = 0; if (store) coins = (await store.communitySince(since)).coins; else for (const [d, v] of mem.days) if (d >= since) coins += v.coins;
    res.json({ weekCoins: coins });
  }));
  api.get('/announcements', limit('announce', 120, 10 * 60 * 1000), wrap(async (req, res) => {
    const list = store ? await store.getKv('announcements', []) : mem.ann, now = today();
    res.json({ items: (Array.isArray(list) ? list : []).filter((a) => !a.until || a.until >= now).slice(0, 4) });
  }));
  api.get('/subscriptions', needStripe, auth, wrap(async (req, res) => {
    res.json({ subscriptions: (await activeSubs(req.customerId)).map(subView) });
  }));
  api.delete('/subscriptions/:id', needStripe, auth, wrap(async (req, res) => {
    const s = await stripe.subscriptions.retrieve(req.params.id);
    if (s.customer !== req.customerId) throw new HttpError(403, 'forbidden', 'Not allowed.');
    await stripe.subscriptions.cancel(s.id);
    res.json({ ok: true });
  }));

  // "Delete account": stop monthly gifts and remove saved cards. Giving history stays with Stripe.
  api.delete('/account', needStripe, auth, wrap(async (req, res) => {
    for (const s of await activeSubs(req.customerId)) await stripe.subscriptions.cancel(s.id);
    const list = await stripe.paymentMethods.list({ customer: req.customerId, type: 'card', limit: 20 });
    for (const pm of list.data) await stripe.paymentMethods.detach(pm.id);
    res.json({ ok: true });
  }));

  mountMembers(api, { store, tokens, wrap, HttpError, vapidPublicKey, limit });
  // Fundraising campaigns (/campaign/...): checkout (one payment or split into monthly payments), totals, donor wall.
  const campaigns = createCampaigns({ stripe, store, content: site.content, log, clean, HttpError, ensureProduct, FUND_NAMES, FEE_RATE, siteEnv, mailer });
  campaigns.mountPublic(api, { wrap, limit });
  app.locals.campaigns = campaigns;
  // Finances: the books and donor records in the Rabbi area (/admin/finances); online gifts come in from Stripe by themselves.
  const finances = createFinances({ stripe, store, content: site.content, mailer, log, funds: FUND_NAMES, now });
  if (reminders) finances.startAutoSync();
  app.locals.finances = finances;
  // Kiddush board API (its own router so the shared per-IP limit above does not throttle a room full of phones).
  const kapi = express.Router();
  kapi.use(express.json({ limit: '16kb' }));
  kapi.use((req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
  kiddush.mountPublic(kapi, { wrap, limit });
  kapi.use((req, res) => res.status(404).json({ code: 'not_found', error: 'Not found.' }));
  app.use('/api/kiddush', kapi);
  api.use((req, res) => res.status(404).json({ code: 'not_found', error: 'Not found.' }));
  app.use('/api', api);
  const adminOn = mountAdmin(app, { funds: FUND_NAMES, store, stripe, password: adminPassword, secret: sessionSecret, limit, send: sendPush, log, extend: (r, ctx) => { kiddush.mountAdmin(r, ctx); site.mountAdmin(r, ctx); campaigns.mountAdmin(r, ctx); finances.mountAdmin(r, ctx); }, levelOf: clubLevel });
  if (!adminOn) { // explain instead of a bare "Not found" when the staff area has not been switched on yet
    app.get(/^\/admin(\/.*)?$/, (req, res) => res.status(404).type('html').send('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Staff area not set up yet</title><body style="font:18px/1.5 Georgia,serif;max-width:560px;margin:8vh auto;padding:0 20px;color:#3b2412"><h1 style="font-weight:400">Staff area not set up yet</h1><p>The staff page switches on once this setting is added in Render (your hosting account):</p><ol><li><b>ADMIN_PASSWORD</b>: a password of 12 or more characters</li></ol><p>Some screens (yahrzeits, members, sponsorships) also need <b>DATABASE_URL</b>, the address of your database (for example a free one from neon.com).</p><p>After you save it, Render restarts and this page becomes your sign-in page. Step-by-step: <code>store/rabbi-setup.md</code>.</p>'));
  }

  // ---------- website (only the public files are served) ----------
  // Google Play "Trusted Web Activity" verification: proves this site and the Android app belong together.
  app.get('/.well-known/assetlinks.json', (req, res) => {
    const fps = (androidSha256 || '').split(',').map((x) => x.trim().toUpperCase()).filter((x) => /^([0-9A-F]{2}:){31}[0-9A-F]{2}$/.test(x));
    res.json(fps.length ? [{ relation: ['delegate_permission/common.handle_all_urls'], target: { namespace: 'android_app', package_name: androidPackage, sha256_cert_fingerprints: fps } }] : []);
  });
  // The app is the front door: any address pointed at this server (for example pushka.sample-chabad.org) opens it.
  // (an address starting with "kiddush." opens the Kiddush sponsor page instead)
  app.get(['/', '/index.html'], (req, res) => res.redirect(302, /^kiddush\./i.test(req.hostname) ? '/kiddush/' : '/pushka/'));
  // Kiddush board: /kiddush/ is the phone sponsor page, /kiddush/tv/ is the TV display.
  app.use('/kiddush', express.static(path.join(ROOT, 'kiddush'), { dotfiles: 'ignore', maxAge: 0, etag: true }));
  // The honor board page can be embedded (iframe) on the organisation's own website.
  const frameOk = (process.env.BOARD_FRAME_ANCESTORS || "https://www.sample-chabad.org https://sample-chabad.org https://*.sample-chabad.org https://chabad-samplehouse.onrender.com").trim();
  app.use('/board', (req, res, next) => {
    res.setHeader('Content-Security-Policy', ["default-src 'self'", "script-src 'self'", "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com", "font-src 'self' https://fonts.gstatic.com", "img-src 'self' data:", "connect-src 'self'", "base-uri 'self'", "frame-ancestors 'self' " + frameOk].join('; '));
    next();
  }, express.static(path.join(ROOT, 'board'), { dotfiles: 'ignore', maxAge: 0, etag: true }));
  app.use('/pushka', express.static(path.join(ROOT, 'pushka'), { dotfiles: 'ignore', maxAge: 0, etag: true }));
  app.use(site.notFound);
  app.use((req, res) => res.status(404).type('text').send('Not found'));
  // Last stop for errors: a short message, never the server's code (bad JSON or a broken address is the visitor's 4xx).
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    const status = err && (err.status || err.statusCode) >= 400 && (err.status || err.statusCode) < 500 ? (err.status || err.statusCode) : 500;
    if (status === 500) log.error('server error:', err && err.message);
    if (res.headersSent) return res.end();
    if (/^\/(api|admin\/api)\//.test(req.path)) return res.status(status).json({ code: status === 500 ? 'server_error' : 'bad_request', error: status === 500 ? 'Something went wrong. Please try again.' : 'Bad request.' });
    res.status(status === 400 ? 404 : status).type('text').send(status === 500 ? 'Something went wrong. Please try again, or call 555-555-0100.' : 'Not found');
  });
  return app;
}

if (require.main === module) {
  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret || sessionSecret.length < 16) { console.error('SESSION_SECRET must be set (16+ characters).'); process.exit(1); }
  const port = process.env.PORT || 3000;
  (async () => {
    let store = null, sendPush = null;
    if (process.env.DATABASE_URL) {
      store = require('./store.js').createStore(process.env.DATABASE_URL);
      // If the database is down when the server starts (or restarts during an update), the website still opens: most pages
      // need no database. It tries for half a minute, then starts anyway and keeps trying every minute in the background.
      let ready = false;
      for (let i = 0; i < 6 && !ready; i++) { try { await store.migrate(); ready = true; } catch (e) { console.error('Database not ready (' + (e && e.message) + '), trying again...'); await new Promise((r) => setTimeout(r, 5000)); } }
      if (!ready) {
        console.error('Database not reachable: starting the website anyway; trying again every minute.');
        const t = setInterval(() => { store.migrate().then(() => { clearInterval(t); console.log('Database connected.'); }).catch(() => {}); }, 60000); t.unref();
      }
      try { const n = await require('./kiddush-legacy.js').importLegacy(store); if (n) console.log('Imported ' + n + ' sponsors from the original Kiddush board.'); } catch (e) { console.error('Kiddush import skipped:', e.message); }
      console.log('Database connected: members, yahrzeits and reminders are on.');
    } else console.log('DATABASE_URL not set: yahrzeit sharing, reminders and the Rabbi area are off.');
    // Keys the Rabbi saved in the Rabbi area ("Keys and settings") win over the server's settings file. Saving one restarts
    // the website (the server, systemd or Render, starts it again by itself), so they are read here, before anything uses them.
    const settings = require('./site/secure-settings.js');
    const applied = await settings.applyOverrides(store, process.env, sessionSecret);
    if (applied.length) console.log('Settings saved in the Rabbi area are in use: ' + applied.join(', '));
    settings.onRestart(() => { console.log('Restarting to use a changed setting.'); process.exit(0); });
    const secret = process.env.STRIPE_SECRET_KEY, pk = process.env.STRIPE_PUBLISHABLE_KEY;
    let stripe = null;
    if (secret && pk) {
      const Stripe = require('stripe');
      stripe = new Stripe(secret);
      console.log('Stripe enabled in ' + (/^sk_live_/.test(secret) ? 'LIVE' : 'TEST') + ' mode.');
      if (/^sk_live_/.test(secret) !== /^pk_live_/.test(pk)) { console.error('Stripe keys mix live and test modes.'); process.exit(1); }
    } else {
      console.log('Stripe keys not set: running without card payments.');
    }
    const vapidPub = process.env.VAPID_PUBLIC_KEY || '', vapidPriv = process.env.VAPID_PRIVATE_KEY || '';
    if (vapidPub && vapidPriv) {
      const webpush = require('web-push');
      webpush.setVapidDetails('mailto:office@sample-chabad.org', vapidPub, vapidPriv);
      sendPush = (sub, payload) => webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify(payload), { TTL: 6 * 3600 });
    }
    if (store && sendPush) { require('./scheduler.js').createScheduler({ store, send: sendPush }).start(); console.log('Reminder scheduler started.'); }
    const server = createApp({
      stripe, publishableKey: pk, sessionSecret, androidPackage: process.env.ANDROID_PACKAGE || undefined, androidSha256: process.env.ANDROID_SHA256 || '',
      store, sendPush, mailer: require('./mailer.js').createMailer({ url: process.env.SMTP_URL, from: process.env.MAIL_FROM }), reminders: true, vapidPublicKey: vapidPub, webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || '', adminPassword: process.env.ADMIN_PASSWORD || '', applePayAssoc: process.env.APPLE_PAY_ASSOC || '',
    }).listen(port, () => console.log('Listening on ' + port));
    // An update (or a restart) sends SIGTERM: stop taking new visitors, let the ones being served finish (a payment, a
    // form), then close the database, so no one is cut off halfway. Render already sends new visitors to the new version.
    const stop = (sig) => {
      console.log(sig + ': finishing open requests, then stopping.');
      server.close(() => { Promise.resolve(store && store.pool && store.pool.end()).catch(() => {}).finally(() => process.exit(0)); });
      setTimeout(() => process.exit(0), 25000).unref();
    };
    process.once('SIGTERM', () => stop('SIGTERM')); process.once('SIGINT', () => stop('SIGINT'));
    // Render's free plan puts the server to sleep after 15 minutes without visitors; the next visitor then waits up to
    // a minute, and no reminder emails go out while it sleeps. Visiting our own public address every 10 minutes keeps
    // it awake (one always-on service fits in the free plan's 750 hours a month). KEEP_AWAKE=0 turns this off.
    const self = process.env.RENDER_EXTERNAL_URL || '';
    if (process.env.RENDER && self && process.env.KEEP_AWAKE !== '0') {
      setInterval(() => { fetch(self.replace(/\/$/, '') + '/healthz').catch(() => {}); }, 10 * 60 * 1000).unref();
      console.log('Keeping the server awake: ' + self);
    }
  })().catch((e) => { console.error('Startup failed:', e.message); process.exit(1); });
}

module.exports = { createApp, FUND_NAMES };
