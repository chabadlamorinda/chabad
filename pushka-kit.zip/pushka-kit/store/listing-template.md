# Google Play store text (fill in, then paste into the Play Console)

Privacy policy URL: https://<your-address>/pushka/privacy.html

**App name (max 30):** My Pushka · Chabad of Sampleton
**Short description (max 80):** Drop coins daily, watch your pushka fill, then give to Chabad of Sampleton.
**Full description:** Ask Claude to write this from your finished app (what it does, your funds, English and Hebrew), in the same plain style as the app.

Play Console answers (check each against Google's current wording):
- Data safety: collects name, email, optional phone and mailing address, payment info (entered into Stripe's secure form; you never see the card number), the gift amount, and only if the user opts in: yahrzeit names/dates and a push-notification address. Not sold. Encrypted in transit. Users can delete their data in the app (More → Profile → Delete account).
- Ads: none. In-app purchases: none (donations to a nonprofit are not purchases of digital goods). Target audience: 18 and over.
