// ===== My Pushka · Chabad of Sampleton =====
// Visual system from the design handoff ("Classical"). English and Hebrew (RTL).
// Cards are saved and charged through our own Stripe-backed server (/api); the donation-page
// redirect below is only a fallback used when the server has no Stripe keys yet.
const DONATE_URL = "https://www.sample-chabad.org/donate"; // the website's donation page (used when card payments are not set up)
const CANDLE_ZIP = "10001";                                      // Brookfield, ST
const SITE_EMAIL = "office@sample-chabad.org";
const MODEKEY = "samplehouse-pushka-mode";
const PRACTICE = (() => { try { const q = new URLSearchParams(location.search).get("practice"); if (q === "1") localStorage.setItem(MODEKEY, "1"); else if (q === "0") localStorage.removeItem(MODEKEY); if (q !== null && history.replaceState) history.replaceState(null, "", location.pathname + location.hash); return localStorage.getItem(MODEKEY) === "1"; } catch (e) { return false; } })();
const KEY = PRACTICE ? "samplehouse-pushka-practice" : "samplehouse-pushka-v4";

const SITE = "https://www.sample-chabad.org";
const C3_HTML = `<bdi dir="ltr" style="white-space:nowrap">501(c)(3)</bdi>`;
const EIN_HTML = `<bdi dir="ltr">00-0000000</bdi>`;
const ORG_EIN = "00-0000000", ORG_PHONE = "555-555-0100", ORG_ADDR = "100 Sample Street, Brookfield, ST 00000", VENMO = "CHABAD-SAMPLE";
const ZELLE_EMAIL = ""; // the Zelle address (also set "zelle" in site/content/org.json so the website shows it)
const STOCK_URL = "https://www.sample-chabad.org", CRYPTO_URL = "https://www.sample-chabad.org", BUILD_URL = "https://www.sample-chabad.org"; // pages on the new website
const FEE_RATE = 0.035, MAX_CARD = 10000;
// <KIT:FEATURES>
const FEATURES = { building: false, kiddush: false };
// </KIT:FEATURES>
// The same funds, amounts and options as the website's donation page (/donate)
// <KIT:FUNDS>
const FUNDS = [
  { id: "general", name: "General Fund", desc: "Where it’s needed most", long: "Supports the day-to-day work of Chabad of Sampleton." },
  { id: "chai", name: "Chai Club", desc: "", long: "A gift to the Chai Club of monthly donors." },
  { id: "holidays", name: "Holiday Programs", desc: "", long: "Supports our holiday programs and community celebrations." },
  { id: "pledge", name: "Pledge", desc: "", long: "Use this to pay toward a pledge you have already made." },
];
// </KIT:FUNDS>
// <KIT:LEGACY>
const LEGACY = {};
// </KIT:LEGACY>
const GIVE_AMTS = [180, 360, 1000, 1800, 3600, 7200];
const LEVELS = [["Visionary", 1000000], ["Founder", 500000], ["Pioneer", 250000], ["Builder", 100000], ["Pillar", 50000], ["Partner", 25000], ["Benefactor", 18000], ["Sustainer", 10000], ["Patron", 5000], ["Supporter", 1800]];
const SPONSORS = [["kiddush", "Sponsor a Kiddush", "synagogue"], ["simchat", "Simchat Torah sponsorship", "holidays"], ["pesach", "Passover sponsorships", "holidays"], ["dinner", "Holiday dinner sponsorships (Rosh Hashanah, Sukkot, Shavuot)", "holidays"]];
const WAYS = () => [["zelle", "Zelle", I.card], ["venmo", "Venmo", I.card], ["daf", "Donor Advised Fund", I.file], ["check", "Check", I.file], ["wire", "Wire / ACH", I.swap], ["stock", "Stock", I.give], ["crypto", "Cryptocurrency", I.give]];
const METHOD = { online: "Online", zelle: "Zelle", venmo: "Venmo", daf: "DAF", check: "Check", wire: "Wire" };
const EMPTY_MODES = { manual: "Manual empty", full: "When full", friday: "Every Friday", monthly: "Monthly" };
const API = { enabled: false, pk: "", live: false, card: null, subs: null };

// ---------- helpers ----------
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const nl = (s) => esc(s).replace(/\n/g, "<br>");
const uid = () => Math.random().toString(36).slice(2, 10);
const r2 = (n) => Math.round(n * 100) / 100;
const fundOf = (id) => FUNDS.find((f) => f.id === (LEGACY[id] || id)) || FUNDS[0];
const money = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: Number.isInteger(+n) ? 0 : 2, maximumFractionDigits: 2 }).format(n);
const money2 = (n) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);
const dkey = (d) => d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate();
const isWk = (d) => d.getDay() >= 1 && d.getDay() <= 5;

// ---------- state ----------
const walletId = () => { const n = String(Math.floor(Math.random() * 1e6)).padStart(6, "0"); return n.slice(0, 3) + "-" + n.slice(3); };
const detectLang = () => (/^he\b/i.test(navigator.language || "") ? "he" : "en");
const def = () => ({
  lang: detectLang(), name: "", email: "", billingEmail: "", phone: "", address: "", token: "", synced: "",
  pushkas: [{ id: "p1", name: "", balance: 0, drops: 0 }], cur: "p1",
  goal: 36, presets: [1.8, 5, 18], emptyMode: "manual",
  sound: true, jingle: true, confetti: true, vibrate: true, partial: false, addl: false, bio: "",
  wallet: { id: walletId(), balance: 0 },
  history: [], pracSubs: [],
  rem: { candle: { on: true, mins: 15 }, streak: { on: false }, weekly: { on: false }, custom: [] }, remV: 2, family: [], kids: { on: false, pin: "", coins: 0 }, dates: [], snd: "classic", seasonal: true, ms: {}, auto: { on: false, amt: 1.8, last: "" }, yzLeads: [30, 7, 1], club: { name: "", show: true },
  nudge: { at: 0, n: 0, first: Date.now() },
  yz: [], yzShare: false, yzRemind: false, pushOn: false, mtoken: "", msig: "",
  candles: [], notified: {}, maaser: 10, lastEmptied: Date.now(), prompted: "",
});
const SND_OK = ["classic", "chime", "soft"];
function load() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
  if (!o && !PRACTICE) { try { const v = JSON.parse(localStorage.getItem("samplehouse-pushka-v3")); if (v) o = { name: v.name, email: v.email, history: v.history, pushkas: [{ id: "p1", name: "", balance: v.balance || 0, drops: v.drops || 0 }] }; } catch (e) {} }
  return normalize(o);
}
function normalize(o) {
  const b = def(), s = Object.assign({}, b, o || {});
  s.rem = Object.assign({}, b.rem, (o && o.rem) || {}); s.rem.candle = Object.assign({}, b.rem.candle, s.rem.candle); s.rem.streak = Object.assign({}, b.rem.streak, s.rem.streak);
  if (!Array.isArray(s.rem.custom)) s.rem.custom = [];
  s.wallet = Object.assign({}, b.wallet, (o && o.wallet) || {});
  if (!Array.isArray(s.pushkas) || !s.pushkas.length) s.pushkas = b.pushkas;
  if (!s.pushkas.find((p) => p.id === s.cur)) s.cur = s.pushkas[0].id;
  if (!o || !o.remV) s.rem.candle.on = true; // new default: a reminder to give before Shabbat (people can turn it off)
  s.remV = 2; if (!Array.isArray(s.yzLeads) || !s.yzLeads.length) s.yzLeads = [30, 7, 1];
  s.club = Object.assign({ name: "", show: true }, s.club || {});
  s.auto = Object.assign({ on: false, amt: 1.8, last: "" }, s.auto || {});
  s.rem.weekly = Object.assign({ on: false }, s.rem.weekly || {}); s.kids = Object.assign({ on: false, pin: "", coins: 0 }, s.kids || {});
  if (!Array.isArray(s.family)) s.family = []; if (!Array.isArray(s.dates)) s.dates = []; if (!s.ms || typeof s.ms !== "object") s.ms = {}; if (s.seasonal === undefined) s.seasonal = true; if (!SND_OK.includes(s.snd)) s.snd = "classic";
  return s;
}
let S = load();
const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
const save = () => { if (S.auth && !PRACTICE && !noSync) { S.dirty = true; syncSoon(); } persist(); };
let noSync = false;
const P = () => S.pushkas.find((p) => p.id === S.cur) || S.pushkas[0];
const U = { page: "home", stack: [], pending: null, giveFund: null, giveAmt: 36, freq: "once", dedication: "", segQ: "", segCat: "All", segId: null, maaserAmt: "", drawn: "", busy: false, onClose: null };
const pushHist = (h) => { S.history.unshift(h); if (S.history.length > 1000) S.history.length = 1000; };

// ---------- language ----------
let LANG = S.lang === "he" ? "he" : "en";
const tpl = (k) => (LANG === "he" && typeof HE !== "undefined" && HE[k]) || k;
const fill = (s, v) => s.replace(/\{(\w+)\}/g, (m, n) => (v && n in v ? v[n] : m));
const tt = (k, v) => fill(tpl(k), v);                 // plain text (toasts, notifications, attributes you escape yourself)
const t = (k, v) => fill(esc(tpl(k)), v);              // HTML-safe text; values in v must already be safe
const loc = () => (LANG === "he" ? "he-IL" : "en-US");
const hebFull = (d) => new Intl.DateTimeFormat(LANG === "he" ? "he-u-ca-hebrew" : "en-u-ca-hebrew", { day: "numeric", month: "long", year: "numeric" }).format(d).replace(/ AM$/, "");
const hebYearNum = (d) => new Intl.DateTimeFormat("en-u-ca-hebrew", { year: "numeric" }).format(d).replace(/\D/g, "");
const hebYearLabel = (d) => (LANG === "he" ? new Intl.DateTimeFormat("he-u-ca-hebrew", { year: "numeric" }).format(d) : hebYearNum(d));
const hebDay = (d) => +new Intl.DateTimeFormat("en-u-ca-hebrew", { day: "numeric" }).format(d).replace(/\D/g, "");
const greg = (d) => new Intl.DateTimeFormat(loc(), { weekday: "short", month: "short", day: "numeric" }).format(d);
const clock = (d) => d.toLocaleTimeString(loc(), { hour: "numeric", minute: "2-digit" });
const when = (ts) => {
  const d = new Date(ts), now = new Date(), y = new Date(now - 864e5);
  if (d.toDateString() === now.toDateString()) return tt("Today · {time}", { time: clock(d) });
  if (d.toDateString() === y.toDateString()) return tt("Yesterday · {time}", { time: clock(d) });
  return greg(d);
};
function applyLang() {
  LANG = S.lang === "he" ? "he" : "en";
  document.documentElement.lang = LANG; document.documentElement.dir = LANG === "he" ? "rtl" : "ltr";
  document.title = tt("My Pushka · Chabad of Sampleton"); stripeP = null;
}
const firstName = () => (S.name || "").trim().split(/\s+/)[0];
const pTitle = (p) => p.name || (firstName() ? tt("{name}’s Pushka", { name: firstName() }) : tt("My Pushka"));
const catL = (c) => (LANG === "he" && typeof SEG_CATS_HE !== "undefined" && SEG_CATS_HE[c]) || c;
const SG = (s) => { if (LANG !== "he" || typeof SEGULOS_HE === "undefined" || !SEGULOS_HE[s.id]) return s; const h = SEGULOS_HE[s.id]; return Object.assign({}, s, { title: h.t, blurb: h.b, how: h.h || s.how, src: h.s || s.src, tr: "", en: "" }); };
const QUOTES = () => (LANG === "he" && typeof REBBE_QUOTES_HE !== "undefined" ? REBBE_QUOTES_HE : REBBE_QUOTES);
const linkText = (txt) => { if (LANG !== "he") return txt; const m = /^(?:Read )?Psalm (\d+)(?::([\d-]+))?$/.exec(txt); if (m) return tt("Psalm") + " " + m[1] + (m[2] ? ":" + m[2] : ""); return tt(txt); };

// ---------- streak ----------
function streak() {
  const days = new Set(S.history.filter((h) => h.kind === "coin").map((h) => dkey(new Date(h.t))));
  let n = 0; const d = new Date();
  for (let i = 0; i < 800; i++) {
    if (isWk(d)) { if (days.has(dkey(d))) n++; else if (i > 0) break; }
    d.setDate(d.getDate() - 1);
  }
  return n;
}
const gaveToday = () => S.history.some((h) => h.kind === "coin" && dkey(new Date(h.t)) === dkey(new Date()));

// ---------- Tehillim monthly cycle ----------
const TEH = [[1, 9], [10, 17], [18, 22], [23, 28], [29, 34], [35, 38], [39, 43], [44, 48], [49, 54], [55, 59], [60, 65], [66, 68], [69, 71], [72, 76], [77, 78], [79, 82], [83, 87], [88, 89], [90, 96], [97, 103], [104, 105], [106, 107], [108, 112], [113, 118], [119, 119, "1-96"], [119, 119, "97-176"], [120, 134], [135, 139], [140, 144], [145, 150]];
function tehillimToday() {
  const d = new Date(), n = hebDay(d), tomorrow = new Date(d.getTime() + 864e5), combined = n === 29 && hebDay(tomorrow) === 1;
  const lo = combined ? 140 : TEH[n - 1][0], hi = combined ? 150 : TEH[n - 1][1], part = combined ? "" : TEH[n - 1][2], links = [];
  for (let c = lo; c <= hi; c++) links.push({ t: "Psalm " + c + (part ? ":" + part : ""), u: "https://www.sefaria.org/Psalms." + c + (part ? "." + part : "") });
  const label = lo === hi ? tt("Psalm") + " " + lo + (part ? ":" + part : "") : tt("Psalms") + " " + lo + "–" + hi;
  return { day: combined ? "29–30" : n, label, links };
}

// ---------- icons (Lucide, 1.5 stroke) ----------
const ico = (d, s = 22, extra = "") => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
const I = {
  home: '<circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.34 18"/><path d="M7 6h1v4"/><path d="m16.71 13.88.7.71-2.82 2.82"/>',
  give: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  wallet: '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  profile: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  chev: '<path d="m9 18 6-6-6-6"/>', back: '<path d="m15 18-6-6 6-6"/>', check: '<path d="M20 6 9 17l-5-5"/>',
  card: '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  book: '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
  calc: '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><path d="M16 10h.01M12 10h.01M8 10h.01M12 14h.01M8 14h.01M16 14v4M12 18h.01M8 18h.01"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
  pencil: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  swap: '<path d="m21 16-4 4-4-4"/><path d="M17 20V4"/><path d="m3 8 4-4 4 4"/><path d="M7 4v16"/>',
  file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>', lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  ext: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
};
const FLIP = 'class="flip"';

// ---------- sound / feel ----------
let ac;
function tone(f, delay, dur, type = "sine", vol = 0.15) {
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume();
    const o = ac.createOscillator(), g = ac.createGain(), at = ac.currentTime + delay;
    o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, at); g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    o.connect(g).connect(ac.destination); o.start(at); o.stop(at + dur + 0.05);
  } catch (e) {}
}
function clink(n = 1, gap = 0.07, delay = 0.42) { // metallic clink per design spec
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === "suspended") ac.resume();
    for (let i = 0; i < n; i++) {
      const pk = SND[S.snd] || SND.classic, t0 = ac.currentTime + delay + i * gap, base = pk[0] + Math.random() * pk[1];
      pk[2].forEach(([m, g, d]) => {
        const o = ac.createOscillator(), v = ac.createGain();
        o.type = "sine"; o.frequency.value = base * m;
        v.gain.setValueAtTime(0, t0); v.gain.linearRampToValueAtTime(g, t0 + 0.003); v.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
        o.connect(v).connect(ac.destination); o.start(t0); o.stop(t0 + d + 0.05);
      });
    }
  } catch (e) {}
}
const buzz = (p) => { if (S.vibrate && navigator.vibrate) navigator.vibrate(p); };
function fanfare() { if (S.confetti) [[784, 0], [988, 0.1], [1175, 0.2], [1568, 0.3]].forEach(([f, d]) => tone(f, d, 0.35, "triangle", 0.12)); }
function confetti() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const c = document.createElement("canvas"); c.className = "confetti"; c.width = innerWidth; c.height = innerHeight; document.body.append(c);
  const g = c.getContext("2d"), cols = ["#b68235", "#e1ad66", "#2a5a9e", "#3b6cb3", "#facb8d", "#7d5411"];
  const ps = Array.from({ length: 140 }, () => ({ x: innerWidth / 2 + (Math.random() - 0.5) * 80, y: innerHeight * 0.55, vx: (Math.random() - 0.5) * 14, vy: -Math.random() * 16 - 6, w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4, c: cols[(Math.random() * cols.length) | 0] }));
  let n = 0;
  (function f() {
    g.clearRect(0, 0, c.width, c.height);
    ps.forEach((p) => { p.vy += 0.45; p.x += p.vx; p.y += p.vy; p.vx *= 0.99; p.r += p.vr; g.save(); g.translate(p.x, p.y); g.rotate(p.r); g.fillStyle = p.c; g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); g.restore(); });
    if (++n < 150) requestAnimationFrame(f); else c.remove();
  })();
}
function toast(msg, act) {
  $$(".toast").forEach((x) => x.remove());
  const el = document.createElement("div"); el.className = "toast"; el.setAttribute("role", "status"); const sp = document.createElement("span"); sp.textContent = msg; el.append(sp);
  if (act) { const b = document.createElement("button"); b.type = "button"; b.className = "toast-act"; b.textContent = act.label; b.onclick = () => { el.remove(); act.fn(); }; el.append(b); }
  document.body.append(el); setTimeout(() => el.remove(), act ? 6500 : 2800);
}

// ---------- sheets ----------
function sheet(html, onOpen, onClose, lock) {
  const prev = U.onClose; U.onClose = null; if (prev) prev();
  U.onClose = onClose || null;
  $("#overlay").innerHTML = `<div class="scrim" ${lock ? "" : 'data-act="closeSheet"'}></div><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div>`;
  if (onOpen) onOpen($("#overlay"));
}
function closeSheet() { const f = U.onClose; U.onClose = null; $("#overlay").innerHTML = ""; if (f) f(); }
const sheetBtns = (primary, secondary) => `<button class="btn btn-primary cta" data-act="${primary[0]}" ${primary[2] ? `data-v="${esc(primary[2])}"` : ""}>${primary[1]}</button>${secondary ? `<button class="btn btn-ghost" data-act="${secondary[0]}">${secondary[1]}</button>` : ""}`;
const infoSheet = (title, body) => sheet(`<div><h3>${esc(title)}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${body}</div></div><button class="btn btn-primary cta" data-act="closeSheet">${t("OK")}</button>`);

// ---------- payments (our Stripe-backed server) ----------
const ERRS = { no_card: "Please add a card first.", invalid_amount: "Please enter an amount between $1 and $10,000.", invalid_fund: "Please choose a fund.", invalid_name: "Please enter your name.", invalid_email: "Please enter a valid email address.", unauthorized: "Please add your card again.", rate_limited: "Too many requests. Please wait a moment.", not_configured: "Card payments are not set up yet.", forbidden: "Not allowed.", network: "Can’t reach the server. Check your connection and try again.", authentication_required: "Your bank needs extra verification. Please try again." };
function errText(e) {
  if (e && e.code === "card_error") return LANG === "he" ? tt("Your card was declined. Please try another card.") : (e.message || tt("Your card was declined. Please try another card."));
  return tt(ERRS[e && e.code] || "Something went wrong. Please try again.");
}
async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json" }, tok = opts.member ? S.mtoken : S.token; if (tok) headers.Authorization = "Bearer " + tok;
  let r; try { r = await fetch("/api" + path, { method: opts.method || "GET", headers, body: opts.body ? JSON.stringify(opts.body) : undefined }); } catch (e) { throw Object.assign(new Error("network"), { code: "network" }); }
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (!r.ok) { if (r.status === 401 && opts.member && S.mtoken) { S.mtoken = ""; S.msig = ""; if (S.auth) S.auth = null; save(); } else if (r.status === 401 && !opts.member && S.token) { S.token = ""; S.synced = ""; API.card = null; save(); } throw Object.assign(new Error(j.error || "Request failed"), { code: j.code || "server_error", status: r.status, data: j }); }
  return j;
}
const BRANDS = { visa: "Visa", mastercard: "Mastercard", amex: "American Express", discover: "Discover", diners: "Diners Club", jcb: "JCB", unionpay: "UnionPay" };
const cardLabel = () => (API.card ? (BRANDS[API.card.brand] || API.card.brand) + " •••• " + API.card.last4 : "");
const cardExp = () => (API.card && API.card.expMonth ? String(API.card.expMonth).padStart(2, "0") + "/" + String(API.card.expYear).slice(-2) : "");
const cardExpired = () => { const c = API.card; if (!c || !c.expYear) return false; const n = new Date(); return c.expYear < n.getFullYear() || (c.expYear === n.getFullYear() && c.expMonth < n.getMonth() + 1); };
async function refreshCard() { try { API.card = (await api("/payment-method")).card; } catch (e) { API.card = null; } }
async function loadSubs() { try { API.subs = (await api("/subscriptions")).subscriptions; } catch (e) { API.subs = []; } if (U.page === "profile" || U.page === "club") draw(); }
async function initPay() { if (PRACTICE) { API.enabled = true; API.card = { brand: "visa", last4: "4242" }; API.subs = S.pracSubs || []; return draw(); } try { const c = await api("/config"); if (c.enabled && c.publishableKey) { API.enabled = true; API.pk = c.publishableKey; API.live = !!c.livemode; if (S.token) await refreshCard(); } API.members = !!c.members; API.accounts = !!c.accounts && !PRACTICE; API.vapid = c.vapidPublicKey || ""; if (API.members && S.mtoken) { try { API.cardIssue = (await api("/member", { member: true })).cardIssue || ""; } catch (e) {} } if (API.vapid && S.pushOn) pushSync(); } catch (e) {} draw(); }
let stripeP = null;
function loadStripe() {
  if (stripeP) return stripeP;
  stripeP = new Promise((res, rej) => {
    const make = () => res(window.Stripe(API.pk, { locale: LANG === "he" ? "he" : "en" }));
    if (window.Stripe) return make();
    const s = document.createElement("script"); s.src = "https://js.stripe.com/v3/"; s.onload = make; s.onerror = () => { stripeP = null; rej(Object.assign(new Error("stripe-js"), { code: "network" })); };
    document.head.append(s);
  });
  return stripeP;
}
function askDetails() {
  return new Promise((res) => {
    sheet(`<div><h3>${t("Your details")}</h3><div class="h-s" style="font-size:13px">${t("We need your name and email to send your receipt.")}</div></div>
      <div class="field"><label for="dn1">${t("Name")}</label><input class="input" id="dn1" autocomplete="name" maxlength="100" value="${esc(S.name)}"></div>
      <div class="field"><label for="dn2">${t("Email")}</label><input class="input" id="dn2" type="email" autocomplete="email" maxlength="254" value="${esc(S.email)}"></div>
      <div class="field"><label for="dn3">${t("Phone (optional)")}</label><input class="input" id="dn3" type="tel" autocomplete="tel" maxlength="30" value="${esc(S.phone)}"></div>
      <div class="field"><label for="dn4">${t("Mailing address (optional)")}</label><input class="input" id="dn4" autocomplete="street-address" maxlength="200" value="${esc(S.address)}"></div>
      <div id="dnErr" class="err" role="alert"></div><button class="btn btn-primary cta" id="dnGo">${t("Continue")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`,
    (o) => { $("#dnGo", o).onclick = () => { const n = $("#dn1", o).value.trim(), e = $("#dn2", o).value.trim(); if (!n) { $("#dnErr", o).textContent = tt("Please enter your name."); return; } if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) { $("#dnErr", o).textContent = tt("Please enter a valid email address."); return; } S.name = n; S.email = e; S.phone = $("#dn3", o).value.trim(); S.address = $("#dn4", o).value.trim(); save(); res(true); closeSheet(); }; },
    () => res(false));
  });
}
async function ensureCustomer() {
  if (!S.name || !S.email) { if (!(await askDetails())) return false; }
  const sig = [S.name, S.email, S.phone, S.address].join("|");
  if (S.token && S.synced === sig) return true;
  const r = await api("/customer", { method: "POST", body: { name: S.name, email: S.email, phone: S.phone, address: S.address } }); S.token = r.token; S.synced = sig; save(); if (S.mtoken) memberSync().catch(() => {}); return true;
}
async function addCard() {
  try { if (!(await ensureCustomer())) return false; } catch (e) { toast(errText(e)); return false; }
  return new Promise(async (res) => {
    sheet(`<div class="sbody"><div><h3>${t("Add a card")}</h3><div class="h-s" style="font-size:13px">${t("Your card is stored securely by Stripe. Chabad of Sampleton never sees your card number.")}</div></div>
      <div id="payEl" class="payel"><div class="h-s">${t("Loading…")}</div></div><div id="payErr" class="err" role="alert"></div></div>
      <div class="stick"><button class="btn btn-primary cta" id="paySave" disabled>${t("Save card")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button></div>`, (o) => $(".sheet", o).classList.add("split"), () => res(false));
    try {
      const { clientSecret } = await api("/setup-intent", { method: "POST" });
      const stripe = await loadStripe();
      const elements = stripe.elements({ clientSecret, appearance: { variables: { colorPrimary: "#b68235", colorText: "#201f1d", fontFamily: "Lora, Georgia, serif", borderRadius: "4px" } } });
      $("#payEl").innerHTML = ""; elements.create("payment", { layout: "tabs", wallets: { applePay: "auto", googlePay: "auto" } }).mount("#payEl");
      const btn = $("#paySave"); if (!btn) return; btn.disabled = false;
      btn.onclick = async () => {
        btn.disabled = true; $("#payErr").textContent = "";
        const { error } = await stripe.confirmSetup({ elements, redirect: "if_required", confirmParams: { payment_method_data: { billing_details: { name: S.name, email: S.email } } } });
        if (error) { $("#payErr").textContent = error.message; btn.disabled = false; return; }
        if (S.token) { try { await api("/payment-method/default", { method: "POST" }); } catch (e) {} } await refreshCard(); if (API.cardIssue) { API.cardIssue = ""; if (S.mtoken) api("/member/card-updated", { method: "POST", member: true }).catch(() => {}); } res(true); closeSheet(); toast(tt("Card saved")); draw();
      };
    } catch (e) { const el = $("#payErr"); if (el) el.textContent = errText(e); }
  });
}
async function removeCard() { try { await api("/payment-method", { method: "DELETE" }); API.card = null; toast(tt("Card removed")); } catch (e) { toast(errText(e)); } draw(); }
function failSheet(e, p) {
  sheet(`<div><h3>${t("We couldn’t complete your gift")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${esc(errText(e))}</div></div>
    <button class="btn btn-primary cta" id="retry">${t("Try again")}</button><button class="btn btn-secondary cta" id="swapCard">${t("Use a different card")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Close")}</button>`,
  (o) => { $("#retry", o).onclick = () => { closeSheet(); chargeFlow(p); }; $("#swapCard", o).onclick = async () => { closeSheet(); if (await addCard()) chargeFlow(p); }; });
}
async function chargeFlow(p) {
  if (U.busy) return;
  if (!API.card) { if (!(await addCard())) return; }
  U.busy = true;
  sheet(`<div class="done"><div class="spin" aria-hidden="true"></div><h3>${t("Processing your gift…")}</h3><div class="h-s">${t("Please don’t close this window.")}</div></div>`, null, null, true);
  try {
    const body = { amount: p.amt, fund: p.fund, dedication: p.ded || "", fee: !!p.fee, idem: uid() + uid() + uid() }; if (p.club) { body.club = p.club; body.replace = !!p.replace; }
    let r = await api(p.freq === "monthly" ? "/subscribe" : "/donate", { method: "POST", body });
    if (r.status === "requires_action") {
      const stripe = await loadStripe();
      const { error, paymentIntent } = await stripe.confirmCardPayment(r.clientSecret, { payment_method: r.paymentMethodId });
      if (error) throw Object.assign(new Error(error.message), { code: "card_error" });
      r = await api("/payment/" + paymentIntent.id);
    }
    if (r.status !== "succeeded" && r.status !== "active") throw Object.assign(new Error("Payment not completed"), { code: "card_error" });
    p.receiptUrl = r.receiptUrl || ""; U.busy = false; if (p.freq === "monthly") API.subs = null; if (p.club) U.club.data = null; completeGift(p);
  } catch (e) { U.busy = false; failSheet(e, p); }
}

// ---------- candle times & notifications ----------
async function loadCandles() {
  try {
    const j = await (await fetch(`https://www.hebcal.com/shabbat?cfg=json&zip=${CANDLE_ZIP}&M=on`)).json();
    S.candles = (j.items || []).filter((i) => i.category === "candles").map((i) => i.date); save(); if (U.page === "home") draw();
  } catch (e) {}
}
const nextCandle = () => (S.candles || []).map((d) => new Date(d)).filter((d) => d > Date.now()).sort((a, b) => a - b)[0];
async function ensureNotify() {
  if (!("Notification" in window)) { toast(tt("This browser can’t show notifications")); return false; }
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") { toast(tt("Notifications are blocked in your browser settings")); return false; }
  const ok = await new Promise((res) => { sheet(`<div class="done"><div class="ck" style="color:var(--accent)">${ico(I.bell, 24)}</div><h3>${t("Allow notifications")}</h3><div style="font-size:14px;max-width:280px">${t("Please allow notifications so we can send you reminders.")}</div></div><button class="btn btn-primary cta" id="nyes">${t("Confirm")}</button><button class="btn btn-ghost" id="nno">${t("Cancel")}</button>`, (o) => { $("#nyes", o).onclick = () => { res(true); closeSheet(); }; $("#nno", o).onclick = () => closeSheet(); }, () => res(false)); });
  return ok && (await Notification.requestPermission()) === "granted";
}
async function notify(body) {
  try {
    const reg = navigator.serviceWorker && (await navigator.serviceWorker.getRegistration());
    if (reg) reg.showNotification(tt("My Pushka"), { body, icon: "icon.svg", tag: "pushka" }); else new Notification(tt("My Pushka"), { body, icon: "icon.svg" });
  } catch (e) {}
}
function mark(k) { S.notified[k] = 1; const ks = Object.keys(S.notified); if (ks.length > 80) ks.slice(0, ks.length - 80).forEach((x) => delete S.notified[x]); save(); }
function tick() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const now = Date.now(), d = new Date(), at = (h, m) => new Date(d).setHours(h, m, 0, 0), within = (ts) => now >= ts && now < ts + 600e3;
  if (S.rem.candle.on && !S.pushOn) (S.candles || []).forEach((c) => { const ts = new Date(c) - S.rem.candle.mins * 60e3, k = "c" + c; if (within(ts) && !S.notified[k]) { mark(k); notify(tt("Candle lighting is in {mins} minutes — it’s customary to give tzedakah first.", { mins: S.rem.candle.mins })); } });
  if (S.rem.streak.on && !S.pushOn && !gaveToday()) {
    const candleDay = (S.candles || []).some((c) => dkey(new Date(c)) === dkey(d)), early = d.getDay() === 5 || candleDay, ts = early ? at(13, 0) : at(20, 0), k = "s" + dkey(d);
    if ((early || isWk(d)) && d.getDay() !== 6 && within(ts) && !S.notified[k]) { mark(k); notify(tt("Keep your streak alive — drop a coin in your pushka.")); }
  }
  dateTick(at, within);
  if (!S.pushOn) S.rem.custom.filter((r) => r.on).forEach((r) => {
    const [h, m] = r.time.split(":").map(Number), k = r.id + dkey(d), okDay = r.days === "once" ? r.date === ymdLocal(d) : HD.dayType(r.days, ymdLocal(d));
    if (okDay && within(at(h, m)) && !S.notified[k]) { mark(k); notify(r.text || tt("Time to give tzedakah!")); }
  });
}

// ---------- biometric lock (device passkey; local app lock) ----------
const b64 = (b) => btoa(String.fromCharCode(...new Uint8Array(b)));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function bioSupported() { try { return !!(window.PublicKeyCredential && (await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())); } catch (e) { return false; } }
async function bioEnable() {
  const cred = await navigator.credentials.create({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), rp: { name: "Chabad of Sampleton" }, user: { id: crypto.getRandomValues(new Uint8Array(16)), name: "pushka", displayName: "My Pushka" }, pubKeyCredParams: [{ type: "public-key", alg: -7 }, { type: "public-key", alg: -257 }], authenticatorSelection: { authenticatorAttachment: "platform", userVerification: "required" }, timeout: 60000 } });
  S.bio = b64(cred.rawId); save();
}
const bioUnlock = () => navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), allowCredentials: [{ type: "public-key", id: unb64(S.bio) }], userVerification: "required", timeout: 60000 } });
function showLock() { const el = $("#lock"); el.hidden = false; el.innerHTML = `<div class="lock-in"><span style="color:var(--accent)">${ico(I.lock, 40)}</span><h2>${t("My Pushka is locked")}</h2><button class="btn btn-primary" data-act="unlock" style="width:220px">${t("Unlock")}</button><button class="btn btn-ghost" data-act="resetApp">${t("Can’t unlock? Reset this app")}</button></div>`; }

// ---------- page chrome ----------
const TABS = [["home", "Pushka", I.home], ["give", "Give", I.give], ["wallet", "Wallet", I.wallet], ["history", "History", I.history], ["more", "More", I.more]];
const tabOf = (pg) => (["segulot", "segulah", "quotes", "building", "otherways", "club"].includes(pg) ? "give" : ["home", "give", "wallet", "history"].includes(pg) ? pg : "more");
const sub = (title, body) => `<div class="head sub"><button class="icon-btn" data-act="back" aria-label="${t("Back")}">${ico(I.back, 24, FLIP)}</button><h1>${esc(title)}</h1><span style="width:44px"></span></div><div class="scroll"><div class="col tight" style="padding-top:var(--s4)">${body}</div></div>`;
const chev = () => `<span style="color:var(--accent)">${ico(I.chev, 18, FLIP)}</span>`;
const rowLink = (act, v, icon, title, subt) => `<button class="row-btn" data-act="${act}" data-v="${esc(v)}"><span style="color:var(--accent);flex:none">${ico(icon, 22)}</span><div class="grow"><div class="fund-n">${esc(title)}</div>${subt ? `<div class="fund-d">${esc(subt)}</div>` : ""}</div>${chev()}</button>`;
const tg = (act, v, title, subt, on) => `<button class="row-btn" role="switch" aria-checked="${on}" data-act="${act}" data-v="${esc(v)}"><div class="grow"><div class="h-t">${title}</div>${subt ? `<div class="h-s">${subt}</div>` : ""}</div><div class="sw ${on ? "on" : ""}"></div></button>`;
const sec = (title) => `<h6 style="color:var(--n700);margin:var(--s3) 0 var(--s1)">${title}</h6>`;

// ---------- pages ----------
const PG = {};
const fracOf = (p) => (p.balance > 0 ? Math.max(Math.min(p.balance / S.goal, 1), 0.07) : 0);
const fillY = (f) => ((1 - f) * 124 + (f <= 0 ? 16 : 0)).toFixed(1);
// The logo is the file pushka/logo.svg: replace that file to change it everywhere.
const flameMark = (px) => `<img src="logo.svg" alt="" height="${px}" style="height:${px}px;width:auto;max-width:${Math.round(px * 1.4)}px;object-fit:contain;flex:none;filter:drop-shadow(0 0 6px rgba(120,210,255,.45))">`;
function tin(from) { // the pushka: a deep-blue tin with a brass nameplate for Chabad of Sampleton
  const name = LANG === "he" ? `<text x="123" y="225.2" text-anchor="middle" fill="#3a2504" style="font:700 10.5px 'Frank Ruhl Libre','Cormorant Garamond',Georgia,serif" direction="rtl">חב״ד סמפלטון</text>` : `<text x="70" y="224.4" textLength="112" lengthAdjust="spacingAndGlyphs" fill="#3a2504" style="font:700 8.6px 'Cormorant Garamond',Georgia,serif;letter-spacing:.9px">CHABAD OF SAMPLETON</text>`;
  return `<svg width="220" height="252" viewBox="0 0 220 252" fill="none" style="display:block" role="img" aria-label="${esc(tt("Chabad of Sampleton pushka"))}"><defs>
<linearGradient id="bf" x1="0" x2="1"><stop offset="0" stop-color="#12306a"/><stop offset=".18" stop-color="#2a5a9e"/><stop offset=".36" stop-color="#4378c0"/><stop offset=".68" stop-color="#244f8e"/><stop offset="1" stop-color="#0f2755"/></linearGradient>
<linearGradient id="bt" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#6a98d6"/><stop offset="1" stop-color="#2f5fa3"/></linearGradient>
<linearGradient id="gd" x1="0" x2="1"><stop offset="0" stop-color="#a06f24"/><stop offset=".4" stop-color="#facb8d"/><stop offset=".7" stop-color="#e6b955"/><stop offset="1" stop-color="#a06f24"/></linearGradient>
<linearGradient id="hl" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity=".28"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="sh" x1="0" x2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".3"/></linearGradient>
<linearGradient id="gl" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".34"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/></linearGradient>
<clipPath id="lbl"><rect x="46" y="84" width="128" height="120" rx="2"/></clipPath>
<linearGradient id="goldf" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#f7d56a"/><stop offset="1" stop-color="#c28d41"/></linearGradient>
<radialGradient id="rv" cx=".35" cy=".3"><stop offset="0" stop-color="#fff6d6"/><stop offset=".6" stop-color="#e6b955"/><stop offset="1" stop-color="#8a5d14"/></radialGradient>
<pattern id="coinp" width="16" height="11" patternUnits="userSpaceOnUse"><ellipse cx="8" cy="5.5" rx="5.5" ry="3.6" fill="none" stroke="#8a5d14" stroke-width=".7" opacity=".5"/></pattern></defs>
<ellipse cx="110" cy="238" rx="94" ry="9" fill="#000" opacity=".3"/>
<path d="M30 62H190V228Q190 232 186 232H34Q30 232 30 228Z" fill="url(#bf)"/>
<rect x="30" y="62" width="160" height="170" rx="4" fill="url(#hl)" opacity=".55"/><rect x="30" y="62" width="160" height="170" rx="4" fill="url(#sh)"/>
<path d="M30 62L46 38H174L190 62Z" fill="url(#bt)" stroke="#173766" stroke-width="1" stroke-linejoin="round"/>
<path d="M46 38H174" stroke="#9cc0ee" stroke-width="1.4" opacity=".8"/>
<path d="M30 62H190V70H30Z" fill="url(#gd)"/>
<g fill="url(#rv)" stroke="#6a4510" stroke-width=".4">${[40, 62, 84, 106, 128, 150, 172].map((x) => `<circle cx="${x}" cy="66" r="1.9"/>`).join("")}</g>
<path d="M30 208H190V228Q190 232 186 232H34Q30 232 30 228Z" fill="url(#gd)"/><path d="M30 208H190" stroke="#5a3b0a" stroke-width=".8" opacity=".6"/><path d="M30 209.2H190" stroke="#fff3c4" stroke-width=".7" opacity=".7"/>
<path d="M30 62H190V228Q190 232 186 232H34Q30 232 30 228Z" stroke="#0f2442" stroke-width="1"/>
<rect x="74" y="43.5" width="72" height="11" rx="5.5" fill="url(#gd)"/><rect x="78" y="46" width="64" height="7" rx="3.5" fill="#0b1b36"/><rect x="78" y="46" width="64" height="2.5" rx="1.2" fill="#000" opacity=".5"/>
<ellipse cx="124" cy="46.4" rx="11" ry="2.1" fill="#f6d77f"/><ellipse cx="124" cy="46.1" rx="9" ry="1.2" fill="#fff3c4" opacity=".8"/>
<rect x="44" y="82" width="132" height="124" rx="3" fill="#f8f4f4" stroke="url(#gd)" stroke-width="2.5"/>
<g clip-path="url(#lbl)"><g id="fillG" style="transform:translateY(${fillY(from)}px);transition:transform 1.1s cubic-bezier(.2,.8,.2,1) .5s">
<rect x="44" y="84" width="132" height="130" fill="url(#goldf)"/><rect x="44" y="84" width="132" height="130" fill="url(#coinp)"/>
<path d="M44 86 Q60.5 78 77 86 T110 86 T143 86 T176 86 V96 H44Z" fill="#ffe9a0" opacity=".9"/></g>
<path d="M46 84H174V120Q110 100 46 150Z" fill="url(#gl)"/></g>
<rect x="50" y="88" width="120" height="112" rx="1.5" stroke="#a06f24" stroke-width=".7"/>
<text x="110" y="122" text-anchor="middle" fill="#173766" style="font:600 38px 'Frank Ruhl Libre','Cormorant Garamond',Georgia,serif" direction="rtl">צדקה</text>
<g transform="translate(40,211)"><circle cx="10" cy="10" r="9.6" fill="#f8fbfd" stroke="#5a3b0a" stroke-width=".8"/><circle cx="10" cy="10" r="7.9" fill="none" stroke="#a06f24" stroke-width=".4" opacity=".7"/><image href="logo.svg" x="3.1" y="2.6" width="13.8" height="14.8" preserveAspectRatio="xMidYMid meet"/></g>
${name}</svg>`;
}
function animateFill() {
  const p = P(), g = $("#fillG"); if (!g) return;
  const f = fracOf(p), pct = Math.min(p.balance / S.goal, 1) * 100, pf = $("#progFill");
  U.fillFor = p.id; U.fillShown = f; U.pctShown = pct;
  requestAnimationFrame(() => requestAnimationFrame(() => { g.style.transform = `translateY(${fillY(f)}px)`; if (pf) pf.style.width = pct + "%"; }));
}
const hex = (n) => `<svg width="44" height="50" viewBox="0 0 46 52" fill="none" aria-hidden="true"><path d="M23 2l19 11v26L23 50 4 39V13z" stroke="var(--accent)" stroke-width="1.5" stroke-linejoin="round"/><text x="23" y="33" text-anchor="middle" fill="var(--a800)" style="font:600 20px 'Cormorant Garamond',Georgia,serif">${n}</text></svg>`;

PG.home = () => {
  if (S.kids.on) return PG.kidsHome();
  const p = P(), now = new Date(), c = nextCandle(), st = streak(), frac = Math.min(p.balance / S.goal, 1), shown = U.fillFor === p.id ? U.fillShown : 0, top = 82, bot = 206, lvl = bot - fracOf(p) * (bot - top), pct = Math.round(frac * 100), rest = Math.max(r2(S.goal - p.balance), 0);
  const progTxt = frac >= 1 ? t("Your pushka is full — empty it to give!") : pct >= 90 ? t("Almost full! {amt} to go", { amt: money2(rest) }) : t("{amt} of {goal} · {n}% full", { amt: money2(p.balance), goal: money(S.goal), n: pct });
  let reminder = "";
  if (c) {
    const title = c.getDay() === 5 ? tt("Shabbat candles Friday, {time}", { time: clock(c) }) : tt("Candle lighting {day}, {time}", { day: c.toLocaleDateString(loc(), { weekday: "long" }), time: clock(c) });
    const subt = S.rem.candle.on ? tt("It's customary to give before lighting. We'll remind you at {time}.", { time: clock(new Date(c - S.rem.candle.mins * 60e3)) }) : tt("It's customary to give before lighting. Turn on the reminder in Reminders.");
    reminder = `<div class="card">${ico(I.flame, 22, 'style="color:var(--accent);flex:none"')}<div style="flex:1"><div class="card-title">${esc(title)}</div><div class="h-s">${esc(subt)}</div></div></div>`;
  }
  reminder = cardIssueBanner() + yzBanner() + notifBanner() + nudgeBanner() + reminder;
  const chips = S.pushkas.length > 1 ? `<div class="chips">${S.pushkas.map((x) => `<button class="chip ${x.id === p.id ? "on" : ""}" data-act="setCur" data-v="${x.id}">${esc(pTitle(x))}</button>`).join("")}</div>` : "";
  const since = greg(new Date(S.lastEmptied));
  const msg = p.balance > 0 ? `<div class="h-t" style="font-size:20px">${t("Your pushka has {amt}", { amt: money2(p.balance) })}</div><div class="h-s">${p.drops === 1 ? t("1 coin since {date}", { date: esc(since) }) : t("{n} coins since {date}", { n: p.drops, date: esc(since) })}</div>` : `<div class="h-t" style="font-size:20px">${t("Your pushka is empty")}</div><div class="h-s">${t("Add some coins now")}</div>`;
  return `<div class="head home-head"><div class="hd-top"><div class="kicker" style="display:flex;align-items:center;gap:8px">${flameMark(28)}<span>${t("Chabad of Sampleton")}</span></div><div class="hd-tools"><button class="lang-btn" data-act="toggleLang" lang="${LANG === "he" ? "en" : "he"}">${LANG === "he" ? "English" : "עברית"}</button><button class="icon-btn sm" data-act="share" aria-label="${t("Share")}">${ico(I.share, 20)}</button></div></div><div class="hd-main"><h1>${esc(pTitle(p))}</h1><div class="dates"><div>${esc(greg(now))}</div><i>${esc(hebFull(now))}</i></div></div></div>
  <div class="scroll"><div class="col">${chips}
    ${seasonOrn(season())}<div class="streak">${hex(st)}<span>${t("Weekday streak")}</span>${st >= 3 ? `<button class="link" data-act="shareStreak">${t("Share")}</button>` : ""}</div>${weekStrip()}
    <div class="msg">${msg}</div>
    <div class="tin"><div class="anchor" id="coinAnchor"></div><div class="zoom"><div class="wrap ${pct >= 90 ? "glow" : ""}" data-act="dropPrimary" role="button" tabindex="0" aria-label="${esc(tt("Drop {amt} in the pushka", { amt: money(S.presets[0]) }))}">${tin(shown)}<div class="bal">${money2(p.balance)}</div></div></div></div>
    <div class="progress"><div class="pg-track"><div class="pg-fill" id="progFill" style="width:${(U.fillFor === p.id ? U.pctShown : 0)}%"></div></div><div class="pg-t">${progTxt}</div></div>
    ${familyChips()}<div><div class="tap">${t("Tap to drop a coin")}</div><div class="quick">${S.presets.map((a) => `<button class="btn btn-secondary" data-act="drop" data-v="${a}">${money(a)}</button>`).join("")}<button class="btn btn-secondary" data-act="other">${t("Other")}</button></div></div>
    <button class="btn btn-primary cta" data-act="openEmpty" ${p.balance <= 0 ? "disabled" : ""}>${t("Empty pushka to Chabad")}</button>
    <button class="btn btn-honor cta" data-act="why">${ico(I.give, 20)} ${t("Donate in honor or in memory of a loved one")}</button>
    <div class="row2"><button class="btn btn-ghost" data-act="donateNow">${t("Donate now")}</button><button class="btn btn-ghost" data-act="go" data-v="settings">${ico(I.gear, 16)} ${t("Pushka settings")}</button></div>
    ${annCards()}${boardCard()}${commCard()}${todayCard()}${occasionCard()}
    ${reminder}
  </div></div>`;
};

const TAXNOTE = () => `<p class="note">${t("Chabad of Sampleton is a {c3} nonprofit, Tax ID {ein}. 100% of the proceeds of your gift benefit Chabad of Sampleton.", { c3: C3_HTML, ein: EIN_HTML })}</p>`;
const withFee = (a) => Math.round(Math.round(a * 100) * (1 + FEE_RATE)) / 100;
const feeOn = () => API.enabled && S.coverFee;
const totalOf = (a) => (feeOn() ? withFee(a) : a);
const feeBox = () => (API.enabled ? `<label class="chk"><input type="checkbox" data-chg="fee" ${S.coverFee ? "checked" : ""}><span>${t("Cover the processing fee (3.5%)")}</span></label>` : "");
const giveCtaText = () => (U.freq === "monthly" ? t("Give {amt} monthly", { amt: money(totalOf(U.giveAmt)) }) : t("Give {amt}", { amt: money(totalOf(U.giveAmt)) }));
PG.give = () => {
  if (!U.giveFund) return `<div class="scroll" style="padding-top:calc(var(--s3) + env(safe-area-inset-top))"><div class="col" style="padding-top:0"><div class="page-h"><h1>${t("Give")}</h1><div class="sub">${t("A direct gift to Chabad of Sampleton.")}</div></div>
    <button class="row-btn club-row" data-act="go" data-v="club"><span style="flex:none;display:flex;gap:2px">${["bronze", "silver", "gold", "platinum"].map((m) => medalSvg(m, 20)).join("")}</span><div class="grow"><div class="fund-n">${t("Chai Club")}</div><div class="fund-d">${t("Bronze, Silver, Gold and Platinum. Join the honor board.")}</div></div>${chev()}</button>
    ${sec(t("Give to a fund"))}<div>${FUNDS.filter((f) => f.id !== "chai").map((f) => `<button class="row-btn" data-act="fund" data-v="${f.id}"><div class="grow"><div class="fund-n">${t(f.name)}</div>${f.desc ? `<div class="fund-d">${t(f.desc)}</div>` : ""}</div>${chev()}</button>`).join("")}</div>
    ${FEATURES.building ? `${sec(t("Building Campaign"))}<div>${rowLink("go", "building", I.home, tt("Center for Jewish Life"), tt("Giving levels and the Wall of Honor"))}</div>` : ""}
    ${sec(t("Sponsorships"))}<div>${SPONSORS.filter(([id]) => id !== "kiddush" || FEATURES.kiddush).map(([id, name]) => rowLink("sponsor", id, I.flame, tt(name), id === "kiddush" ? tt("See the open Shabbosos and choose one") : "")).join("")}</div>
    ${sec(t("Give for a segulah"))}<div>${rowLink("go", "segulot", I.book, tt("Segulot & Prayers"), tt("Choose a segulah and how much to give"))}</div>
    ${sec(t("Other ways to give"))}<div>${rowLink("go", "otherways", I.card, tt("Zelle, Venmo, check, stock and more"), "")}</div>${TAXNOTE()}</div></div>`;
  const f = fundOf(U.giveFund);
  return `<div class="scroll" style="padding-top:calc(var(--s3) + env(safe-area-inset-top))"><div class="col tight" style="padding-top:0">
    <button class="btn btn-ghost" data-act="allFunds" style="align-self:flex-start;padding-inline-start:0">${ico(I.back, 16, FLIP)}${t("All funds")}</button>
    <div class="page-h"><div class="kicker">${t("Give to")}</div><h2 style="margin:2px 0 4px">${t(f.name)}</h2><p style="margin:0;font-size:13px;text-align:justify;color:var(--n800)">${t(f.long)}</p></div>
    <div class="field"><label>${t("Amount")}</label><div class="amts three">${GIVE_AMTS.map((a) => `<button class="btn btn-secondary ${U.giveAmt === a ? "sel" : ""}" data-act="amt" data-v="${a}">${money(a)}</button>`).join("")}</div>
      <input class="input" id="giveCustom" data-inp="giveCustom" type="number" min="1" step="0.01" inputmode="decimal" aria-label="${t("Other amount")}" placeholder="${t("Other amount")}" style="margin-top:6px"></div>
    <div class="field"><label>${t("Frequency")}</label><div class="seg"><label><input type="radio" name="freq" value="once" data-chg="freq" ${U.freq === "once" ? "checked" : ""}>${t("One time")}</label><label><input type="radio" name="freq" value="monthly" data-chg="freq" ${U.freq === "monthly" ? "checked" : ""}>${t("Monthly")}</label></div></div>
    <div class="field"><label for="ded">${t("Dedication or note (optional)")}</label><input class="input" id="ded" data-inp="ded" maxlength="80" placeholder="${t("In honor of / in memory of…")}" value="${esc(U.dedication)}"></div>
    ${feeBox()}
    <div class="h-s" style="display:flex;align-items:center;gap:8px;font-size:13px">${ico(I.card, 16)}${API.enabled ? (API.card ? esc(cardLabel()) + ` <button class="link" data-act="cardChange">${t("Change")}</button>` : t("You’ll add a card when you give")) : t("Payment completes on our secure donation page")}</div>
    <button class="btn btn-primary cta" id="giveCta" data-act="submitGive">${giveCtaText()}</button>${TAXNOTE()}</div></div>`;
};

// ----- building campaign & other ways to give -----
PG.building = () => sub(tt("Building Campaign"), `<p class="body-p">${t("Chabad of Sampleton is building a new Center for Jewish Life at 100 Sample Street in Brookfield: a synagogue, event space, Hebrew school and preschool classrooms, a kosher market and a commercial kitchen, with a mikvah and more floors planned for later phases.")}</p>
  ${sec(t("Giving levels"))}<div>${LEVELS.map(([n, a]) => `<button class="row-btn" data-act="level" data-v="${n}"><div class="grow"><div class="fund-n">${t(n)}</div></div><div class="h-a">${money(a)}</div>${chev()}</button>`).join("")}</div>
  <p class="note">${t("Gifts are recognized on the Wall of Honor. Larger gifts can also be made by check, wire, stock or crypto.")}</p>
  <a class="btn btn-secondary cta" href="${BUILD_URL}" target="_blank" rel="noopener">${t("Learn more about the campaign")}</a>${TAXNOTE()}`);
PG.otherways = () => sub(tt("Other ways to give"), `<div>${WAYS().map(([id, name, ic]) => rowLink("way", id, ic, tt(name), "")).join("")}</div><div class="card" style="flex-direction:column;align-items:flex-start;gap:4px"><div class="card-title">${t("Chabad of Sampleton")}</div><a href="tel:${ORG_PHONE.replace(/-/g, "")}" dir="ltr">${ORG_PHONE}</a><a href="mailto:${SITE_EMAIL}">${SITE_EMAIL}</a><span dir="ltr">${esc(ORG_ADDR)}</span></div>${TAXNOTE()}`);
function waysHtml(id) {
  const ein = EIN_HTML, copy = (v) => `<button class="btn btn-ghost" data-act="copy" data-v="${esc(v)}">${t("Copy")}</button>`, link = (u, l) => `<a class="btn btn-secondary cta" href="${esc(u)}" target="_blank" rel="noopener">${l}</a>`;
  return ({
    zelle: ZELLE_EMAIL ? `<p>${t("Send your gift by Zelle to:")}</p><div class="card"><b dir="ltr" style="flex:1">${esc(ZELLE_EMAIL)}</b>${copy(ZELLE_EMAIL)}</div>` : `<p>${t("Send your gift by Zelle to the address shown on our donation page, or ask us for it.")}</p>${link(SITE + "/donate#zelle", t("Open our donation page"))}`,
    venmo: `<p>${t("Send your gift on Venmo to:")}</p><div class="card"><b dir="ltr" style="flex:1">@${VENMO}</b>${copy("@" + VENMO)}</div>${link("https://venmo.com/u/" + VENMO, t("Open Venmo"))}`,
    daf: `<p>${t("Recommend a grant from your donor advised fund to Chabad of Sampleton (Tax ID {ein}).", { ein })}</p><div class="card"><span dir="ltr" style="flex:1">${esc(ORG_ADDR)}</span>${copy(ORG_ADDR)}</div>`,
    check: `<p>${t("Make your check payable to Chabad of Sampleton and mail it to:")}</p><div class="card"><span dir="ltr" style="flex:1">${esc(ORG_ADDR)}</span>${copy(ORG_ADDR)}</div>`,
    wire: `<p>${t("Call or email us for wire and ACH details.")}</p>`,
    stock: `<p>${t("Donate stock securely through our StockDonator page.")}</p>${link(STOCK_URL, t("Donate stock"))}`,
    crypto: `<p>${t("Cryptocurrency gifts are welcome. See our page for details, or call us.")}</p>${link(CRYPTO_URL, t("Donate cryptocurrency"))}`,
  })[id] || "";
}
const contactBtns = (subject) => `<div class="row2"><a class="btn btn-ghost" href="tel:${ORG_PHONE.replace(/-/g, "")}" dir="ltr">${ORG_PHONE}</a><a class="btn btn-ghost" href="mailto:${SITE_EMAIL}?subject=${encodeURIComponent(subject)}">${t("Email us")}</a></div>`;


PG.wallet = () => `<div class="scroll" style="padding-top:calc(var(--s3) + env(safe-area-inset-top))"><div class="col" style="padding-top:0">
  <div class="page-h"><h1>${t("Wallet")}</h1><div class="sub">${t("Set aside funds now for emptying your pushka later.")} <button class="link" data-act="walletLearn">${t("Learn more")}</button></div></div>
  <div class="card" style="flex-direction:column;align-items:center;gap:4px;padding:var(--s4)"><div class="h-s" style="text-transform:uppercase;letter-spacing:.1em;font-size:11px">${t("Your Wallet ID")}</div><div style="font:400 34px var(--heading);letter-spacing:.18em;color:var(--a700);font-feature-settings:'tnum';direction:ltr">${esc(S.wallet.id)}</div></div>
  <div style="text-align:center"><div class="h-s" style="text-transform:uppercase;letter-spacing:.1em;font-size:11px">${t("Balance")}</div><div style="font:400 56px/1.1 var(--heading);font-feature-settings:'tnum'">${money2(S.wallet.balance)}</div></div>
  <button class="btn btn-secondary cta" data-act="addFunds">${ico(I.plus, 16)} ${t("Add funds")}</button>
  <div>${rowLink("walletSend", "", I.swap, tt("Send / request between wallets"), tt("Empower friends and family with giving tzedakah"))}${rowLink("autoRefill", "", I.gear, tt("Manage wallet auto refill"), tt("Auto refill inactive"))}${rowLink("walletHist", "", I.file, tt("Wallet transaction history"), "")}</div>
  <p class="note">${t("Wallet features are coming soon.")}</p>
</div></div>`;

function histTitle(h) { if (h.title) return h.title; if (h.kind === "coin") return h.why ? (typeof h.why === "object" ? tt(h.why.k === "memory" ? "Coin in memory of {name}" : "Coin in honor of {name}", { name: h.why.name }) : tt("Coin for {why}", { why: tt(h.why) })) : tt(h.ttl === "maaser" ? "Maaser added" : h.ttl === "auto" ? "Daily auto-coin" : "Coin dropped"); return (h.fp ? tt("Pushka emptied →") + " " : "") + tt(fundOf(h.fund).name); }
function histMeta(h) {
  if (h.kind === "coin") return h.by ? tt("by {name}", { name: h.by }) : "";
  if (h.kind === "gift" && h.fund) { const a = []; if (h.freq === "monthly") a.push(tt("Monthly")); else if (!h.fp) a.push(tt("One time")); if (h.method && h.method !== "online") a.push(tt(METHOD[h.method]) + " (" + tt("pending") + ")"); if (h.fee) a.push(tt("incl. processing fee")); if (h.ded) a.push(h.ded); return a.join(" · "); }
  return h.meta || "";
}
PG.history = () => {
  const yr = hebYearNum(new Date()), total = S.history.filter((h) => h.kind === "gift" && hebYearNum(new Date(h.t)) === yr).reduce((a, h) => a + h.amt, 0);
  const pn = (id) => { const x = S.pushkas.find((q) => q.id === id); return x ? pTitle(x) : ""; };
  const rows = S.history.length ? S.history.map((h) => `<div class="row-btn" style="cursor:default"><div class="grow"><div class="h-t">${esc(histTitle(h))}</div><div class="h-s">${esc(when(h.t))}${histMeta(h) ? " · " + esc(histMeta(h)) : ""}${h.kind === "coin" && S.pushkas.length > 1 && pn(h.pid) ? " · " + esc(pn(h.pid)) : ""}</div></div><div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px"><div class="h-a">${money2(h.amt)}</div>${h.kind === "coin" && h.t > S.lastEmptied ? `<button class="link" data-act="undoCoin" data-v="${h.t}">${t("Undo")}</button>` : ""}${h.receiptUrl ? `<a class="tag-accent" href="${esc(h.receiptUrl)}" target="_blank" rel="noopener">${t("Receipt")}</a>` : h.receipt ? `<span class="tag-accent">${t("Receipt")}</span>` : ""}</div></div>`).join("") : `<div class="rowp">${t("Nothing yet. Drop your first coin on the Pushka tab.")}</div>`;
  return `<div class="scroll" style="padding-top:calc(var(--s3) + env(safe-area-inset-top))"><div class="col tight" style="padding-top:0">
    <div class="page-h" style="display:flex;justify-content:space-between;align-items:flex-end"><h1>${t("History")}</h1><div class="year"><div class="k">${t("Given in {year}", { year: esc(hebYearLabel(new Date())) })}</div><div class="v">${money2(total)}</div></div></div>
    <div>${rows}</div><button class="btn btn-secondary cta" data-act="go" data-v="statement">${t("Giving statement")}</button><p class="note">${t("Coins in your pushka are given when you empty it.")} ${API.enabled ? t("A receipt is emailed for every gift.") : t("Your receipt comes from our donation page after each gift.")}</p></div></div>`;
};

PG.more = () => `<div class="scroll" style="padding-top:calc(var(--s3) + env(safe-area-inset-top))"><div class="col" style="padding-top:0"><div class="page-h"><h1>${t("More")}</h1></div><div>
  ${rowLink("go", "maaser", I.calc, tt("Maaser Calculator"), tt("Calculate your tenth"))}${rowLink("go", "reminders", I.bell, tt("Reminders"), tt("Candle lighting and daily coin"))}${rowLink("go", "yahrzeit", I.flame, tt("Yahrzeits"), tt("Remember loved ones and give in their memory"))}
  ${rowLink("go", "board", I.home, tt("Chai Club honor board"), tt("Our monthly donors"))}${rowLink("go", "occasions", I.flame, tt("Birthdays and anniversaries"), tt("Give in honor of people you love"))}${rowLink("go", "awards", I.flame, tt("Achievements"), tt("Badges, streaks and your giving"))}${rowLink("go", "cards", I.card, tt("Payment method"), tt("Change or remove your card"))}${rowLink("go", "settings", I.gear, tt("Settings"), tt("Goal, amounts, sounds, pushkas, language"))}${rowLink("go", "profile", I.profile, tt("Profile"), S.name || tt("Name, email, address"))}${rowLink("go", "support", I.help, tt("Support"), tt("We’re happy to help"))}</div>
  <a class="btn btn-ghost" href="${SITE}" target="_blank" rel="noopener" style="align-self:flex-start;padding-inline-start:0">${ico(I.back, 16, FLIP)} ${t("Back to sample-chabad.org")}</a></div></div>`;

// ----- segulos -----
const segFeat = () => SEG_FEATURED.map((id) => SEGULOS.find((s) => s.id === id));
const segHit = (raw) => { const s = SG(raw), q = U.segQ.trim().toLowerCase(); return (!q || (s.title + " " + s.blurb + " " + catL(raw.cat)).toLowerCase().includes(q)) && (U.segCat === "All" || raw.cat === U.segCat); };
const segRow = (raw, showCat) => { const s = SG(raw), q = raw.kind === "quotes"; return `<div class="row-btn seg-row"><button class="grow seg-main" data-act="seg" data-v="${raw.id}"><div class="fund-n">${esc(s.title)}</div>${showCat ? `<div class="kicker" style="margin-top:2px">${esc(catL(raw.cat))}</div>` : ""}<div class="fund-d clamp">${esc(s.blurb)}</div></button>${q ? chev() : `<button class="btn btn-secondary seg-give" data-act="segGive" data-v="${raw.id}" aria-label="${esc(tt("Give for {name}", { name: s.title }))}">${t("Give")}</button>`}</div>`; };
function segList() {
  if (U.segQ.trim() || U.segCat !== "All") { const l = SEGULOS.filter(segHit); return l.length ? l.map((s) => segRow(s, true)).join("") : `<div class="rowp">${t("No matches. Try another word.")}</div>`; }
  return `<div>${segFeat().map((s) => segRow(s, false)).join("")}</div>` + SEG_CATS.map((c) => `<h6 style="color:var(--n700);margin:var(--s4) 0 var(--s1)">${esc(catL(c))}</h6>${SEGULOS.filter((s) => s.cat === c && !SEG_FEATURED.includes(s.id)).map((s) => segRow(s, false)).join("")}`).join("");
}
const segChips = () => ["All", ...SEG_CATS].map((c) => `<button class="chip ${U.segCat === c ? "on" : ""}" data-act="segCat" data-v="${esc(c)}">${c === "All" ? t("All") : esc(catL(c))}</button>`).join("");
PG.segulot = () => sub(tt("Segulot & Prayers"), `<div class="field"><input class="input" id="segQ" data-inp="segQ" type="search" placeholder="${esc(tt("Search {n} segulos…", { n: SEGULOS.length }))}" aria-label="${t("Search segulos")}" value="${esc(U.segQ)}"></div>
  <div class="chips" id="segChips">${segChips()}</div><div id="segList">${segList()}</div>
  <p class="note">${t("Segulos are traditional customs and sources of inspiration, not guarantees. For questions of Jewish law, ask the Rabbi. Texts are provided for convenience.")}</p>`);
PG.segulah = () => {
  const raw = SEGULOS.find((x) => x.id === U.segId) || SEGULOS[0];
  if (raw.kind === "quotes") return PG.quotes();
  const s = SG(raw);
  const acts = `<button class="btn btn-primary cta" data-act="segGive" data-v="${raw.id}">${t("Give for this segulah")}</button>` + (raw.act || []).map((a) => ({
    coin: `<button class="btn btn-secondary cta" data-act="dropPrimary">${t("Drop a coin in my pushka")}</button>`,
    give: "",
    maaser: `<button class="btn btn-primary cta" data-act="go" data-v="maaser">${t("Open the Maaser Calculator")}</button>`,
    reminders: `<button class="btn btn-secondary cta" data-act="go" data-v="reminders">${t("Set a reminder")}</button>`,
  }[a] || "")).join("");
  let teh = "", links = raw.links || [];
  if (raw.kind === "tehillim") { const th = tehillimToday(); teh = `<div class="card" style="flex-direction:column;align-items:flex-start"><div class="kicker">${t("Hebrew day {n} of the month", { n: th.day })}</div><div class="card-title" style="font-size:24px">${esc(th.label)}</div><div class="h-s">${t("The Hebrew date changes at nightfall; this uses today’s calendar date.")}</div></div>`; links = th.links; }
  return sub(s.title, `<div class="kicker">${esc(catL(raw.cat))}</div>${teh}<p class="body-p">${nl(s.blurb)}</p>
    ${s.how ? `<h6 style="color:var(--n700)">${t("How")}</h6><ol class="how">${s.how.map((h) => `<li>${esc(h)}</li>`).join("")}</ol>` : ""}
    ${raw.he ? `<div class="hebrew" dir="rtl" lang="he">${nl(raw.he)}</div>` : ""}${s.tr ? `<div class="tr">${esc(s.tr)}</div>` : ""}${s.en ? `<blockquote>${nl(s.en)}</blockquote>` : ""}
    ${s.src ? `<div class="src">${t("Source: {src}", { src: esc(s.src) })}</div>` : ""}
    ${links.length ? `<div class="chips wrapchips">${links.map((l) => `<a class="chip" href="${esc(l.u)}" target="_blank" rel="noopener">${esc(linkText(l.t))} ${ico(I.ext, 12)}</a>`).join("")}</div>` : ""}${acts}`);
};
PG.quotes = () => sub(tt("Selected Quotes from the Rebbe"), `<p class="note">${t("Paraphrased teachings and sayings, shared for inspiration. Please check exact wording against the Rebbe’s own words and sources.")}</p>${QUOTES().map((q) => `<blockquote class="big"><p>“${esc(q.q)}”</p><footer>${esc(q.n)}</footer></blockquote>`).join("")}<button class="btn btn-primary cta" data-act="dropPrimary">${t("Drop a coin in my pushka")}</button>`);

// ----- maaser -----
const maaserOut = () => { const a = parseFloat(U.maaserAmt) || 0; return r2((a * S.maaser) / 100); };
PG.maaser = () => sub(tt("Maaser Calculator"), `<div class="field"><label for="maa">${t("Enter amount")}</label><div class="amt"><span>$</span><input class="input" id="maa" data-inp="maaserAmt" type="number" min="0" step="0.01" inputmode="decimal" placeholder="${t("Income or profit")}" value="${esc(U.maaserAmt)}"></div></div>
  <div class="card" style="flex-direction:column;align-items:stretch;gap:var(--s2)"><div style="display:flex;justify-content:space-between;align-items:center"><div class="kicker" style="color:var(--n700)">${t("Maaser percentage")}</div><span class="tag-accent" id="maaPct" style="font-size:14px;padding:2px 12px">${S.maaser}%</span></div>
    <input type="range" id="maaRange" data-inp="maaserPct" data-chg="maaserSave" min="1" max="20" step="1" value="${S.maaser}" aria-label="${t("Maaser percentage")}"><div style="display:flex;justify-content:space-between" class="h-s"><span>1%</span><span>10%</span><span>20%</span></div></div>
  <div class="card" style="flex-direction:column;gap:2px;padding:var(--s4)"><div class="h-s">${t("Maaser amount")}</div><div id="maaOut" style="font:400 48px var(--heading);font-feature-settings:'tnum'">${money2(maaserOut())}</div></div>
  <button class="btn btn-secondary cta maaBtn" data-act="maaserPushka" ${maaserOut() > 0 ? "" : "disabled"}>${t("Add to pushka")}</button>
  <button class="btn btn-secondary cta maaBtn" data-act="maaserWallet" ${maaserOut() > 0 ? "" : "disabled"}>${t("Add to wallet")}</button>
  <button class="btn btn-primary cta maaBtn" data-act="maaserDonate" ${maaserOut() > 0 ? "" : "disabled"}>${t("Donate now")}</button>
  <p class="note">${t("Maaser (a tenth of income) is a traditional guideline; some give up to a fifth. Ask the Rabbi how it applies to your situation.")}</p>`);

// ----- reminders -----
const DAYS = { weekdays: "Weekdays", daily: "Every day", friday: "Fridays", roshchodesh: "Rosh Chodesh", chai: "18th of the Hebrew month", erevrc: "Erev Rosh Chodesh", prefast: "Evening before a fast day", once: "Once" };
const SUGG = [
  ["morning", "Good morning coin", "Start your day with a coin for tzedakah.", "daily", "08:00"],
  ["tehillim", "Today’s Tehillim", "Today’s Tehillim is waiting for you. Open the app to read it.", "daily", "07:00"],
  ["grateful", "Evening gratitude", "What are you grateful for today? Drop a coin to say thank you.", "daily", "21:00"],
  ["kids", "Friday coin with the kids", "Let the kids drop the coin in the pushka before Shabbat.", "friday", "10:00"],
  ["rc", "Rosh Chodesh", "Today is Rosh Chodesh, a good day to give.", "roshchodesh", "09:00"],
  ["morning2", "Morning blessing coin", "A coin with your morning blessings sets the tone for the day.", "daily", "07:30"],
  ["erc", "Erev Rosh Chodesh", "Tomorrow is Rosh Chodesh. A good moment for a coin.", "erevrc", "18:00"],
  ["fast", "Before a fast day", "Tomorrow is a fast day. Give tzedakah today.", "prefast", "18:00"],
  ["chai", "Chai day", "Chai! The 18th of the Hebrew month. Give $18 for life.", "chai", "09:00"],
];
PG.reminders = () => {
  const c = S.rem.candle, st = S.rem.streak;
  return sub(tt("Reminders"), `<div>
    <div class="row-btn"><button class="grow" data-act="candleMins" style="all:unset;cursor:pointer;flex:1"><div class="h-t">${t("Before Candle Lighting")}</div><div class="h-s">${t("Friday & Holidays · {mins} mins before", { mins: c.mins })}</div></button><button role="switch" aria-checked="${c.on}" aria-label="${t("Before Candle Lighting")}" data-act="remToggle" data-v="candle" style="all:unset;cursor:pointer"><div class="sw ${c.on ? "on" : ""}"></div></button></div>
    ${tg("remToggle", "streak", t("Streak Reminder"), `${t("Weekdays · 8:00 pm")}<br>${t("Every Friday & before holidays · 1:00 pm")}`, st.on)}
    ${S.rem.custom.map((r) => `<div class="row-btn"><div class="grow"><div class="h-t">${esc(r.text || tt("Give tzedakah"))}</div><div class="h-s">${t(DAYS[r.days])} · ${esc(clock(new Date("2000-01-01T" + r.time)))}</div></div><button class="icon-btn sm" data-act="remDel" data-v="${r.id}" aria-label="${t("Delete reminder")}">${ico(I.trash, 18)}</button><button role="switch" aria-checked="${r.on}" aria-label="${t("Reminder on")}" data-act="remToggle" data-v="${r.id}" style="all:unset;cursor:pointer"><div class="sw ${r.on ? "on" : ""}"></div></button></div>`).join("")}</div>
    <button class="btn btn-secondary cta" data-act="addRem">${ico(I.plus, 16)} ${t("Add reminder")}</button>
    <button class="btn btn-secondary cta" data-act="travel">${t("Traveling soon?")}</button>
    ${rowLink("go", "occasions", I.flame, tt("Birthdays and anniversaries"), tt("Give in honor of people you love"))}
    ${sec(t("Suggested reminders"))}<div>${SUGG.filter((x) => !S.rem.custom.some((r) => r.sid === x[0])).map((x) => `<div class="row-btn"><div class="grow"><div class="h-t">${t(x[1])}</div><div class="h-s">${t(x[2])}</div><div class="h-s">${t(DAYS[x[3]])} · ${esc(clock(new Date("2000-01-01T" + x[4])))}</div></div><button class="btn btn-secondary" data-act="remSuggest" data-v="${x[0]}">${t("Add")}</button></div>`).join("") || `<div class="rowp">${t("You’ve added all the suggestions. Thank you!")}</div>`}</div>
    ${pushCard()}${pushOk() && S.pushOn ? `<div>${tg("weeklyTgl", "", t("Sunday summary"), t("A short note each Sunday about your week of giving."), S.rem.weekly.on)}</div>` : ""}
    <p class="note">${t("Reminders arrive while the app is open or installed on your home screen. Candle times are for Brookfield, ST.")}</p>`);
};

// ----- settings & profile -----
PG.settings = () => sub(tt("Settings"), `${sec(t("Payment"))}<div>${rowLink("go", "cards", I.card, tt("Payment method"), PRACTICE ? tt("Practice mode") : API.enabled ? (API.card ? cardLabel() : tt("No card saved")) : tt("Not switched on yet"))}</div>${sec(t("Pushka"))}
  <div class="field"><label for="goal">${t("Pushka goal")}</label><div class="amt"><span>$</span><input class="input" id="goal" type="number" min="1" step="0.01" inputmode="decimal" data-chg="setGoal" value="${S.goal.toFixed(2)}"></div></div>
  <div class="field"><label>${t("Preset amounts")}</label><div class="row3">${S.presets.map((a, i) => `<div class="amt">${i === 0 ? `<b class="primary-tag">${t("Primary")}</b>` : ""}<span>$</span><input class="input" type="number" min="0.01" step="0.01" inputmode="decimal" aria-label="${esc(tt("Preset {n}", { n: i + 1 }))}" data-chg="setPreset" data-i="${i}" value="${a.toFixed(2)}"></div>`).join("")}</div></div>
  <div class="field"><label for="emp">${t("Empty pushka")}</label><select class="input" id="emp" data-chg="setEmpty">${Object.entries(EMPTY_MODES).map(([k, v]) => `<option value="${k}" ${S.emptyMode === k ? "selected" : ""}>${t(v)}</option>`).join("")}</select></div>
  <button class="btn btn-secondary cta" data-act="resetAsk" data-v="${esc(P().id)}">${t("Reset this pushka")}</button>
  <div class="field"><label for="lng">${t("Language")}</label><select class="input" id="lng" data-chg="setLang"><option value="en" ${LANG === "en" ? "selected" : ""}>English</option><option value="he" ${LANG === "he" ? "selected" : ""}>עברית</option></select></div>
  <div>${tg("tgl", "sound", t("Sound"), t("Coin clink when you drop a coin"), S.sound)}${tg("tgl", "jingle", t("Coin jingle"), t("A shower of coins when you empty the pushka"), S.jingle)}${tg("tgl", "confetti", t("Confetti sound"), t("A celebration when your goal is reached"), S.confetti)}${tg("tgl", "vibrate", t("Vibration"), "", S.vibrate)}${tg("tgl", "partial", t("Partial payments"), t("Give part of your pushka and keep the rest"), S.partial)}${tg("tgl", "addl", t("Additional payment options"), t("Including check, wire, DAF"), S.addl)}${tg("bio", "", t("Biometric lock"), t("Unlock the app with your fingerprint, face or screen lock"), !!S.bio)}</div>
  ${sec(t("Sound"))}<div class="field"><label for="snd">${t("Coin sound")}</label><select class="input" id="snd" data-chg="setSnd">${[["classic", "Classic clink"], ["chime", "Soft chime"], ["soft", "Gentle tap"]].map(([k, l]) => `<option value="${k}" ${S.snd === k ? "selected" : ""}>${t(l)}</option>`).join("")}</select></div>
  <div>${tg("tgl", "seasonal", t("Holiday decorations"), t("The home screen glows with the season, like the Chanukah menorah."), S.seasonal)}</div>
  ${sec(t("Family"))}<div>${S.family.map((n) => `<div class="row-btn" style="cursor:default"><div class="grow h-t">${esc(n)}</div><button class="icon-btn sm" data-act="famDel" data-v="${esc(n)}" aria-label="${t("Delete")}">${ico(I.trash, 18)}</button></div>`).join("")}</div><button class="btn btn-secondary cta" data-act="famAdd">${ico(I.plus, 16)} ${t("Add a family member")}</button><div class="h-s">${t("Tap a name on the home screen to say whose coin it is.")}</div>
  ${sec(t("Kids mode"))}<div>${rowLink("kidsOn", "", I.lock, tt("Kids mode"), tt("Big coins and stickers, protected by a grown-up code"))}</div>
  ${sec(t("Daily auto-coin"))}<div>${tg("autoTgl", "", t("Add a coin every day"), t("A small daily habit: the pushka fills by itself, and you decide when to empty it."), S.auto.on)}</div>${S.auto.on ? `<div class="field"><label for="autoA">${t("Amount per day")}</label><div class="amt"><span>$</span><input class="input" id="autoA" type="number" min="0.01" step="0.01" inputmode="decimal" data-chg="autoAmt" value="${S.auto.amt.toFixed(2)}"></div></div>` : ""}
  ${sec(t("My pushkas"))}<div>${S.pushkas.map((p) => `<button class="row-btn" data-act="editPushka" data-v="${p.id}"><span style="color:var(--accent);flex:none">${ico(I.home, 22)}</span><div class="grow"><div class="fund-n">${esc(pTitle(p))}</div><div class="fund-d">${money2(p.balance)}${p.id === S.cur ? " · " + t("current") : ""}</div></div><span style="color:var(--accent)">${ico(I.pencil, 16)}</span></button>`).join("")}</div>
  <button class="btn btn-secondary cta" data-act="addPushka">${ico(I.plus, 16)} ${t("Add pushka")}</button>
  ${sec(t("Practice mode"))}<div>${tg("pracToggle", "", t("Practice mode"), t("Try the app without real money. Practice data is kept separate and can be cleared anytime."), PRACTICE)}</div>${PRACTICE ? `<button class="btn btn-secondary cta" data-act="pClear">${t("Clear practice data")}</button>` : ""}
  ${sec(t("Profile"))}<div>${rowLink("go", "profile", I.profile, S.name || tt("Your profile"), S.email || tt("Name, email, phone, address"))}</div>`);

PG.cards = () => {
  let body;
  if (PRACTICE) body = `<div class="rowp">${t("Practice mode uses a pretend Visa •••• 4242. No real card is needed.")}</div>`;
  else if (!API.enabled) body = `<div class="rowp">${t("Card payments are not switched on yet. Gifts are completed on our donation page.")}</div>`;
  else body = `${cardIssueBanner()}${API.card
    ? `<div class="card" style="flex-direction:column;align-items:stretch;gap:4px"><div class="kicker">${t("Your card")}</div><div class="card-title" style="direction:ltr;text-align:start">${ico(I.card, 20)} ${esc(cardLabel())}</div><div class="h-s">${cardExp() ? t("Expires {date}", { date: esc(cardExp()) }) : ""}${cardExpired() ? " · <b style='color:#9b1c5a'>" + t("Expired") + "</b>" : ""}</div></div>
      <button class="btn btn-primary cta" data-act="cardChange">${t("Change card")}</button><button class="btn btn-ghost" data-act="removeCard">${t("Remove card")}</button>`
    : `<div class="rowp">${t("No card saved")}</div><button class="btn btn-primary cta" data-act="cardChange">${t("Add a card")}</button>`}
    <p class="note">${t("Your new card replaces the old one for your pushka and monthly gifts. Your card is stored securely by Stripe. Chabad of Sampleton never sees your card number.")}</p>`;
  return sub(tt("Payment method"), body);
};
PG.profile = () => {
  const f = (k, label, v) => `<div class="row-btn" style="cursor:default"><div class="grow"><div class="h-s" style="text-transform:uppercase;letter-spacing:.08em;font-size:11px">${label}</div><div style="font-size:16px">${v ? esc(v) : "—"}</div></div><button class="icon-btn sm" data-act="editField" data-v="${k}" aria-label="${esc(tt("Edit"))} ${label}">${ico(I.pencil, 18)}</button></div>`;
  let rec;
  if (!API.enabled) rec = `<div class="rowp">${t("Monthly gifts are available once card payments are switched on.")}</div>`;
  else if (API.subs === null) rec = `<div class="rowp">${t("Loading…")}</div>`;
  else if (!API.subs.length) rec = `<div class="rowp">${t("No monthly gifts. Choose “Monthly” when giving to a fund.")}</div>`;
  else rec = API.subs.map((s) => `<div class="row-btn" style="cursor:default"><div class="grow"><div class="h-t">${t("{amt} monthly · {fund}", { amt: money(s.amount), fund: t(fundOf(s.fund).name) })}</div><div class="h-s">${s.next ? t("Next gift {date}", { date: esc(greg(new Date(s.next))) }) : ""}</div></div><button class="btn btn-ghost" data-act="cancelSub" data-v="${esc(s.id)}">${t("Cancel")}</button></div>`).join("");
  const payRow = API.enabled
    ? `<div class="row-btn" style="cursor:default"><span style="color:var(--accent)">${ico(I.card, 20)}</span><div class="grow" style="font-size:14px;direction:ltr;text-align:start">${API.card ? esc(cardLabel()) : t("No card saved")}</div><button class="btn btn-ghost" data-act="cardChange">${API.card ? t("Change") : t("Add")}</button>${API.card ? `<button class="btn btn-ghost" data-act="removeCard">${t("Remove")}</button>` : ""}</div>`
    : `<div class="rowp">${t("Card payments are not switched on yet. Gifts are completed on our donation page.")}</div>`;
  return sub(tt("Profile"), `${accountCard()}${installCard()}${f("name", t("Name"), S.name)}${f("email", t("Email"), S.email)}${f("billingEmail", t("Billing email"), S.billingEmail)}${f("phone", t("Phone number"), S.phone)}${f("address", t("Mailing address"), S.address)}
    ${sec(t("Recurring"))}${rec}${sec(t("Payment"))}${payRow}
    ${sec(t("Manage account"))}<button class="row-btn" data-act="deleteAcct" style="color:#9b1c5a"><span style="flex:none">${ico(I.trash, 22)}</span><div class="grow" style="font-size:16px">${t("Delete account?")}</div></button>`);
};
PG.support = () => sub(tt("Support"), `<p class="body-p">${t("Questions about the pushka, your gifts or receipts? We’re happy to help.")}</p><div class="card" style="flex-direction:column;align-items:flex-start;gap:4px"><div class="card-title">${t("Chabad of Sampleton")}</div><a href="mailto:${SITE_EMAIL}">${SITE_EMAIL}</a><a href="https://www.sample-chabad.org" target="_blank" rel="noopener">sample-chabad.org</a></div>
  <p class="row2" style="justify-content:flex-start;gap:var(--s4)"><a href="privacy.html" target="_blank" rel="noopener">${t("Privacy policy")}</a><a href="support.html" target="_blank" rel="noopener">${t("Help & FAQ")}</a></p>
  <p class="note">${t("Tip: add this app to your home screen — in your browser menu choose “Add to Home Screen.”")}</p>`);

// ---------- rendering ----------
const practiceBar = () => (PRACTICE ? `<div class="practice"><div class="pr-t">${t("Practice mode — no real money is used")}</div><div class="pr-b"><button data-act="pFill">${t("Fill to goal")}</button><button data-act="pClear">${t("Clear practice data")}</button><button data-act="pExit">${t("Exit practice mode")}</button></div></div>` : "");
function captureFill() { // a re-draw must continue from where the fill visually is, not jump to the end
  const g = $("#fillG"); if (!g || U.drawn !== "home") return;
  try { const ty = new DOMMatrix(getComputedStyle(g).transform).f; U.fillShown = ty >= 139 ? 0 : Math.max(0, 1 - ty / 124); const pf = $("#progFill"); if (pf && pf.parentElement.clientWidth) U.pctShown = (pf.getBoundingClientRect().width / pf.parentElement.clientWidth) * 100; } catch (e) {}
}
function draw() {
  captureFill();
  const pg = PG[U.page] && !S.kids.on ? U.page : "home", prev = $(".scroll"), y = prev && U.drawn === pg ? prev.scrollTop : 0;
  $("#app").innerHTML = practiceBar() + PG[pg]() + (S.kids.on ? `<nav class="tabbar kids"><button class="tab on" data-act="kidsExit">${ico(I.lock, 22)}<span>${t("Grown-ups")}</span></button></nav>` : `<nav class="tabbar" aria-label="${t("Main")}">${TABS.map(([id, l, ic]) => `<button class="tab ${tabOf(pg) === id ? "on" : ""}" data-act="tab" data-v="${id}" ${tabOf(pg) === id ? 'aria-current="page"' : ""}>${ico(ic)}<span>${t(l)}</span></button>`).join("")}</nav>`);
  $("#app").className = pg === "home" ? "home" : ""; document.body.dataset.pg = pg; { const sn = pg === "home" ? season() : null; if (sn) $("#app").dataset.season = sn.id; else delete $("#app").dataset.season; }
  U.drawn = pg; const sc = $(".scroll"); if (sc) sc.scrollTop = y;
  if (pg === "home") animateFill();
  if (pg === "club" || pg === "board") mountBoard();
  if (pg === "club" && API.enabled && S.token && API.subs === null && !U.subsLoading) { U.subsLoading = true; loadSubs().finally(() => (U.subsLoading = false)); }
  if (pg === "profile" && API.enabled && S.token && API.subs === null && !U.subsLoading) { U.subsLoading = true; loadSubs().finally(() => (U.subsLoading = false)); }
}

// ---------- actions ----------
const A = {};
document.addEventListener("click", (e) => { const el = e.target.closest("[data-act]"); if (!el) return; const fn = A[el.dataset.act]; if (fn) { if (el.tagName === "A") return; e.preventDefault(); fn(el.dataset.v, el, e); } });
document.addEventListener("change", (e) => { const el = e.target.closest("[data-chg]"); if (el && A[el.dataset.chg]) A[el.dataset.chg](el.value, el, e); });
document.addEventListener("input", (e) => { const el = e.target.closest("[data-inp]"); if (el && A[el.dataset.inp]) A[el.dataset.inp](el.value, el, e); });
document.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches('[role="button"][data-act]')) { e.preventDefault(); e.target.click(); } });

A.closeSheet = () => closeSheet();
A.fee = (v, el) => { S.coverFee = el.checked; save(); refreshCtas(); };
function refreshCtas() { const g = $("#giveCta"); if (g) g.innerHTML = giveCtaText(); const x = $("#segGo"); if (x) x.innerHTML = segGiftText(); const e = $("#emptyGo"); if (e) e.innerHTML = emptyCtaText(); const d = $("#donGo"); if (d) d.innerHTML = donCtaText(); }
A.emptyAmt = () => refreshCtas(); A.donAmt = () => refreshCtas(); A.emptyPay = () => refreshCtas();
A.copy = (v) => { try { navigator.clipboard.writeText(v).then(() => toast(tt("Copied"))); } catch (e) { toast(v); } };
A.way = (id) => { const name = tt(WAYS().find((w) => w[0] === id)[1]); sheet(`<h3>${esc(name)}</h3>${waysHtml(id)}${contactBtns("Giving by " + name)}<p class="note">${t("Chabad of Sampleton is a {c3} nonprofit, Tax ID {ein}. 100% of the proceeds of your gift benefit Chabad of Sampleton.", { c3: C3_HTML, ein: EIN_HTML })}</p><button class="btn btn-primary cta" data-act="closeSheet">${t("Close")}</button>`); };
A.sponsor = (v) => { if (v === "kiddush") { const w = window.open("/kiddush/" + (LANG === "he" ? "?lang=he" : ""), "_blank", "noopener"); if (!w) location.href = "/kiddush/"; return; } const sp = SPONSORS.find((x) => x[0] === v); Object.assign(U, { giveFund: sp[2], giveAmt: 360, freq: "once", dedication: tt("Sponsorship: {name}", { name: tt(sp[1]) }).slice(0, 80) }); U.stack = []; U.page = "give"; draw(); };
A.level = (v) => {
  const L = LEVELS.find((x) => x[0] === v);
  if (L[1] > MAX_CARD) return sheet(`<div><h3>${t("{level} · {amt}", { level: t(L[0]), amt: money(L[1]) })}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("For gifts of this size, please contact us. We’ll help you give by check, wire, stock, crypto or donor advised fund.")}</div></div>${contactBtns("Building Campaign: " + L[0])}<button class="btn btn-secondary cta" data-act="goWays">${t("Other ways to give")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Close")}</button>`);
  Object.assign(U, { giveFund: "building", giveAmt: L[1], freq: "once", dedication: tt("Building Campaign: {level}", { level: tt(L[0]) }).slice(0, 80) }); U.stack = []; U.page = "give"; draw();
};
A.goWays = () => { closeSheet(); U.stack = []; U.page = "otherways"; U.stack.push("give"); draw(); };
A.tab = (v) => { U.stack = []; U.page = v; if (v === "give") U.giveFund = null; draw(); };
A.go = (v) => { U.stack.push(U.page); U.page = v; draw(); };
A.back = () => { U.page = U.stack.pop() || "more"; draw(); };
A.share = async () => { const d = { title: tt("Chabad of Sampleton · My Pushka"), text: tt("Give tzedakah every day with the Chabad of Sampleton pushka."), url: location.href.split("#")[0] }; try { if (navigator.share) await navigator.share(d); else { await navigator.clipboard.writeText(d.url); toast(tt("Link copied")); } } catch (e) {} };
A.setCur = (v) => { S.cur = v; save(); closeSheet(); draw(); };
const setLang = (l) => { S.lang = l; save(); applyLang(); if (S.pushOn) pushPrefsSoon(); closeSheet(); if ($("#lock") && !$("#lock").hidden) showLock(); draw(); };
A.toggleLang = () => setLang(LANG === "he" ? "en" : "he");
A.setLang = (v) => setLang(v === "he" ? "he" : "en");

// coins
function drop(a, ttl, why) {
  a = r2(a); if (!(a > 0) || a > 100000) return;
  const p = P(), before = p.balance;
  p.balance = r2(p.balance + a); p.drops++;
  const entry = { kind: "coin", t: Date.now(), ttl: ttl || "coin", amt: a, pid: p.id, ...(why ? { why } : {}), ...(U.by ? { by: U.by } : {}) }; pushHist(entry);
  if (S.kids.on) S.kids.coins = (S.kids.coins || 0) + 1; reportCoin(a); milestone();
  save(); if (S.sound) clink(p.balance > 20 ? 2 : 1, 0.09); buzz(30); draw(); if (S.pushOn && S.rem.streak.on) pushPrefsSoon();
  if (!S.kids.on) toast(tt("{amt} added to your pushka", { amt: money(a) }), { label: tt("Undo"), fn: () => removeCoinAt(S.history.indexOf(entry)) });
  const an = $("#coinAnchor"); if (an) { const c = document.createElement("div"); c.className = "coin"; c.textContent = money(a); an.append(c); setTimeout(() => c.remove(), 800); }
  if (before < S.goal && p.balance >= S.goal) setTimeout(() => { fanfare(); confetti(); toast(tt("Your pushka is full! 🎉")); if (S.emptyMode === "full") setTimeout(openEmpty, 1400); }, 700);
}
A.drop = (v) => drop(parseFloat(v));
A.dropPrimary = () => { drop(S.presets[0]); if (U.page !== "home") toast(tt("{amt} added to your pushka", { amt: money(S.presets[0]) })); };
A.other = () => sheet(`<h3>${t("Drop a coin")}</h3><div class="field"><label for="oa">${t("Amount")}</label><input class="input" id="oa" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="$0.00"></div>${sheetBtns(["otherGo", t("Drop in pushka")], ["closeSheet", t("Cancel")])}`, () => setTimeout(() => $("#oa") && $("#oa").focus(), 60));
A.otherGo = () => { const v = parseFloat($("#oa").value); if (!(v > 0) || v > 100000) return toast(tt("Enter a valid amount")); closeSheet(); drop(v); };

// emptying & giving
const emptyCtaText = () => { const p = P(); let base = p.balance; if (S.partial) { const v = parseFloat(($("#ea") || {}).value); base = v > 0 ? v : 0; } const payOnline = (($("select[name=pm]") || {}).value || "online") === "online"; return `${API.enabled ? t("Send") : t("Give")} ${base > 0 ? money2(payOnline ? totalOf(base) : base) : ""}`; };
function openEmpty() {
  const p = P(); if (p.balance <= 0) return toast(tt("Your pushka is empty"));
  const sub1 = API.enabled && API.card ? t("{amt} will be charged to {card} and sent to:", { amt: money2(p.balance), card: `<bdi>${esc(cardLabel())}</bdi>` }) + ` <button class="link" data-act="cardChange">${t("Change card")}</button>` : t("{amt} will be given to Chabad of Sampleton. Choose a fund:", { amt: money2(p.balance) });
  sheet(`<div><h3>${t("Empty your pushka")}</h3><div class="h-s" style="font-size:13px">${sub1}</div></div>
    ${S.partial ? `<div class="field"><label for="ea">${t("Amount to give (up to {max})", { max: money2(p.balance) })}</label><input class="input" id="ea" data-inp="emptyAmt" type="number" min="0.01" max="${p.balance}" step="0.01" value="${p.balance}"></div>` : ""}
    <div class="fundlist">${FUNDS.map((f, i) => `<label class="radio"><input type="radio" name="fund" value="${f.id}" ${i === 0 ? "checked" : ""}><span class="dot"></span><span class="nm">${t(f.name)}</span></label>`).join("")}</div>
    ${S.addl ? `<div class="field"><label for="pmsel">${t("Pay by")}</label><select class="input" id="pmsel" name="pm" data-chg="emptyPay">${Object.entries(METHOD).map(([k, v]) => `<option value="${k}">${k === "online" && API.enabled ? t("Card") : t(v)}</option>`).join("")}</select></div>` : ""}
    ${feeBox()}
    <button class="btn btn-primary cta" id="emptyGo" data-act="confirmEmpty">${emptyCtaText()}</button>`);
}
A.openEmpty = openEmpty;
A.confirmEmpty = () => {
  const p = P(); let amt = p.balance;
  if (S.partial) { amt = r2(parseFloat($("#ea").value)); if (!(amt > 0 && amt <= p.balance + 1e-9)) return toast(tt("Enter an amount up to {max}", { max: money2(p.balance) })); }
  const fund = ($("input[name=fund]:checked") || {}).value || "general", method = ($("select[name=pm]") || {}).value || "online";
  closeSheet(); startGift({ amt, fund, freq: "once", ded: "", fromPushka: true, method, pid: p.id });
};
const donCtaText = () => t("Give {amt}", { amt: money(totalOf(parseFloat(($("#dn") || {}).value) || 0)) });
A.donateNow = () => sheet(`<div><h3>${t("Donate now")}</h3><div class="h-s" style="font-size:13px">${t("Give directly to Chabad of Sampleton.")}</div></div><div class="field"><label for="dn">${t("Amount")}</label><input class="input" id="dn" data-inp="donAmt" type="number" min="1" step="0.01" inputmode="decimal" value="${P().balance || 180}"></div>${feeBox()}<button class="btn btn-primary cta" id="donGo" data-act="donateGo">${donCtaText()}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.donateGo = () => { const v = parseFloat($("#dn").value); if (!(v > 0) || v > 100000) return toast(tt("Enter a valid amount")); closeSheet(); startGift({ amt: r2(v), fund: "general", freq: "once", ded: "", fromPushka: false, method: "online", pid: P().id }); };
A.fund = (v) => { Object.assign(U, { giveFund: v, giveAmt: 360, freq: "once", dedication: "" }); draw(); };
A.allFunds = () => { U.giveFund = null; draw(); };
A.giveGeneral = () => { Object.assign(U, { giveFund: "general", giveAmt: 360, freq: "once", dedication: "" }); U.stack = []; U.page = "give"; draw(); };
A.amt = (v) => { U.giveAmt = +v; draw(); };
A.giveCustom = (v) => { const n = parseFloat(v); if (n > 0) { U.giveAmt = r2(n); $$(".amts .btn").forEach((b) => b.classList.remove("sel")); const c = $("#giveCta"); if (c) c.innerHTML = giveCtaText(); } };
A.freq = (v) => { U.freq = v; draw(); };
A.ded = (v) => { U.dedication = v; };
A.submitGive = () => { if (!(U.giveAmt > 0) || U.giveAmt > 100000) return toast(tt("Enter a valid amount")); startGift({ amt: U.giveAmt, fund: U.giveFund, freq: U.freq, ded: U.dedication.trim(), fromPushka: false, method: "online", pid: P().id }); };

// Fallback only: used when the server has no Stripe keys yet.
const donateLink = (p) => `${DONATE_URL}?amount=${encodeURIComponent(p.amt)}&fund=${encodeURIComponent(p.fund)}&frequency=${p.freq}${p.ded ? "&dedication=" + encodeURIComponent(p.ded) : ""}`;
function practiceGift(p) {
  p.fee = !!feeOn();
  sheet(`<div class="done"><div class="spin" aria-hidden="true"></div><h3>${t("Processing your gift…")}</h3></div>`, null, null, true);
  setTimeout(() => { if (p.freq === "monthly") { if (p.club && p.replace) S.pracSubs = (S.pracSubs || []).filter((x) => !x.club); S.pracSubs = (S.pracSubs || []).concat([{ id: "prac" + uid(), amount: p.amt, gift: p.amt, club: !!p.club, fund: p.fund, next: Date.now() + 30 * 864e5 }]); API.subs = S.pracSubs; } completeGift(p); }, 900);
}
async function startGift(p) {
  if (p.method && p.method !== "online") return offlineSheet(p);
  if (PRACTICE) return practiceGift(p);
  p.fee = !!(feeOn());
  if (API.enabled) return chargeFlow(p);
  U.pending = p;
  sheet(`<div><h3>${t("Finish your gift")}</h3><div class="h-s" style="font-size:13px">${t("We opened our secure donation page for {amt} to the {fund}. Complete it there, then come back and tap below.", { amt: money2(p.amt), fund: t(fundOf(p.fund).name) })}</div></div><button class="btn btn-secondary cta" data-act="reopen">${t("Open donation page again")}</button>${sheetBtns(["finished", t("I’ve completed my gift")], ["closeSheet", t("Not yet")])}`);
  window.open(donateLink(p), "_blank", "noopener");
}
A.reopen = () => window.open(donateLink(U.pending), "_blank", "noopener");
A.finished = () => completeGift(U.pending);
function offlineSheet(p) {
  U.pending = p; const m = tt(METHOD[p.method]);
  sheet(`<div><h3>${t("Give by {method}", { method: esc(m) })}</h3><div class="h-s" style="font-size:13px">${t("{amt} to the {fund}. Once you’ve sent it, tap below. We’ll record it as pending until it is received.", { amt: money2(p.amt), fund: t(fundOf(p.fund).name) })}</div></div>${waysHtml(p.method)}${contactBtns("Pushka gift by " + METHOD[p.method])}${sheetBtns(["finished", t("I’ve sent it")], ["closeSheet", t("Not yet")])}`);
}
function completeGift(p) {
  const f = fundOf(p.fund), ts = Date.now(), pu = S.pushkas.find((x) => x.id === p.pid) || P(), offline = p.method && p.method !== "online", total = p.fee ? withFee(p.amt) : p.amt;
  if (p.fromPushka) { pu.balance = r2(pu.balance - p.amt); if (pu.balance < 0.005) { pu.balance = 0; pu.drops = 0; S.lastEmptied = ts; } if (S.jingle) clink(7, 0.06, 0); }
  pushHist({ kind: "gift", t: ts, amt: total, fee: !!p.fee, fund: p.fund, fp: !!p.fromPushka, freq: p.freq, method: p.method, ded: p.ded || "", receiptUrl: p.receiptUrl || "", receipt: API.enabled && !offline && !PRACTICE });
  save(); buzz([60, 40, 60]); fanfare(); confetti(); U.pending = null; U.giveFund = null; draw();
  const note = PRACTICE ? t("Practice mode: no money was charged.") : API.enabled && !offline ? (S.email ? t("A receipt is on its way to {email}.", { email: `<bdi>${esc(S.email)}</bdi>` }) : "") : offline ? t("We’ll confirm once your gift is received.") : t("Your receipt will be emailed by our donation page.");
  U.lastGift = { ded: p.ded || "" }; const cl = p.club && clubOf(p.amt);
  sheet(`<div class="done">${cl ? `<div class="medalpop">${medalSvg(cl[0], 84)}</div><div class="kicker">${t("Welcome to the {level} level", { level: t(cl[2]) })}</div>` : `<div class="ck" style="color:var(--accent)">${ico(I.check, 24)}</div>`}<h3>${t("Todah rabah")}</h3><div style="font-size:14px;max-width:280px">${t("{amt} is on its way to the {fund}.", { amt: money2(total), fund: t(f.name) })}</div><div class="h-s">${note}</div>${p.receiptUrl ? `<a class="btn btn-ghost" href="${esc(p.receiptUrl)}" target="_blank" rel="noopener">${t("View receipt")}</a>` : ""}</div>${p.ded ? `<button class="btn btn-secondary cta" data-act="honorCard">${t("Make an honor card")}</button>` : ""}<button class="btn btn-primary cta" data-act="closeSheet">${t("Done")}</button>`);
}
function autoEmpty() {
  const p = P(), now = new Date(); if (p.balance <= 0 || S.emptyMode === "manual" || S.prompted === dkey(now)) return;
  const last = new Date(S.lastEmptied), due = (S.emptyMode === "full" && p.balance >= S.goal) || (S.emptyMode === "friday" && now.getDay() === 5) || (S.emptyMode === "monthly" && (now.getMonth() !== last.getMonth() || now.getFullYear() !== last.getFullYear()));
  if (due) { S.prompted = dkey(now); save(); openEmpty(); }
}

// cards & monthly gifts
A.cardChange = async () => { if (PRACTICE) return toast(tt("Not needed in practice mode")); const sheetOpen = !!$("#overlay .sheet"), ok = await addCard(); if (ok && sheetOpen && U.page === "home") A.openEmpty(); else draw(); };
A.addCard = () => (PRACTICE ? toast(tt("Not needed in practice mode")) : addCard());
A.removeCard = () => sheet(`<div><h3>${t("Remove this card?")}</h3><div class="h-s" style="font-size:13px">${t("You’ll need to add a card again before your next gift.")}</div></div><button class="btn btn-primary cta" data-act="removeCardGo">${t("Remove card")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.removeCardGo = () => { closeSheet(); if (PRACTICE) return toast(tt("Not needed in practice mode")); removeCard(); };
A.cancelSub = (v) => sheet(`<div><h3>${t("Cancel this monthly gift?")}</h3><div class="h-s" style="font-size:13px">${t("No further gifts will be charged.")}</div></div><button class="btn btn-primary cta" data-act="cancelSubGo" data-v="${esc(v)}">${t("Cancel monthly gift")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Keep it")}</button>`);
A.cancelSubGo = async (v) => { closeSheet(); if (PRACTICE) { S.pracSubs = (S.pracSubs || []).filter((x) => x.id !== v); API.subs = S.pracSubs; save(); toast(tt("Monthly gift cancelled")); return draw(); } try { await api("/subscriptions/" + encodeURIComponent(v), { method: "DELETE" }); toast(tt("Monthly gift cancelled")); } catch (e) { toast(errText(e)); } API.subs = null; draw(); };

// wallet
A.walletLearn = () => infoSheet(tt("About the wallet"), t("Your wallet will hold funds you set aside for tzedakah, so emptying your pushka later is quick and simple. This feature is coming soon."));
const soon = (what) => infoSheet(what, t("This feature is coming soon."));
A.addFunds = () => soon(tt("Add funds")); A.walletSend = () => soon(tt("Send / request between wallets")); A.autoRefill = () => soon(tt("Manage wallet auto refill"));
A.walletHist = () => infoSheet(tt("Wallet transaction history"), t("No wallet transactions yet."));

// maaser
const maaserRefresh = () => { const o = maaserOut(); $("#maaOut").textContent = money2(o); $$(".maaBtn").forEach((b) => (b.disabled = !(o > 0))); };
A.maaserAmt = (v) => { U.maaserAmt = v; maaserRefresh(); };
A.maaserPct = (v) => { S.maaser = +v; $("#maaPct").textContent = v + "%"; maaserRefresh(); };
A.maaserSave = () => save();
A.maaserPushka = () => { const o = maaserOut(); if (o > 0) { drop(o, "maaser"); toast(tt("{amt} added to your pushka", { amt: money2(o) })); } };
A.maaserWallet = () => soon(tt("Add to wallet"));
A.maaserDonate = () => { const o = maaserOut(); if (o > 0) startGift({ amt: o, fund: "general", freq: "once", ded: tt("Maaser"), fromPushka: false, method: "online", pid: P().id }); };

// segulos
const segGiftAmt = { id: "", amt: 360, freq: "once" };
function segGiveSheet() {
  const raw = SEGULOS.find((x) => x.id === segGiftAmt.id), s = SG(raw);
  sheet(`<div><h3>${t("Give for {name}", { name: esc(s.title) })}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("Your gift goes to Chabad of Sampleton, given in the merit of this segulah.")}</div></div>
    <div class="field"><label>${t("Amount")}</label><div class="amts three">${GIVE_AMTS.map((a) => `<button class="btn btn-secondary ${segGiftAmt.amt === a ? "sel" : ""}" data-act="segAmt" data-v="${a}">${money(a)}</button>`).join("")}</div>
      <input class="input" id="segCustom" data-inp="segCustom" type="number" min="1" step="0.01" inputmode="decimal" aria-label="${t("Other amount")}" placeholder="${t("Other amount")}" style="margin-top:6px"></div>
    <div class="field"><label>${t("Frequency")}</label><div class="seg"><label><input type="radio" name="sfreq" value="once" data-chg="segFreq" ${segGiftAmt.freq === "once" ? "checked" : ""}>${t("One time")}</label><label><input type="radio" name="sfreq" value="monthly" data-chg="segFreq" ${segGiftAmt.freq === "monthly" ? "checked" : ""}>${t("Monthly")}</label></div></div>
    ${feeBox()}
    <button class="btn btn-primary cta" id="segGo" data-act="segGo">${segGiftText()}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
}
const segGiftText = () => (segGiftAmt.freq === "monthly" ? t("Give {amt} monthly", { amt: money(totalOf(segGiftAmt.amt)) }) : t("Give {amt}", { amt: money(totalOf(segGiftAmt.amt)) }));
A.segGive = (v) => { Object.assign(segGiftAmt, { id: v, amt: 360, freq: "once" }); segGiveSheet(); };
A.segAmt = (v) => { segGiftAmt.amt = +v; segGiveSheet(); };
A.segCustom = (v) => { const n = parseFloat(v); if (n > 0) { segGiftAmt.amt = r2(n); $$("#overlay .amts .btn").forEach((b) => b.classList.remove("sel")); const g = $("#segGo"); if (g) g.innerHTML = segGiftText(); } };
A.segFreq = (v) => { segGiftAmt.freq = v === "monthly" ? "monthly" : "once"; const g = $("#segGo"); if (g) g.innerHTML = segGiftText(); };
A.segGo = () => {
  if (!(segGiftAmt.amt > 0) || segGiftAmt.amt > MAX_CARD) return toast(tt("Enter a valid amount"));
  const raw = SEGULOS.find((x) => x.id === segGiftAmt.id); closeSheet();
  startGift({ amt: segGiftAmt.amt, fund: "general", freq: segGiftAmt.freq, ded: ("Segulah: " + raw.title).slice(0, 80), fromPushka: false, method: "online", pid: P().id });
};
A.seg = (v) => { U.segId = v; const s = SEGULOS.find((x) => x.id === v); U.stack.push(U.page); U.page = s.kind === "quotes" ? "quotes" : "segulah"; draw(); };
A.segQ = (v) => { U.segQ = v; $("#segList").innerHTML = segList(); };
A.segCat = (v) => { U.segCat = v; $("#segChips").innerHTML = segChips(); $("#segList").innerHTML = segList(); };

// reminders
A.remToggle = async (v) => {
  const r = v === "candle" ? S.rem.candle : v === "streak" ? S.rem.streak : S.rem.custom.find((x) => x.id === v); if (!r) return;
  if (!r.on && !(await ensureNotify())) return;
  r.on = !r.on; save(); if (r.on && v === "candle") loadCandles(); if (S.pushOn) pushPrefsSoon(); draw();
};
A.remDel = (v) => { S.rem.custom = S.rem.custom.filter((x) => x.id !== v); save(); if (S.pushOn) pushPrefsSoon(); draw(); };
A.candleMins = () => sheet(`<h3>${t("Before Candle Lighting")}</h3><div class="field"><label>${t("Remind me")}</label><div class="seg">${[10, 15, 30, 60].map((m) => `<label><input type="radio" name="cm" value="${m}" ${S.rem.candle.mins === m ? "checked" : ""}>${t("{n} min", { n: m })}</label>`).join("")}</div></div>${sheetBtns(["candleSave", t("Save")], ["closeSheet", t("Cancel")])}`);
A.candleSave = () => { S.rem.candle.mins = +($("input[name=cm]:checked") || { value: 15 }).value; save(); if (S.pushOn) pushPrefsSoon(); closeSheet(); draw(); };
A.addRem = () => sheet(`<h3>${t("Add reminder")}</h3><div class="field"><label for="rt">${t("Time")}</label><input class="input" id="rt" type="time" value="09:00"></div><div class="field"><label>${t("Repeat")}</label><div class="seg"><label><input type="radio" name="rd" value="weekdays" checked>${t("Weekdays")}</label><label><input type="radio" name="rd" value="daily">${t("Every day")}</label><label><input type="radio" name="rd" value="friday">${t("Fridays")}</label></div></div><div class="field"><label for="rx">${t("Message (optional)")}</label><input class="input" id="rx" maxlength="60" placeholder="${t("Time to give tzedakah!")}"></div>${sheetBtns(["remSave", t("Save")], ["closeSheet", t("Cancel")])}`);
A.remSave = async () => { const time = $("#rt").value; if (!time) return toast(tt("Choose a time")); const r = { id: uid(), time, days: ($("input[name=rd]:checked") || {}).value || "weekdays", text: $("#rx").value.trim(), on: true }; closeSheet(); if (!(await ensureNotify())) return; S.rem.custom.push(r); save(); if (S.pushOn) pushPrefsSoon(); draw(); };

A.weeklyTgl = () => { S.rem.weekly.on = !S.rem.weekly.on; save(); pushPrefsSoon(); draw(); };
A.remSuggest = async (v) => { const x = SUGG.find((q) => q[0] === v); if (!x || !(await ensureNotify())) return; S.rem.custom.push({ id: uid(), sid: x[0], time: x[4], days: x[3], text: tt(x[2]), on: true }); save(); if (S.pushOn) pushPrefsSoon(); toast(tt("Reminder added")); draw(); };

// settings
A.setGoal = (v) => { const n = parseFloat(v); if (n >= 1 && n <= 100000) { S.goal = r2(n); save(); } draw(); };
A.setPreset = (v, el) => { const n = parseFloat(v); if (n > 0 && n <= 10000) { S.presets[+el.dataset.i] = r2(n); save(); } draw(); };
A.setEmpty = (v) => { S.emptyMode = v; save(); };
A.tgl = (k) => { S[k] = !S[k]; save(); if (S[k] && k === "sound") clink(1, 0, 0); draw(); };
A.bio = async () => {
  if (S.bio) { S.bio = ""; save(); draw(); return toast(tt("Biometric lock off")); }
  if (!(await bioSupported())) return toast(tt("This device doesn’t support a screen-lock unlock"));
  try { await bioEnable(); toast(tt("Biometric lock on")); } catch (e) { toast(tt("Couldn’t turn on the lock")); } draw();
};
A.unlock = async () => { try { await bioUnlock(); $("#lock").hidden = true; } catch (e) { toast(tt("Unlock failed. Try again.")); } };
A.addPushka = () => sheet(`<h3>${t("Add pushka")}</h3><div class="field"><label for="np">${t("Name")}</label><input class="input" id="np" maxlength="24" placeholder="${t("e.g. Kids’ pushka")}"></div>${sheetBtns(["pushkaAdd", t("Add")], ["closeSheet", t("Cancel")])}`, () => setTimeout(() => $("#np") && $("#np").focus(), 60));
A.pushkaAdd = () => { const n = $("#np").value.trim(); if (!n) return toast(tt("Enter a name")); const p = { id: uid(), name: n, balance: 0, drops: 0 }; S.pushkas.push(p); S.cur = p.id; save(); closeSheet(); draw(); };
A.editPushka = (v) => { const p = S.pushkas.find((x) => x.id === v); sheet(`<h3>${esc(pTitle(p))}</h3><div class="field"><label for="rn">${t("Name")}</label><input class="input" id="rn" maxlength="24" value="${esc(p.name)}" placeholder="${esc(pTitle({ name: "" }))}"></div><button class="btn btn-primary cta" data-act="pushkaSave" data-v="${p.id}">${t("Save")}</button><button class="btn btn-secondary cta" data-act="setCur" data-v="${p.id}">${t("Make current")}</button><button class="btn btn-ghost" data-act="resetAsk" data-v="${p.id}">${t("Reset this pushka")}</button>${S.pushkas.length > 1 ? `<button class="btn btn-ghost" data-act="pushkaDel" data-v="${p.id}">${t("Delete this pushka")}</button>` : ""}`); };
A.pushkaSave = (v) => { const p = S.pushkas.find((x) => x.id === v); p.name = $("#rn").value.trim(); save(); closeSheet(); draw(); };
A.pushkaDel = (v) => { const p = S.pushkas.find((x) => x.id === v); if (p.balance > 0) return sheet(`<div><h3>${t("Delete this pushka?")}</h3><div class="h-s" style="font-size:13px">${t("It holds {amt}. Deleting it removes that amount from your pushka. Consider emptying it first.", { amt: money2(p.balance) })}</div></div><button class="btn btn-primary cta" data-act="pushkaDelGo" data-v="${p.id}" style="color:#9b1c5a;border-color:#9b1c5a">${t("Delete anyway")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`); A.pushkaDelGo(v); };
A.pushkaDelGo = (v) => { S.pushkas = S.pushkas.filter((x) => x.id !== v); if (S.cur === v) S.cur = S.pushkas[0].id; save(); closeSheet(); draw(); };
const FIELDS = { name: ["Name", "text", "name"], email: ["Email", "email", "email"], billingEmail: ["Billing email", "email", "email"], phone: ["Phone number", "tel", "tel"], address: ["Mailing address", "text", "street-address"] };
A.editField = (k) => { const [label, type, auto] = FIELDS[k]; sheet(`<h3>${t(label)}</h3><div class="field"><label for="ef">${t(label)}</label><input class="input" id="ef" type="${type}" autocomplete="${auto}" maxlength="120" value="${esc(S[k])}"></div><button class="btn btn-primary cta" data-act="fieldSave" data-v="${k}">${t("Save")}</button>`, () => setTimeout(() => $("#ef") && $("#ef").focus(), 60)); };
A.fieldSave = (k) => { S[k] = $("#ef").value.trim(); save(); closeSheet(); draw(); };
const exitPractice = (on) => { try { if (on) localStorage.setItem(MODEKEY, "1"); else localStorage.removeItem(MODEKEY); } catch (e) {} location.href = location.pathname; };
A.pExit = () => exitPractice(false);
A.pracToggle = () => exitPractice(!PRACTICE);
A.pFill = () => { const p = P(), need = r2(S.goal - p.balance); if (need <= 0) return toast(tt("Already at goal")); U.stack = []; U.page = "home"; draw(); const n = 5, base = r2(need / n); for (let i = 0; i < n; i++) setTimeout(() => drop(i === n - 1 ? r2(need - base * (n - 1)) : base), 450 * i); };
A.pClear = () => sheet(`<div><h3>${t("Clear practice data?")}</h3><div class="h-s" style="font-size:13px">${t("This resets the practice pushka and practice history. Your real data is not touched.")}</div></div><button class="btn btn-primary cta" data-act="pClearGo">${t("Clear")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.pClearGo = () => { try { localStorage.removeItem("samplehouse-pushka-practice"); } catch (e) {} location.reload(); };
const wipe = () => { try { localStorage.removeItem(KEY); } catch (e) {} location.reload(); };
A.deleteAcct = () => sheet(`<div><h3>${t("Delete account?")}</h3><div class="h-s" style="font-size:13px">${t("This erases your pushkas, history and settings from this device, stops any monthly gifts and removes your saved card. Gifts you already made are not affected.")}</div></div><button class="btn btn-primary cta" data-act="wipe" style="color:#9b1c5a;border-color:#9b1c5a">${t("Delete everything")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.wipe = async () => { if (S.mtoken && !PRACTICE) { try { await api("/member", { method: "DELETE", member: true }); const sub = await pushSub(); if (sub) await sub.unsubscribe(); } catch (e) { if (e.code !== "unauthorized") { closeSheet(); return toast(errText(e)); } } } if (API.enabled && S.token) { try { await api("/account", { method: "DELETE" }); } catch (e) { if (e.code !== "unauthorized") { closeSheet(); return toast(errText(e)); } } } wipe(); };
A.resetApp = (v, el) => { if (el.dataset.armed) return wipe(); el.dataset.armed = "1"; el.textContent = tt("Tap again to erase this app’s data"); setTimeout(() => { el.dataset.armed = ""; el.textContent = tt("Can’t unlock? Reset this app"); }, 5000); };


// ---------- yahrzeits, push reminders, and sharing with the Rabbi (all opt-in) ----------
const HD = window.HebDate;
const ymdLocal = (d) => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
const RELS = ["Father", "Mother", "Husband", "Wife", "Son", "Daughter", "Brother", "Sister", "Grandparent", "Other"];
function yzNext(e) {
  if (!HD) return null;
  const o = HD.next({ day: e.day, month: e.month, year: e.year || null }, ymdLocal(new Date())); if (!o) return null;
  const days = HD.daysBetween(ymdLocal(new Date()), o.date);
  return Object.assign({ days, greg: new Intl.DateTimeFormat(loc(), { weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(HD.toDate(o.date)) }, o);
}
const yzHeb = (e) => e.day + " " + (LANG === "he" ? HD.MONTHS_HE[e.month] || e.month : e.month);
const yzWhen = (n) => (n === 0 ? tt("Today") : n === 1 ? tt("Tomorrow (begins this evening)") : tt("In {n} days", { n }));
const yzSorted = () => S.yz.map((e) => ({ e, n: yzNext(e) })).sort((a, b) => (a.n ? a.n.days : 9999) - (b.n ? b.n.days : 9999));
function yzBanner() {
  if (!S.yz.length || !HD) return "";
  const soon = yzSorted().find((x) => x.n && x.n.days <= 7); if (!soon) return "";
  return `<button class="card" data-act="go" data-v="yahrzeit" style="text-align:start;width:100%">${ico(I.flame, 22, 'style="color:var(--accent);flex:none"')}<div style="flex:1"><div class="card-title">${t("Yahrzeit of {name}", { name: esc(soon.e.name) })}</div><div class="h-s">${esc(yzWhen(soon.n.days))} · ${esc(soon.n.greg)}</div></div>${chev()}</button>`;
}
function cardIssueBanner() {
  if (!API.cardIssue) return "";
  return `<div class="card" style="border-color:#9b1c5a">${ico(I.card, 22, 'style="color:#9b1c5a;flex:none"')}<div style="flex:1"><div class="card-title">${t("We couldn’t charge your card")}</div><div class="h-s">${t("Please update your card so your gifts can go through.")}</div></div><button class="btn btn-secondary" data-act="addCard">${t("Update card")}</button></div>`;
}
const yzNote = (n) => (n.notes || []).map((k) => `<div class="h-s">${t(k === "adar" ? "Born or passed in Adar: in a leap year some keep Adar I, others Adar II. Ask the Rabbi which to keep." : "The 30th does not fall this year, so it is marked on the 29th. Ask the Rabbi if unsure.")}</div>`).join("");
const toggleRow = (act, title, sub, on) => tg(act, "", title, sub, on);
PG.yahrzeit = () => {
  const rows = yzSorted().map(({ e, n }) => `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px"><div><div class="card-title">${esc(e.name)}</div><div class="h-s">${e.relation ? esc(tt(e.relation)) + " · " : ""}<bdi>${esc(yzHeb(e))}</bdi></div></div><div style="display:flex;gap:2px"><button class="icon-btn sm" data-act="yzEdit" data-v="${esc(e.id)}" aria-label="${esc(tt("Edit"))}">${ico(I.pencil, 18)}</button><button class="icon-btn sm" data-act="yzDel" data-v="${esc(e.id)}" aria-label="${t("Delete reminder")}">${ico(I.trash, 18)}</button></div></div>
    ${n ? `<div class="h-t">${esc(yzWhen(n.days))}</div><div class="h-s">${esc(n.greg)}</div>${yzNote(n)}` : ""}${e.notes ? `<div class="h-s">${esc(e.notes)}</div>` : ""}
    <button class="btn btn-secondary" data-act="yzGive" data-v="${esc(e.id)}">${t("Give in their memory")}</button></div>`).join("");
  const avail = API.members && !PRACTICE;
  return sub(tt("Yahrzeits"), `<p class="body-p">${t("Keep the yahrzeit dates of your loved ones. We calculate the Hebrew date each year and can remind you.")}</p>
    ${rows || `<div class="rowp">${t("No yahrzeits yet.")}</div>`}
    <button class="btn btn-primary cta" data-act="yzAdd">${ico(I.plus, 16)} ${t("Add a yahrzeit")}</button>
    ${sec(t("Reminders and sharing"))}
    ${avail ? `${toggleRow("yzRemindTgl", t("Remind me by notification"), t("By default: a month before, a week before and the day before. You can change this."), S.yzRemind)}
    ${S.yzRemind ? `<div class="field"><label>${t("Remind me")}</label><div class="chips wrapchips">${[[30, "1 month before"], [14, "2 weeks before"], [7, "1 week before"], [3, "3 days before"], [1, "1 day before"], [0, "On the day"]].map(([n, l]) => `<button class="chip ${S.yzLeads.includes(n) ? "on" : ""}" data-act="yzLead" data-v="${n}" aria-pressed="${S.yzLeads.includes(n)}">${t(l)}</button>`).join("")}</div></div>` : ""}
    ${toggleRow("yzShareTgl", t("Share with Chabad of Sampleton"), t("So the Rabbi can remember your loved ones and reach out. Off by default."), S.yzShare)}
    <p class="note">${t("If you share, the Rabbi can see these names and dates together with your name, email and phone. Nobody else can. Turn it off at any time and they are deleted from our server.")}</p>`
    : `<p class="note">${PRACTICE ? t("Reminders and sharing are not used in practice mode.") : t("Reminders and sharing are not switched on yet. Your list stays on this device.")}</p>`}`);
};
const yzDraft = { id: "", name: "", relation: "", mode: "civil", date: "", sunset: false, hday: "", hmonth: "Tishri", hyear: "", notes: "" };
function yzPreview() {
  const el = $("#yzPrev"); if (!el) return;
  const e = yzFromDraft(); el.textContent = e ? tt("Hebrew date: {d}", { d: yzHeb(e) + (e.year ? " " + e.year : "") }) : "";
}
function yzFromDraft() {
  const d = yzDraft;
  if (d.mode === "civil") { if (!/^\d{4}-\d{2}-\d{2}$/.test(d.date) || !HD) return null; const h = HD.hebrewOf(d.date, d.sunset); return { day: h.day, month: h.month, year: h.year }; }
  const day = parseInt(d.hday, 10), y = parseInt(d.hyear, 10); if (!(day >= 1 && day <= 30)) return null;
  return { day, month: d.hmonth, year: y >= 4000 && y <= 6000 ? y : null };
}
function yzSheet() {
  const d = yzDraft;
  sheet(`<h3>${t(d.id ? "Edit yahrzeit" : "Add a yahrzeit")}</h3>
    <div class="field"><label for="yzN">${t("Name")}</label><input class="input" id="yzN" data-inp="yzF" data-k="name" maxlength="80" value="${esc(d.name)}"></div>
    <div class="field"><label for="yzR">${t("Relationship")}</label><select class="input" id="yzR" data-chg="yzF" data-k="relation"><option value="">—</option>${RELS.map((r) => `<option value="${r}" ${d.relation === r ? "selected" : ""}>${t(r)}</option>`).join("")}</select></div>
    <div class="field"><div class="seg"><label><input type="radio" name="yzm" value="civil" data-chg="yzMode" ${d.mode === "civil" ? "checked" : ""}>${t("Date of passing")}</label><label><input type="radio" name="yzm" value="hebrew" data-chg="yzMode" ${d.mode === "hebrew" ? "checked" : ""}>${t("I know the Hebrew date")}</label></div></div>
    ${d.mode === "civil" ? `<div class="field"><label for="yzD">${t("Date of passing")}</label><input class="input" id="yzD" type="date" data-chg="yzF" data-inp="yzF" data-k="date" value="${esc(d.date)}"></div>
      <div class="field"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-chg="yzSun" ${d.sunset ? "checked" : ""}> ${t("Passed after sunset")}</label></div>`
    : `<div class="field"><label for="yzHM">${t("Hebrew month")}</label><select class="input" id="yzHM" data-chg="yzF" data-k="hmonth">${HD.MONTHS.map((m) => `<option value="${m}" ${d.hmonth === m ? "selected" : ""}>${esc(LANG === "he" ? HD.MONTHS_HE[m] : m)}</option>`).join("")}</select></div>
      <div class="field"><label for="yzHD">${t("Hebrew day (1–30)")}</label><input class="input" id="yzHD" type="number" min="1" max="30" inputmode="numeric" data-inp="yzF" data-k="hday" value="${esc(d.hday)}"></div>
      <div class="field"><label for="yzHY">${t("Hebrew year (optional)")}</label><input class="input" id="yzHY" type="number" min="4000" max="6000" inputmode="numeric" data-inp="yzF" data-k="hyear" value="${esc(d.hyear)}"></div>`}
    <div class="h-t" id="yzPrev" role="status"></div>
    <div class="field"><label for="yzNt">${t("Notes (optional)")}</label><input class="input" id="yzNt" data-inp="yzF" data-k="notes" maxlength="200" value="${esc(d.notes)}"></div>
    <div id="yzErr" class="err" role="alert"></div>
    <button class="btn btn-primary cta" data-act="yzSave">${t("Save")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`, () => yzPreview());
}
A.yzF = (v, el) => { yzDraft[el.dataset.k] = v; yzPreview(); };
A.yzSun = (v, el) => { yzDraft.sunset = el.checked; yzPreview(); };
A.yzMode = (v) => { yzDraft.mode = v === "hebrew" ? "hebrew" : "civil"; yzSheet(); };
A.yzAdd = () => { Object.assign(yzDraft, { id: "", name: "", relation: "", mode: "civil", date: "", sunset: false, hday: "", hmonth: "Tishri", hyear: "", notes: "" }); yzSheet(); };
A.yzEdit = (v) => { const e = S.yz.find((x) => x.id === v); if (!e) return; Object.assign(yzDraft, { id: e.id, name: e.name, relation: e.relation || "", mode: "hebrew", date: "", sunset: false, hday: String(e.day), hmonth: e.month, hyear: e.year ? String(e.year) : "", notes: e.notes || "" }); yzSheet(); };
A.yzSave = () => {
  const d = yzDraft, name = d.name.trim(), h = yzFromDraft();
  if (!name) { $("#yzErr").textContent = tt("Please enter a name."); return; }
  if (!h) { $("#yzErr").textContent = tt("Please enter a valid date."); return; }
  if (S.yz.length >= 30 && !d.id) { $("#yzErr").textContent = tt("You can keep up to 30 yahrzeits."); return; }
  const e = { id: d.id || uid() + uid(), name, relation: d.relation, day: h.day, month: h.month, year: h.year || null, notes: d.notes.trim() };
  const i = S.yz.findIndex((x) => x.id === e.id); if (i >= 0) S.yz[i] = e; else S.yz.push(e);
  save(); closeSheet(); draw(); yzSync();
};
A.yzDel = (v) => sheet(`<div><h3>${t("Delete this yahrzeit?")}</h3></div><button class="btn btn-primary cta" data-act="yzDelGo" data-v="${esc(v)}" style="color:#9b1c5a;border-color:#9b1c5a">${t("Delete")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.yzDelGo = (v) => { S.yz = S.yz.filter((x) => x.id !== v); save(); closeSheet(); draw(); yzSync(); };
A.yzGive = (v) => { const e = S.yz.find((x) => x.id === v); if (!e) return; Object.assign(U, { giveFund: "general", giveAmt: 36, freq: "once", dedication: tt("In memory of {name}", { name: e.name }).slice(0, 80) }); U.stack = []; U.page = "give"; draw(); };

// member account (name/email) on our server: needed for yahrzeit sharing and for yahrzeit notifications
async function memberSync() {
  const sig = [S.name, S.email, S.phone, S.address, S.token].join("|");
  if (S.mtoken && S.msig === sig) return true;
  const r = await api("/member", { method: "POST", member: true, body: { name: S.name, email: S.auth ? S.auth.email : S.email, phone: S.phone, address: S.address, stripeToken: S.token || undefined } });
  S.mtoken = r.token; S.msig = sig; save(); return true;
}
async function ensureMember() {
  if (!S.name || !S.email) { if (!(await askDetails())) return false; }
  await memberSync(); return true;
}
let yzTimer = null;
function yzSync() {
  if (!API.members || PRACTICE || !S.mtoken) return;
  clearTimeout(yzTimer);
  yzTimer = setTimeout(async () => {
    try {
      if (S.yzShare || S.yzRemind) await api("/yahrzeits", { method: "PUT", member: true, body: { entries: S.yz.map((e) => ({ id: e.id, name: e.name, relation: e.relation || "", day: e.day, month: e.month, year: e.year || null, notes: e.notes || "" })), share: S.yzShare } });
      else await api("/yahrzeits", { method: "DELETE", member: true });
    } catch (e) {}
  }, 400);
}
A.yzLead = (v) => { const n = +v, i = S.yzLeads.indexOf(n); if (i >= 0) { if (S.yzLeads.length === 1) return toast(tt("Keep at least one reminder, or turn reminders off")); S.yzLeads.splice(i, 1); } else S.yzLeads.push(n); S.yzLeads.sort((a, b) => b - a); save(); pushPrefsSoon(); draw(); };
A.yzShareTgl = async () => {
  if (!S.yzShare) {
    const ok = await new Promise((res) => sheet(`<div><h3>${t("Share with Chabad of Sampleton?")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("The Rabbi will be able to see the names and dates on this list, together with your name, email and phone, so he can remember your loved ones and reach out to you. You can turn this off at any time and it will be deleted from our server.")}</div></div><button class="btn btn-primary cta" id="shYes">${t("Yes, share")}</button><button class="btn btn-ghost" id="shNo">${t("Not now")}</button>`, (o) => { $("#shYes", o).onclick = () => { res(true); closeSheet(); }; $("#shNo", o).onclick = () => closeSheet(); }, () => res(false)));
    if (!ok) return;
    try { if (!(await ensureMember())) return; } catch (e) { return toast(errText(e)); }
    S.yzShare = true; save(); await yzSyncNow(); toast(tt("Shared with the Rabbi")); draw();
  } else { S.yzShare = false; save(); await yzSyncNow(); toast(tt("Sharing is off and your data was removed")); draw(); }
};
async function yzSyncNow() { clearTimeout(yzTimer); if (!API.members || PRACTICE || !S.mtoken) return; try { if (S.yzShare || S.yzRemind) await api("/yahrzeits", { method: "PUT", member: true, body: { entries: S.yz.map((e) => ({ id: e.id, name: e.name, relation: e.relation || "", day: e.day, month: e.month, year: e.year || null, notes: e.notes || "" })), share: S.yzShare } }); else await api("/yahrzeits", { method: "DELETE", member: true }); } catch (e) { toast(errText(e)); } }
A.yzRemindTgl = async () => {
  if (!S.yzRemind) {
    try { if (!(await ensureMember())) return; } catch (e) { return toast(errText(e)); }
    S.yzRemind = true; // set first so the subscription is sent with yahrzeit reminders on
    if (!(await pushEnable())) { S.yzRemind = false; save(); return; }
    save(); await yzSyncNow(); toast(tt("Yahrzeit reminders on")); draw();
  } else { S.yzRemind = false; save(); await yzSyncNow(); pushPrefsSoon(); draw(); }
};

// push notifications (work when the app is closed; need the server's notification keys)
const b64u = (s) => Uint8Array.from(atob((s + "=".repeat((4 - (s.length % 4)) % 4)).replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));
function pushPrefs() { return { lang: LANG, candle: { on: !!S.rem.candle.on, mins: S.rem.candle.mins }, streak: { on: !!S.rem.streak.on }, yahrzeit: { on: !!S.yzRemind, leads: S.yzLeads }, lastCoin: lastCoinYmd(), streakN: streak(), tz: (Intl.DateTimeFormat().resolvedOptions().timeZone || ""), weekly: { on: !!S.rem.weekly.on }, week: weekSummary(), custom: S.rem.custom.filter((r) => r.on).slice(0, 12).map((r) => ({ id: r.id, time: r.time, days: r.days, date: r.date || "", text: (r.text || "").slice(0, 120) })), dates: S.dates.map((x) => ({ id: x.id, name: x.name, kind: x.kind, m: x.m, d: x.d })) }; }
function weekSummary() { const since = Date.now() - 7 * 864e5, cs = S.history.filter((h) => h.kind === "coin" && h.t >= since); return { coins: cs.length, sum: r2(cs.reduce((a, h) => a + h.amt, 0)) }; }
const lastCoinYmd = () => { const h = S.history.find((x) => x.kind === "coin"); return h ? ymdLocal(new Date(h.t)) : ""; };
const pushOk = () => API.members && API.vapid && !PRACTICE && "serviceWorker" in navigator && "PushManager" in window;
async function pushSub() { const reg = await navigator.serviceWorker.ready; return reg.pushManager.getSubscription(); }
async function pushSync() {
  if (!pushOk() || !S.pushOn) return;
  try {
    const reg = await navigator.serviceWorker.ready; let sub = await reg.pushManager.getSubscription();
    if (!sub) { if (Notification.permission !== "granted") return; sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(API.vapid) }); }
    await api("/push/subscribe", { method: "POST", member: true, body: { subscription: sub.toJSON(), prefs: pushPrefs() } });
  } catch (e) {}
}
async function pushEnable() {
  if (!pushOk()) { toast(tt("Notifications aren’t available here yet")); return false; }
  if (S.pushOn && (await pushSub())) return true;
  if (!(await ensureNotify())) return false;
  try {
    const reg = await navigator.serviceWorker.ready, sub = (await reg.pushManager.getSubscription()) || (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(API.vapid) }));
    await api("/push/subscribe", { method: "POST", member: true, body: { subscription: sub.toJSON(), prefs: pushPrefs() } });
    S.pushOn = true; save(); return true;
  } catch (e) { toast(tt("Couldn’t turn on notifications")); return false; }
}
async function pushDisable() {
  S.pushOn = false; S.yzRemind = false; save();
  try { const sub = await pushSub(); if (sub) { const ep = sub.endpoint; await sub.unsubscribe(); await api("/push/unsubscribe", { method: "POST", body: { endpoint: ep } }); } } catch (e) {}
  yzSync();
}
let prefTimer = null;
function pushPrefsSoon() { clearTimeout(prefTimer); prefTimer = setTimeout(async () => { if (!S.pushOn) return; try { const sub = await pushSub(); if (sub) await api("/push/prefs", { method: "PUT", body: { endpoint: sub.endpoint, prefs: pushPrefs() } }); } catch (e) {} }, 800); }
function pushCard() {
  if (!pushOk()) return "";
  return `${sec(t("When the app is closed"))}${tg("pushTgl", "", t("Send reminders to this device"), t("Candle lighting, streak and yahrzeit reminders arrive even when the app is closed."), S.pushOn)}`;
}
A.pushTgl = async () => { if (S.pushOn) { await pushDisable(); toast(tt("Notifications off")); } else { try { if (await pushEnable()) toast(tt("Notifications on")); } catch (e) { toast(errText(e)); } } draw(); };



function notifBanner() {
  if (PRACTICE || !S.rem.candle.on || !("Notification" in window) || Notification.permission !== "default" || U.notifHidden || Date.now() - (S.notifAt || 0) < 7 * 864e5) return "";
  return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Turn on your Shabbat reminder")}</div><div class="h-s">${t("We’ll remind you to give tzedakah before candle lighting. You can turn it off anytime in Reminders.")}</div><div style="display:flex;gap:8px"><button class="btn btn-secondary" data-act="notifGo">${t("Turn on")}</button><button class="btn btn-ghost" data-act="notifNo">${t("Not now")}</button></div></div>`;
}
A.notifNo = () => { S.notifAt = Date.now(); save(); U.notifHidden = true; draw(); };
A.notifGo = async () => { U.notifHidden = true; try { if (pushOk()) await pushEnable(); else await ensureNotify(); } catch (e) {} S.notifAt = Date.now(); save(); draw(); };

// ---------- gentle, optional nudge to save your details (never required) ----------
const NUDGE_GAP = [3, 14, 30, 60]; // days to wait after each "Not now"
function nudgeDue() {
  if (PRACTICE || U.nudgeHidden || (API.accounts ? S.auth : S.email)) return false;
  const n = S.nudge || (S.nudge = { at: 0, n: 0, first: Date.now() }), gap = NUDGE_GAP[Math.min(n.n, NUDGE_GAP.length - 1)] * 864e5;
  const used = S.pushkas.reduce((a, p) => a + p.drops, 0) >= 3;
  return used && Date.now() - (n.at || n.first) > (n.at ? gap : 2 * 864e5);
}
function nudgeBanner() {
  if (!nudgeDue()) return "";
  if (API.accounts) return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Keep your pushka safe (optional)")}</div><div class="h-s">${t("Sign in with your email to have your own pushka on every device. You can use the whole app without this.")}</div><div style="display:flex;gap:8px"><button class="btn btn-secondary" data-act="nudgeYes">${t("Sign in")}</button><button class="btn btn-ghost" data-act="nudgeNo">${t("Not now")}</button></div></div>`;
  return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Save your details? (optional)")}</div><div class="h-s">${t("Get receipts, reminders and your list of yahrzeits kept safe. You can use the whole app without this.")}</div><div style="display:flex;gap:8px"><button class="btn btn-secondary" data-act="nudgeYes">${t("Save my details")}</button><button class="btn btn-ghost" data-act="nudgeNo">${t("Not now")}</button></div></div>`;
}
A.nudgeNo = () => { S.nudge = { at: Date.now(), n: ((S.nudge && S.nudge.n) || 0) + 1, first: (S.nudge && S.nudge.first) || Date.now() }; save(); U.nudgeHidden = true; draw(); };
A.nudgeYes = async () => { if (API.accounts) return signInSheet(""); U.nudgeHidden = true; if (await askDetails()) { if (API.members && !PRACTICE) { try { await memberSync(); } catch (e) {} } toast(tt("Saved. Thank you!")); } else U.nudgeHidden = false; draw(); };


// ---------- Chai Club: monthly donors, four levels, honor board ----------
const CLUB = [["bronze", 72, "Bronze"], ["silver", 180, "Silver"], ["gold", 360, "Gold"], ["platinum", 720, "Platinum"]];
const CLUB_RANGE = { bronze: "$72 – $179 a month", silver: "$180 – $359 a month", gold: "$360 – $719 a month", platinum: "$720 and above a month" };
const clubOf = (a) => { for (let i = CLUB.length - 1; i >= 0; i--) if (a >= CLUB[i][1]) return CLUB[i]; return null; };
const medalSvg = (id, w) => (window.ClubBoard ? ClubBoard.medal(id, w).outerHTML : "");
const clubSub = () => (API.subs || []).find((x) => x.club);
U.club = { amt: 180, data: null };
function clubWho() { const l = clubOf(U.club.amt); return l ? t("You’ll be a {level} member", { level: t(l[2]) }) : t("Thank you! Gifts under $72 a month aren’t listed on the board, but every gift matters."); }
PG.club = () => {
  const ex = clubSub(), exL = ex && clubOf(ex.gift || ex.amount), cur = clubOf(U.club.amt);
  const lv = CLUB.slice().reverse().map(([id, min, nm]) => `<button class="clv ${cur && cur[0] === id ? "sel" : ""}" data-act="clubLvl" data-v="${id}"><span>${medalSvg(id, 36)}</span><span class="grow" style="text-align:start"><b>${t(nm)}</b><br><small>${t(CLUB_RANGE[id])}</small></span><span class="clv-a">${money(min)}+</span></button>`).join("");
  return sub(tt("Chai Club"), `<div id="clubBoard"></div>
    <div id="joinHere" class="joinsec">${sec(t("Join the Chai Club"))}</div>
    <p class="body-p">${t("Join our community of monthly donors. Your steady gift lets Chabad of Sampleton plan ahead, and your medal is displayed on our honor board.")}</p>
    ${ex && exL ? `<div class="card" style="gap:12px">${medalSvg(exL[0], 40)}<div style="flex:1"><div class="card-title">${t("You’re a {level} member", { level: t(exL[2]) })}</div><div class="h-s">${t("{amt} monthly · {fund}", { amt: money(ex.gift || ex.amount), fund: t("Chai Club") })}</div><div class="h-s">${t("Choose a level below to change it.")}</div></div></div>` : ""}
    <div class="clvs">${lv}</div>
    <div class="field"><label for="clubAmt">${t("Monthly amount")}</label><div class="amt"><span>$</span><input class="input" id="clubAmt" type="number" min="1" step="1" inputmode="decimal" data-inp="clubAmt" value="${U.club.amt}"></div><div class="h-t" id="clubWho" style="margin-top:6px">${clubWho()}</div></div>
    ${cur ? `<div class="field"><label for="clubName">${t("Name on the honor board")}</label><input class="input" id="clubName" maxlength="60" data-inp="clubName" value="${esc(S.club.name || S.name)}" placeholder="${esc(tt("e.g. The Cohen Family"))}"></div>
    <label class="chk"><input type="checkbox" data-chg="clubShow" ${S.club.show ? "checked" : ""}><span>${t("Show my name on the board (otherwise I’m counted but not named)")}</span></label>` : ""}
    ${feeBox()}
    <div class="h-s" style="display:flex;align-items:center;gap:8px;font-size:13px">${ico(I.card, 16)}${API.enabled ? (API.card ? esc(cardLabel()) + ` <button class="link" data-act="cardChange">${t("Change")}</button>` : t("You’ll add a card when you give")) : t("Payment completes on our secure donation page")}</div>
    <button class="btn btn-primary cta" id="clubCta" data-act="clubJoin">${clubCta()}</button>
    ${TAXNOTE()}`);
};
const clubCta = () => t(clubSub() ? "Update my monthly gift to {amt}" : "Join monthly · {amt}", { amt: money(totalOf(U.club.amt)) });
A.clubLvl = (v) => { const l = CLUB.find((x) => x[0] === v), cur = clubOf(U.club.amt); if (!cur || cur[0] !== v) U.club.amt = l[1]; draw(); };
A.clubAmt = (v) => { const n = parseFloat(v); U.club.amt = n > 0 ? r2(n) : 0; const w = $("#clubWho"), c = $("#clubCta"); if (w) w.innerHTML = clubWho(); if (c) c.innerHTML = clubCta(); $$(".clv").forEach((b) => { const l = clubOf(U.club.amt); b.classList.toggle("sel", !!l && b.dataset.v === l[0]); }); };
A.clubName = (v) => { S.club.name = v; save(); };
A.clubShow = (v, el) => { S.club.show = el.checked; save(); };
A.clubJoin = () => {
  const a = U.club.amt; if (!(a >= 1) || a > MAX_CARD) return toast(tt("Enter a valid amount"));
  const name = (S.club.name || S.name || "").trim(); if (clubOf(a) && S.club.show && !name) { toast(tt("Please enter the name for the board.")); return $("#clubName") && $("#clubName").focus(); }
  S.club.name = name; save();
  startGift({ amt: a, fund: "chai", freq: "monthly", ded: "", fromPushka: false, method: "online", pid: P().id, club: { name, show: !!S.club.show && !!clubOf(a) }, replace: !!clubSub() });
};
A.clubJoinHome = () => { U.stack.push(U.page); U.page = "club"; draw(); };
function mountBoard() {
  const el = $("#clubBoard"); if (!el || !window.ClubBoard) return;
  const paint = (d) => { const e = $("#clubBoard"); if (e) { e.textContent = ""; e.appendChild(ClubBoard.render(d, { lang: LANG, onJoin: true })); } };
  paint(U.club.data);
  if (!U.club.loading && (!U.club.data || Date.now() - U.club.at > 60000)) { U.club.loading = true; ClubBoard.load("").then((d) => { U.club.data = d; U.club.at = Date.now(); }).catch(() => {}).finally(() => { U.club.loading = false; if (U.club.data) paint(U.club.data); }); }
}
// ---------- keep-coming-back features: week strip, intentions, today, occasions, achievements, auto-coin ----------
const coinDays = () => new Set(S.history.filter((h) => h.kind === "coin").map((h) => dkey(new Date(h.t))));
function weekStrip() { // the calendar week, Sunday to Shabbat
  const days = coinDays(), now = new Date(), out = [], sun = new Date(now); sun.setDate(now.getDate() - now.getDay());
  for (let i = 0; i < 7; i++) {
    const d = new Date(sun); d.setDate(sun.getDate() + i); const isToday = dkey(d) === dkey(now), future = d > now && !isToday;
    out.push(`<span class="wd ${days.has(dkey(d)) ? "on" : ""} ${isToday ? "today" : ""} ${future ? "future" : ""}" aria-label="${esc(greg(d))}${days.has(dkey(d)) ? " ✓" : ""}"><i>${esc(new Intl.DateTimeFormat(loc(), { weekday: "narrow" }).format(d))}</i><b></b></span>`);
  }
  return `<div class="week" role="img" aria-label="${esc(tt("This week"))}">${out.join("")}</div>`;
}
U.hm = { k: "honor", name: "" };
A.why = () => { U.hm = { k: "honor", name: "" }; sheet(`<div><h3>${t("Donate in honor or in memory of a loved one")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("The coin goes into your pushka, dedicated to someone special.")}</div></div>
  <div class="seg"><label><input type="radio" name="hmk" value="honor" data-chg="hmKind" checked>${t("In honor of")}</label><label><input type="radio" name="hmk" value="memory" data-chg="hmKind">${t("In memory of")}</label></div>
  <div class="field"><label for="hmN">${t("Name")}</label><input class="input" id="hmN" maxlength="60" data-inp="hmName" placeholder="${esc(tt("e.g. Rachel bat Sarah"))}"></div>
  <div class="amts three">${S.presets.map((a) => `<button class="btn btn-secondary" data-act="whyDrop" data-v="${a}">${money(a)}</button>`).join("")}</div>
  <div class="field"><label for="hmA">${t("Other amount")}</label><div style="display:flex;gap:8px"><div class="amt"><span>$</span><input class="input" id="hmA" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0.00"></div><button class="btn btn-primary" style="width:auto;padding:0 20px" data-act="whyCustom">${t("Add")}</button></div></div><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`, () => setTimeout(() => $("#hmN") && $("#hmN").focus(), 80)); };
A.hmKind = (v) => { U.hm.k = v === "memory" ? "memory" : "honor"; };
A.hmName = (v) => { U.hm.name = v.slice(0, 60); };
A.whyCustom = () => { const n = parseFloat($("#hmA").value); if (!(n > 0) || n > 100000) { toast(tt("Enter a valid amount")); return $("#hmA").focus(); } A.whyDrop(String(r2(n))); };
A.whyDrop = (v) => { const name = (U.hm.name || "").trim(); if (!name) { toast(tt("Please enter a name.")); return $("#hmN") && $("#hmN").focus(); } closeSheet(); drop(parseFloat(v), "coin", { k: U.hm.k, name }); };

function todayCard() {
  const q = QUOTES(), i = Math.floor(Date.now() / 864e5) % q.length, x = q[i]; if (!x) return "";
  return `<div class="card today" style="flex-direction:column;align-items:stretch;gap:8px"><div class="kicker">${t("Thought for today")}</div><blockquote class="big" style="margin:0"><p style="font-size:20px">“${esc(x.q)}”</p><footer>${esc(x.n)}</footer></blockquote><button class="btn btn-secondary" data-act="dropPrimary">${t("Drop a coin in response")} · ${money(S.presets[0])}</button></div>`;
}
const OCC = [["rh", "Rosh Hashanah", 1, "Tishri", "Give a coin for a sweet new year."], ["yk", "Erev Yom Kippur", 9, "Tishri", "Tzedakah before Yom Kippur is a longstanding custom."], ["sk", "Sukkos", 15, "Tishri", "Share the joy: help someone celebrate Sukkos."], ["ch", "Chanukah", 25, "Kislev", "Chanukah gelt: give coins each night."], ["tu", "Tu BiShvat", 15, "Shevat", "Plant something good: a gift for the New Year of the trees."], ["pu", "Purim", 14, "Adar II", "Matanos L’evyonim: gifts to those in need."], ["pe", "Pesach", 15, "Nisan", "Maos Chittim: help families celebrate Pesach."], ["sh", "Shavuos", 6, "Sivan", "Give in honor of receiving the Torah."], ["ta", "Tisha B’Av", 9, "Av", "A time to care for one another."]];
function nextOcc() {
  if (!HD) return null; const today = ymdLocal(new Date()); let best = null;
  OCC.forEach(([id, nm, day, month, note]) => { const o = HD.next({ day, month, year: null }, today); if (!o) return; const days = HD.daysBetween(today, o.date); if (days <= 30 && (!best || days < best.days)) best = { id, nm, note, days }; });
  return best;
}
function occasionCard() {
  const o = nextOcc(); if (!o) return "";
  return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="kicker">${t("Coming up")}</div><div class="card-title">${t(o.nm)} · ${esc(yzWhen(o.days))}</div><div class="h-s">${t(o.note)}</div><button class="btn btn-secondary" data-act="occGive" data-v="${o.id}">${t("Give for {name}", { name: t(o.nm) })}</button></div>`;
}
A.occGive = (v) => { const o = OCC.find((x) => x[0] === v); Object.assign(U, { giveFund: "holidays", giveAmt: 36, freq: "once", dedication: tt(o[1]).slice(0, 80) }); U.stack = []; U.page = "give"; draw(); };

// auto-coin: a small daily commitment that fills the pushka on its own
function autoCoins() {
  const a = S.auto; if (!a.on || PRACTICE) return; const today = ymdLocal(new Date()); if (a.last === today) return;
  const p = S.pushkas.find((x) => x.id === S.cur) || S.pushkas[0]; let n = 0, d = new Date(a.last ? a.last + "T12:00:00" : Date.now() - 864e5);
  while (ymdLocal(d) < today && n < 7) { d.setDate(d.getDate() + 1); const t0 = new Date(d); t0.setHours(9, 0, 0, 0); if (ymdLocal(t0) > today) break; p.balance = r2(p.balance + a.amt); p.drops++; pushHist({ kind: "coin", t: t0.getTime(), ttl: "auto", amt: a.amt, pid: p.id }); n++; }
  a.last = today; save(); if (n) setTimeout(() => { toast(tt("{n} auto-coins added to your pushka", { n })); draw(); }, 600);
}
A.setSnd = (v) => { S.snd = SND_OK.includes(v) ? v : "classic"; save(); clink(1, 0, 0); };
A.autoTgl = () => { S.auto.on = !S.auto.on; if (S.auto.on) S.auto.last = ymdLocal(new Date()); save(); draw(); };
A.autoAmt = (v) => { const n = parseFloat(v); if (n > 0 && n <= 1000) { S.auto.amt = r2(n); save(); } draw(); };

// achievements
function stats() {
  const coins = S.history.filter((h) => h.kind === "coin"), gifts = S.history.filter((h) => h.kind === "gift"), st = streak();
  return { coins: coins.length, coinSum: r2(coins.reduce((a, h) => a + h.amt, 0)), given: r2(gifts.reduce((a, h) => a + h.amt, 0)), gifts: gifts.length, emptied: gifts.some((h) => h.fp), st, monthly: !!(API.subs || []).length, club: !!clubSub(), yz: S.yz.length > 0 };
}
const BADGES = [
  ["first", "First coin", "Drop your first coin.", (x) => x.coins >= 1], ["c18", "Chai coins", "Drop 18 coins.", (x) => x.coins >= 18], ["c100", "A hundred coins", "Drop 100 coins.", (x) => x.coins >= 100],
  ["s3", "Three in a row", "A 3-day streak.", (x) => x.st >= 3], ["s7", "A full week", "A 7-day streak.", (x) => x.st >= 7], ["s18", "Chai streak", "An 18-day streak.", (x) => x.st >= 18],
  ["empty", "Pushka emptied", "Empty your pushka to Chabad.", (x) => x.emptied], ["gift", "First gift", "Make your first gift.", (x) => x.gifts >= 1],
  ["monthly", "Monthly giver", "Start a monthly gift.", (x) => x.monthly], ["club", "Chai Club", "Join the Chai Club.", (x) => x.club], ["yz", "Remembering", "Add a yahrzeit.", (x) => x.yz],
];
PG.awards = () => {
  const x = stats(), got = BADGES.filter((b) => b[3](x)).length;
  const tile = (n, l) => `<div class="stat"><div class="v">${n}</div><div class="k">${l}</div></div>`;
  return sub(tt("Achievements"), `<div class="stats">${tile(x.st, t("Day streak"))}${tile(x.coins, t("Coins dropped"))}${tile(money(x.given), t("Given so far"))}</div>
    <div class="h-t">${t("{n} of {total} badges earned", { n: got, total: BADGES.length })}</div>
    <div class="badges">${BADGES.map((b) => { const on = b[3](x); return `<div class="badge ${on ? "on" : ""}"><span class="bi">${ico(on ? I.check : I.lock, 22)}</span><b>${t(b[1])}</b><small>${t(b[2])}</small></div>`; }).join("")}</div>
    <p class="note">${t("Streaks count weekdays. Shabbat never breaks your streak.")}</p>`);
};

PG.kidsHome = () => {
  const p = P(), shown = U.fillFor === p.id ? U.fillShown : 0, frac = Math.min(p.balance / S.goal, 1), pct = Math.round(frac * 100);
  return `<div class="head home-head"><div class="hd-top"><div class="kicker">${t("Chabad of Sampleton")}</div></div><div class="hd-main"><h1>${t("Kids’ pushka")}</h1></div></div>
  <div class="scroll"><div class="col">
    <div class="tin"><div class="anchor" id="coinAnchor"></div><div class="zoom"><div class="wrap" data-act="dropPrimary" role="button" tabindex="0" aria-label="${esc(tt("Drop {amt} in the pushka", { amt: money(S.presets[0]) }))}">${tin(shown)}<div class="bal">${money2(p.balance)}</div></div></div></div>
    <div class="progress"><div class="pg-track"><div class="pg-fill" id="progFill" style="width:${(U.fillFor === p.id ? U.pctShown : 0)}%"></div></div><div class="pg-t">${t("{n}% full", { n: pct })}</div></div>
    <div class="kidcoins">${S.presets.map((a) => `<button class="kidcoin" data-act="drop" data-v="${a}" aria-label="${esc(money(a))}">${money(a)}</button>`).join("")}</div>
    ${kidsStickers()}
  </div></div>`;
};
// ---------- the honor board is for everyone; community, announcements, occasions, kids, skins, cards ----------
const SND = { classic: [2100, 900, [[1, 0.22, 0.5], [1.51, 0.12, 0.35], [2.76, 0.07, 0.2]]], chime: [880, 440, [[1, 0.2, 1.1], [2, 0.1, 0.8], [3, 0.05, 0.5]]], soft: [520, 120, [[1, 0.25, 0.7], [1.5, 0.08, 0.5]]] };
function boardCard() {
  const d = U.club.data, total = d ? d.total : 0, names = d ? d.members.slice(0, 3).map((m) => m.name) : [];
  const counts = ["platinum", "gold", "silver", "bronze"].map((l) => `<span class="bc">${medalSvg(l, 22)}<b>${d ? d.counts[l] || 0 : "·"}</b></span>`).join("");
  return `<button class="card boardcard" data-act="go" data-v="board"><div style="flex:1;text-align:start"><div class="card-title">${t("Our monthly donors")}</div><div class="h-s">${total ? t("{n} monthly donors keep our community going.", { n: total }) : t("Join the Chai Club and see your medal on our board.")}</div>${names.length ? `<div class="bn">${names.map((n) => esc(n)).join(" · ")}</div>` : ""}<div class="bcs">${counts}</div></div>${chev()}</button>`;
}
A.clubJoinPage = () => { if (U.page === "club") { const j = $("#joinHere"); if (j) j.scrollIntoView({ behavior: "smooth", block: "start" }); return; } U.stack = ["give"]; U.page = "club"; draw(); };
PG.board = () => sub(tt("Chai Club honor board"), `<p class="body-p">${t("These families give every month to keep Chabad of Sampleton going. Join by name, or anonymously: you still get your medal.")}</p><div id="clubBoard"></div>`);

// community counter (anonymous totals only) and announcements from the Rabbi
let coinBuf = { n: 0, cents: 0 }, coinTimer = null;
function reportCoin(a) {
  if (PRACTICE || !API.enabled && !API.members) return; coinBuf.n++; coinBuf.cents += Math.round(a * 100); clearTimeout(coinTimer);
  coinTimer = setTimeout(() => { const b = coinBuf; coinBuf = { n: 0, cents: 0 }; api("/community/coins", { method: "POST", body: b }).catch(() => {}); }, 4000);
}
function commCard() {
  const n = (U.comm && U.comm.weekCoins) || 0; if (n < 5) return "";
  return `<div class="card" style="gap:12px"><div class="commn">${n.toLocaleString(loc())}</div><div><div class="card-title">${t("coins dropped this week")}</div><div class="h-s">${t("by our community. Every coin counts.")}</div></div></div>`;
}
function annCards() {
  return (U.ann || []).slice(0, 2).map((a) => {
    const pct = a.goal > 0 ? Math.min(100, Math.round((a.raised / a.goal) * 100)) : 0;
    return `<div class="card ann ${a.kind}" style="flex-direction:column;align-items:stretch;gap:8px">${a.kind === "match" ? `<span class="tag-accent" style="align-self:flex-start">${t("Matching day")}</span>` : ""}<div class="card-title">${esc(a.title)}</div>${a.body ? `<div class="h-s" style="font-size:13px">${esc(a.body)}</div>` : ""}${a.kind === "cause" && a.goal > 0 ? `<div class="pg-track"><div class="pg-fill" style="width:${pct}%"></div></div><div class="h-s">${t("{raised} of {goal} raised", { raised: money(a.raised), goal: money(a.goal) })}</div>` : ""}${a.fund ? `<button class="btn btn-secondary" data-act="annGive" data-v="${esc(a.id)}">${t(a.kind === "cause" ? "Give to this cause" : "Give now")}</button>` : ""}</div>`;
  }).join("");
}
A.annGive = (v) => { const a = (U.ann || []).find((x) => x.id === v); if (!a) return; Object.assign(U, { giveFund: a.fund, giveAmt: 36, freq: "once", dedication: a.title.slice(0, 80) }); U.stack = []; U.page = "give"; draw(); };
async function loadExtras() {
  try { const c = await fetch("/api/community"); if (c.ok) U.comm = await c.json(); } catch (e) {}
  try { const a = await fetch("/api/announcements"); if (a.ok) U.ann = (await a.json()).items || []; } catch (e) {}
  try { if (window.ClubBoard && !U.club.data) { U.club.data = await ClubBoard.load(""); U.club.at = Date.now(); } } catch (e) {}
  if (U.page === "home") draw();
}

// who is giving (family), streak sharing, streak milestones
function familyChips() {
  if (!S.family.length) return "";
  return `<div class="chips" aria-label="${esc(tt("Who is giving?"))}"><button class="chip ${!U.by ? "on" : ""}" data-act="by" data-v="">${t("Me")}</button>${S.family.map((n) => `<button class="chip ${U.by === n ? "on" : ""}" data-act="by" data-v="${esc(n)}">${esc(n)}</button>`).join("")}</div>`;
}
A.by = (v) => { U.by = v; draw(); };
A.famAdd = () => sheet(`<h3>${t("Add a family member")}</h3><div class="field"><label for="fn">${t("Name")}</label><input class="input" id="fn" maxlength="20"></div>${sheetBtns(["famSave", t("Add")], ["closeSheet", t("Cancel")])}`, () => setTimeout(() => $("#fn") && $("#fn").focus(), 60));
A.famSave = () => { const n = $("#fn").value.trim(); if (!n) return toast(tt("Enter a name")); if (S.family.length < 8 && !S.family.includes(n)) S.family.push(n); save(); closeSheet(); draw(); };
A.famDel = (v) => { S.family = S.family.filter((x) => x !== v); if (U.by === v) U.by = ""; save(); draw(); };
A.shareStreak = async () => { const st = streak(), d = { title: tt("Chabad of Sampleton · My Pushka"), text: tt("I’m on a {n}-day tzedakah streak! Sponsor a day of giving with me.", { n: st }), url: location.origin + "/pushka/?go=give" }; try { if (navigator.share) await navigator.share(d); else { await navigator.clipboard.writeText(d.text + " " + d.url); toast(tt("Link copied")); } } catch (e) {} };
function milestone() { const st = streak(); if ([3, 7, 18, 36, 100].includes(st) && !S.ms["s" + st]) { S.ms["s" + st] = 1; save(); setTimeout(() => { fanfare(); confetti(); toast(tt("{n}-day streak! Keep going.", { n: st })); }, 900); } }

// birthdays and anniversaries
const nextCivil = (m, d) => { const now = new Date(), y = now.getFullYear(); let t0 = new Date(y, m - 1, d); if (t0 < new Date(y, now.getMonth(), now.getDate())) t0 = new Date(y + 1, m - 1, d); return Math.round((t0 - new Date(y, now.getMonth(), now.getDate())) / 864e5); };
PG.occasions = () => {
  const rows = S.dates.map((x) => ({ x, n: nextCivil(x.m, x.d) })).sort((a, b) => a.n - b.n).map(({ x, n }) => `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px"><div><div class="card-title">${esc(x.name)}</div><div class="h-s">${t(x.kind === "anniversary" ? "Anniversary" : "Birthday")} · ${esc(new Intl.DateTimeFormat(loc(), { month: "long", day: "numeric" }).format(new Date(2000, x.m - 1, x.d)))}</div></div><button class="icon-btn sm" data-act="dateDel" data-v="${esc(x.id)}" aria-label="${t("Delete")}">${ico(I.trash, 18)}</button></div><div class="h-t">${esc(yzWhen(n))}</div><button class="btn btn-secondary" data-act="dateGive" data-v="${esc(x.id)}">${t("Give in their honor")}</button></div>`).join("");
  return sub(tt("Birthdays and anniversaries"), `<p class="body-p">${t("Add the dates of people you love. We’ll remind you a week before and on the day, so you can give tzedakah in their honor.")}</p>${rows || `<div class="rowp">${t("No dates yet.")}</div>`}<button class="btn btn-primary cta" data-act="dateAdd">${ico(I.plus, 16)} ${t("Add a date")}</button>`);
};
A.dateAdd = () => { U.dk = "birthday"; sheet(`<h3>${t("Add a date")}</h3><div class="field"><label for="dnm">${t("Name")}</label><input class="input" id="dnm" maxlength="60"></div><div class="seg"><label><input type="radio" name="dk" value="birthday" data-chg="dateKind" checked>${t("Birthday")}</label><label><input type="radio" name="dk" value="anniversary" data-chg="dateKind">${t("Anniversary")}</label></div><div class="field"><label for="ddt">${t("Date")}</label><input class="input" id="ddt" type="date"></div><div id="dErr" class="err" role="alert"></div><button class="btn btn-primary cta" data-act="dateSave">${t("Save")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`, () => setTimeout(() => $("#dnm") && $("#dnm").focus(), 60)); };
A.dateKind = (v) => { U.dk = v === "anniversary" ? "anniversary" : "birthday"; };
A.dateSave = () => { const name = $("#dnm").value.trim(), v = $("#ddt").value; if (!name) { $("#dErr").textContent = tt("Please enter a name."); return; } const m = /^\d{4}-(\d{2})-(\d{2})$/.exec(v); if (!m) { $("#dErr").textContent = tt("Please enter a valid date."); return; } if (S.dates.length >= 20) { $("#dErr").textContent = tt("You can keep up to 20 dates."); return; } S.dates.push({ id: uid() + uid(), name, kind: U.dk, m: +m[1], d: +m[2] }); save(); closeSheet(); pushPrefsSoon(); draw(); };
A.dateDel = (v) => { S.dates = S.dates.filter((x) => x.id !== v); save(); pushPrefsSoon(); draw(); };
A.dateGive = (v) => { const x = S.dates.find((y) => y.id === v); if (!x) return; Object.assign(U, { giveFund: "general", giveAmt: 36, freq: "once", dedication: tt("In honor of {name}", { name: x.name }).slice(0, 80) }); U.stack = []; U.page = "give"; draw(); };
function dateTick(at, within) {
  if (S.pushOn) return; const d = new Date();
  S.dates.forEach((x) => [7, 0].forEach((lead) => { const t0 = new Date(d.getFullYear(), d.getMonth(), d.getDate() + lead); if (t0.getMonth() + 1 === x.m && t0.getDate() === x.d) { const k = "dt" + x.id + dkey(d) + lead; if (within(at(9, 0)) && !S.notified[k]) { mark(k); notify(lead === 0 ? tt("Today: {name}’s {kind}. Give tzedakah in their honor?", { name: x.name, kind: tt(x.kind === "anniversary" ? "anniversary" : "birthday") }) : tt("{name}’s {kind} is in a week. Give tzedakah in their honor?", { name: x.name, kind: tt(x.kind === "anniversary" ? "anniversary" : "birthday") })); } } }));
}

// travelling coin
A.travel = () => sheet(`<h3>${t("Traveling soon?")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("It’s a lovely custom to give a coin before a journey. We’ll remind you the morning you leave.")}</div><div class="field"><label for="trd">${t("Departure date")}</label><input class="input" id="trd" type="date"></div>${sheetBtns(["travelSave", t("Remind me")], ["closeSheet", t("Cancel")])}`);
A.travelSave = async () => { const v = $("#trd").value; if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return toast(tt("Please enter a valid date.")); closeSheet(); if (!(await ensureNotify())) return; S.rem.custom.push({ id: uid(), sid: "trip" + v, time: "08:00", days: "once", date: v, text: tt("Safe travels! A coin for the journey?"), on: true }); save(); if (S.pushOn) pushPrefsSoon(); toast(tt("Reminder added")); draw(); };

// seasonal look
function season() {
  if (!HD || !S.seasonal) return null; const today = ymdLocal(new Date()), p = HD.parts(today), leap = HD.isLeap(p.year);
  if ((p.month === "Kislev" && p.day >= 25) || (p.month === "Tevet" && p.day <= 3)) { for (let i = 0; i < 9; i++) { const q = HD.parts(HD.addDays(today, -i)); if (q.month === "Kislev" && q.day === 25) return { id: "chanukah", n: Math.min(i + 1, 8) }; } }
  if (p.month === (leap ? "Adar II" : "Adar") && p.day >= 13 && p.day <= 15) return { id: "purim" };
  if (p.month === "Tishri" && p.day <= 2) return { id: "rh" };
  if (p.month === "Tishri" && p.day >= 15 && p.day <= 23) return { id: "sukkos" };
  if (p.month === "Nisan" && p.day >= 15 && p.day <= 22) return { id: "pesach" };
  if (p.month === "Sivan" && p.day >= 6 && p.day <= 7) return { id: "shavuos" };
  return null;
}
const SEASON_GREET = { chanukah: "Chag Urim Sameach", purim: "Purim Sameach", rh: "Shanah Tovah", sukkos: "Chag Sukkos Sameach", pesach: "Chag Pesach Sameach", shavuos: "Chag Shavuos Sameach" };
function seasonOrn(s) {
  if (!s) return "";
  let orn = "";
  if (s.id === "chanukah") { const xs = [10, 28, 46, 64, 82, 118, 136, 154, 172]; orn = `<svg viewBox="0 0 182 64" width="112" height="40" aria-hidden="true"><path d="M8 40q0 22 83 22t83-22" fill="none" stroke="#e6b955" stroke-width="3" stroke-linecap="round"/><path d="M91 62V36" stroke="#e6b955" stroke-width="3"/>${xs.map((x, i) => { const sh = i === 4, lit = sh || (i < 4 ? 4 - i <= s.n : i - 4 <= s.n), y = sh ? 8 : 20; return `<rect x="${(sh ? 91 : x + 4) - 2}" y="${y + 6}" width="4" height="${sh ? 28 : 16}" rx="1" fill="#f6efdc"/>${lit ? `<path d="M${sh ? 91 : x + 4} ${y - 8}q6 8 0 14q-6 -6 0 -14z" fill="#ffd66b" class="flame"/>` : ""}`; }).join("")}</svg>`; }
  return `<div class="season" data-s="${s.id}">${orn}<div class="greet">${t(SEASON_GREET[s.id])}</div></div>`;
}

// kids mode (grown-up PIN)
const sha = async (s) => { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("pushka:" + s)); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join(""); };
A.kidsOn = () => sheet(`<h3>${t("Kids mode")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("Big coin buttons and stickers, with no giving or settings. Choose a 4-digit grown-up code to leave kids mode.")}</div><div class="field"><label for="kp">${t("Grown-up code")}</label><input class="input" id="kp" inputmode="numeric" maxlength="4" pattern="[0-9]*" autocomplete="off"></div><div id="kErr" class="err" role="alert"></div><button class="btn btn-primary cta" data-act="kidsStart">${t("Start kids mode")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.kidsStart = async () => { const v = $("#kp").value; if (!/^\d{4}$/.test(v)) { $("#kErr").textContent = tt("Enter exactly 4 digits."); return; } S.kids.pin = await sha(v); S.kids.on = true; save(); closeSheet(); U.page = "home"; U.stack = []; draw(); };
A.kidsExit = () => sheet(`<h3>${t("Grown-ups only")}</h3><div class="field"><label for="kp2">${t("Grown-up code")}</label><input class="input" id="kp2" inputmode="numeric" maxlength="4" pattern="[0-9]*" autocomplete="off"></div><div id="kErr2" class="err" role="alert"></div><button class="btn btn-primary cta" data-act="kidsUnlock">${t("Leave kids mode")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`, () => setTimeout(() => $("#kp2") && $("#kp2").focus(), 60));
A.kidsUnlock = async () => { if ((await sha($("#kp2").value)) === S.kids.pin) { S.kids.on = false; save(); closeSheet(); draw(); } else $("#kErr2").textContent = tt("That code isn’t right."); };
const STAR = ["#f6d77f", "#9fc0e3", "#f3a6a0", "#a8d8a0", "#d7b4f0", "#ffb86b"];
const kidsStickers = () => { const n = Math.min(24, Math.floor((S.kids.coins || 0) / 3)); return `<div class="stickers" aria-label="${esc(tt("Your stickers"))}">${Array.from({ length: n }, (_, i) => `<svg viewBox="0 0 24 24" width="34" height="34" aria-hidden="true"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z" fill="${STAR[i % STAR.length]}" stroke="#fff" stroke-width="1"/></svg>`).join("") || `<div class="h-s">${t("Drop 3 coins to win a sticker!")}</div>`}</div>`; };

// honor card (picture to share) and giving statement
async function honorCardBlob(text, from) {
  const c = document.createElement("canvas"); c.width = 1080; c.height = 1350; const g = c.getContext("2d");
  const bg = g.createLinearGradient(0, 0, 0, 1350); bg.addColorStop(0, "#1b3a70"); bg.addColorStop(1, "#0b1730"); g.fillStyle = bg; g.fillRect(0, 0, 1080, 1350);
  const gold = g.createLinearGradient(0, 0, 1080, 1350); gold.addColorStop(0, "#f6d983"); gold.addColorStop(.5, "#c58f2a"); gold.addColorStop(1, "#f3d27a");
  g.strokeStyle = gold; g.lineWidth = 6; g.strokeRect(50, 50, 980, 1250); g.lineWidth = 2; g.strokeRect(72, 72, 936, 1206);
  g.textAlign = "center"; g.fillStyle = gold; g.font = "700 220px 'Frank Ruhl Libre','Cormorant Garamond',Georgia,serif"; g.fillText("צדקה", 540, 420);
  g.fillStyle = "#f6f1e4"; g.font = "400 58px 'Cormorant Garamond',Georgia,serif"; g.fillText(tt("A gift of tzedakah was made"), 540, 560);
  g.fillStyle = "#f6d77f"; g.font = "600 84px 'Cormorant Garamond',Georgia,serif";
  const words = text.split(" "); let line = "", y = 740; const lines = []; words.forEach((w) => { const t2 = line ? line + " " + w : w; if (g.measureText(t2).width > 820 && line) { lines.push(line); line = w; } else line = t2; }); lines.push(line);
  lines.slice(0, 4).forEach((l, i) => g.fillText(l, 540, y + i * 100));
  if (from) { g.fillStyle = "#dbe3f2"; g.font = "italic 400 54px 'Cormorant Garamond',Georgia,serif"; g.fillText(tt("with love from {name}", { name: from }), 540, 1100); }
  g.fillStyle = gold; g.font = "600 46px 'Cormorant Garamond',Georgia,serif"; g.fillText("Chabad of Sampleton", 540, 1215);
  return new Promise((res) => c.toBlob(res, "image/png"));
}
A.honorCard = async () => {
  const text = (U.lastGift && U.lastGift.ded) || ""; if (!text) return; const blob = await honorCardBlob(text, S.name), file = new File([blob], "honor-card.png", { type: "image/png" });
  try { if (navigator.canShare && navigator.canShare({ files: [file] })) return await navigator.share({ files: [file], title: tt("A gift of tzedakah was made") }); } catch (e) { if (e && e.name === "AbortError") return; }
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "honor-card.png"; document.body.append(a); a.click(); a.remove(); toast(tt("Card saved to your device"));
};
const giftYears = () => [...new Set(S.history.filter((h) => h.kind === "gift").map((h) => new Date(h.t).getFullYear()))].sort((a, b) => b - a);
PG.statement = () => {
  const ys = giftYears(), y = ys.includes(U.stY) ? U.stY : ys[0] || new Date().getFullYear(), rows = S.history.filter((h) => h.kind === "gift" && new Date(h.t).getFullYear() === y).sort((a, b) => a.t - b.t), tot = rows.reduce((a, h) => a + h.amt, 0);
  return sub(tt("Giving statement"), `${ys.length > 1 ? `<div class="chips">${ys.map((x) => `<button class="chip ${x === y ? "on" : ""}" data-act="stYear" data-v="${x}">${x}</button>`).join("")}</div>` : ""}
    <div class="card" style="flex-direction:column;align-items:flex-start;gap:2px"><div class="kicker">${t("Total given in {year}", { year: y })}</div><div style="font:400 40px var(--heading)">${money2(tot)}</div><div class="h-s">${rows.length === 1 ? t("1 gift") : t("{n} gifts", { n: rows.length })}</div></div>
    <div>${rows.map((h) => `<div class="row-btn" style="cursor:default"><div class="grow"><div class="h-t">${esc(tt(fundOf(h.fund).name))}</div><div class="h-s">${esc(new Intl.DateTimeFormat(loc(), { dateStyle: "medium" }).format(new Date(h.t)))}${h.freq === "monthly" ? " · " + t("Monthly") : ""}${h.ded ? " · " + esc(h.ded) : ""}</div></div><div class="h-a">${money2(h.amt)}</div></div>`).join("") || `<div class="rowp">${t("No gifts in this year yet.")}</div>`}</div>
    <div class="row2 noprint"><button class="btn btn-secondary" data-act="stCsv" data-v="${y}">${t("Download spreadsheet")}</button><button class="btn btn-secondary" data-act="stPrint">${t("Print")}</button></div>
    <p class="note">${t("This is a summary of gifts made in this app. Official tax receipts are emailed by Stripe for every gift. Chabad of Sampleton is a 501(c)(3), Tax ID {ein}.", { ein: ORG_EIN })}</p>`);
};
A.stYear = (v) => { U.stY = +v; draw(); };
A.stPrint = () => window.print();
A.stCsv = (v) => {
  const cell = (x) => { let s = String(x == null ? "" : x); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  const rows = S.history.filter((h) => h.kind === "gift" && new Date(h.t).getFullYear() === +v).sort((a, b) => a.t - b.t);
  const csv = [["Date", "Fund", "Amount", "Frequency", "Note"].map(cell).join(",")].concat(rows.map((h) => [new Date(h.t).toISOString().slice(0, 10), fundOf(h.fund).name, h.amt.toFixed(2), h.freq || "once", h.ded || ""].map(cell).join(","))).join("\r\n");
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); a.download = "giving-" + v + ".csv"; document.body.append(a); a.click(); a.remove();
};

// undo a mistaken coin, or reset the pushka
function removeCoinAt(i) {
  const h = S.history[i]; if (i < 0 || !h || h.kind !== "coin") return;
  const p = S.pushkas.find((x) => x.id === h.pid) || P(); p.balance = Math.max(0, r2(p.balance - h.amt)); p.drops = Math.max(0, p.drops - 1);
  S.history.splice(i, 1); save(); draw(); if (S.pushOn) pushPrefsSoon(); toast(tt("Coin removed"));
}
A.undoCoin = (v) => removeCoinAt(S.history.findIndex((h) => h.kind === "coin" && String(h.t) === String(v)));
A.resetAsk = (v) => {
  const p = S.pushkas.find((x) => x.id === v) || P(), n = S.history.filter((h) => h.kind === "coin" && h.pid === p.id && h.t > S.lastEmptied).length;
  sheet(`<div><h3>${t("Reset {name}?", { name: esc(pTitle(p)) })}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("This sets the pushka back to $0.00 and removes the {n} coins added since you last emptied it. Gifts you already made are not affected.", { n })}</div></div><button class="btn btn-primary cta" data-act="resetGo" data-v="${esc(p.id)}" style="color:#9b1c5a">${t("Reset pushka")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
};
A.resetGo = (v) => { const p = S.pushkas.find((x) => x.id === v) || P(); S.history = S.history.filter((h) => !(h.kind === "coin" && h.pid === p.id && h.t > S.lastEmptied)); p.balance = 0; p.drops = 0; U.fillFor = ""; save(); closeSheet(); draw(); if (S.pushOn) pushPrefsSoon(); toast(tt("Pushka reset")); };

// ---------- sign in, and your own pushka on every device (optional) ----------
const DEVICE_KEYS = ["token", "mtoken", "msig", "auth", "rev", "dirty", "synced", "bio", "notified", "candles", "pushOn"];
const stateDoc = () => { const d = JSON.parse(JSON.stringify(S)); DEVICE_KEYS.forEach((k) => delete d[k]); return d; };
const hasLocal = () => S.history.length > 0 || S.pushkas.some((p) => p.balance > 0 || p.drops > 0);
function applyDoc(doc, rev) {
  const keep = {}; DEVICE_KEYS.forEach((k) => { if (k in S) keep[k] = S[k]; });
  noSync = true; S = normalize(Object.assign({}, doc, keep)); S.rev = rev; S.dirty = false; noSync = false; persist(); applyLang(); draw();
}
let syncT = 0, syncing = false, syncAgain = false;
function syncSoon() { if (syncing) { syncAgain = true; return; } clearTimeout(syncT); syncT = setTimeout(() => pushState(), 2500); }
async function pushState(force) {
  if (!S.auth || !S.mtoken || syncing || PRACTICE) return false; syncing = true; clearTimeout(syncT); let ok = false;
  try { const r = await api("/account/state", { method: "PUT", member: true, body: { state: stateDoc(), baseRev: S.rev || 0, force: force === true } }); S.rev = r.rev; S.dirty = false; persist(); ok = true; }
  catch (e) { if (e.status === 409 && e.data && e.data.state) { applyDoc(e.data.state, e.data.rev); toast(tt("Updated from your other device")); ok = true; } }
  syncing = false; if (syncAgain) { syncAgain = false; syncSoon(); }
  return ok;
}
async function pullState() {
  if (!S.auth || !S.mtoken || PRACTICE || syncing) return;
  try { if (S.dirty) return void (await pushState()); const r = await api("/account/state", { member: true }); if (r.state && r.rev > (S.rev || 0)) applyDoc(r.state, r.rev); } catch (e) {}
}
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") pullState(); });
window.addEventListener("online", () => pullState());
const authErr = (e) => (e.code === "network" ? tt("No connection. Please try again.") : tt(e.message));

function signInSheet(email, err) {
  sheet(`<div><h3>${t("Sign in")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("Enter your email and we’ll send you a 6-digit code. No password needed. Your pushka is saved to your account and follows you to any phone or computer.")}</div></div>
    <div class="field"><label for="si1">${t("Email")}</label><input class="input" id="si1" type="email" autocomplete="email" inputmode="email" maxlength="254" value="${esc(email || S.email)}"></div>
    <div id="siErr" class="err" role="alert">${err ? esc(err) : ""}</div><button class="btn btn-primary cta" id="siGo">${t("Send me a code")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`,
  (o) => {
    const go = async () => {
      const e = $("#si1", o).value.trim().toLowerCase(), er = $("#siErr", o), b = $("#siGo", o);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) { er.textContent = tt("Please enter a valid email address."); return; }
      b.disabled = true; er.textContent = "";
      try { await api("/auth/request", { method: "POST", body: { email: e, lang: LANG } }); codeSheet(e); }
      catch (x) { er.textContent = authErr(x); b.disabled = false; }
    };
    $("#siGo", o).onclick = go; $("#si1", o).onkeydown = (ev) => { if (ev.key === "Enter") go(); }; setTimeout(() => { try { $("#si1", o).focus(); } catch (e) {} }, 50);
  });
}
function codeSheet(email) {
  sheet(`<div><h3>${t("Enter your code")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("We sent a 6-digit code to {email}. It works for 10 minutes.", { email: `<b dir="ltr">${esc(email)}</b>` })}</div></div>
    <div class="field"><label for="si2">${t("6-digit code")}</label><input class="input" id="si2" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*" style="letter-spacing:.35em;font-size:22px;text-align:center;direction:ltr"></div>
    <div id="siErr" class="err" role="alert"></div><button class="btn btn-primary cta" id="siGo">${t("Sign in")}</button>
    <button class="btn btn-ghost" id="siAgain">${t("Send a new code")}</button><button class="btn btn-ghost" id="siOther">${t("Use a different email")}</button>`,
  (o) => {
    const er = $("#siErr", o), go = async () => {
      const code = $("#si2", o).value.replace(/\s/g, ""); if (!/^\d{6}$/.test(code)) { er.textContent = tt("Please enter the 6-digit code."); return; }
      $("#siGo", o).disabled = true; er.textContent = "";
      try { await finishSignIn(await api("/auth/verify", { method: "POST", body: { email, code } })); }
      catch (x) { er.textContent = authErr(x); $("#siGo", o).disabled = false; }
    };
    $("#siGo", o).onclick = go; $("#si2", o).oninput = (ev) => { ev.target.value = ev.target.value.replace(/\D/g, "").slice(0, 6); if (ev.target.value.length === 6) go(); };
    $("#siAgain", o).onclick = async () => { er.textContent = ""; try { await api("/auth/request", { method: "POST", body: { email, lang: LANG } }); er.textContent = tt("A new code is on its way."); } catch (x) { er.textContent = authErr(x); } };
    $("#siOther", o).onclick = () => signInSheet("");
    setTimeout(() => { try { $("#si2", o).focus(); } catch (e) {} }, 50);
  });
}
async function finishSignIn(r) {
  S.mtoken = r.token; S.auth = { email: r.email, at: Date.now() }; if (!S.email) S.email = r.email; if (!S.name && r.name) S.name = r.name;
  if (r.stripeToken) { S.token = r.stripeToken; S.synced = ""; API.card = null; API.subs = null; }
  S.msig = [S.name, S.email, S.phone, S.address, S.token].join("|"); S.rev = 0; persist();
  if (API.enabled && S.token) refreshCard().catch(() => {});
  if (r.hasState && hasLocal()) return conflictSheet();
  if (r.hasState) { const st = await api("/account/state", { member: true }); applyDoc(st.state, st.rev); closeSheet(); return toast(tt("Welcome back! Your pushka is restored.")); }
  S.dirty = true; await pushState(); closeSheet(); draw(); toast(tt("Signed in. Your pushka is saved."));
}
function conflictSheet() {
  sheet(`<div><h3>${t("Which pushka should we keep?")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("Your account already has a saved pushka, and this device has one too. Choose one. The other will be replaced.")}</div></div>
    <button class="btn btn-primary cta" data-act="signCloud">${t("Use my saved pushka")}</button><button class="btn btn-ghost" data-act="signLocal">${t("Use this device’s pushka")}</button>`, null, null, true);
}
A.signIn = () => signInSheet("");
A.signCloud = async () => { try { const st = await api("/account/state", { member: true }); applyDoc(st.state, st.rev); closeSheet(); toast(tt("Welcome back! Your pushka is restored.")); } catch (e) { toast(authErr(e)); } };
A.signLocal = async () => { S.dirty = true; if (await pushState(true)) { closeSheet(); draw(); toast(tt("Signed in. Your pushka is saved.")); } else toast(tt("No connection. Please try again.")); };
A.signOutAsk = () => sheet(`<div><h3>${t("Sign out?")}</h3><div class="h-s" style="font-size:13px;margin-top:4px">${t("Your pushka stays saved in your account. This device will be cleared so the next person starts fresh. Sign in again any time to get it back.")}</div></div>
  <button class="btn btn-primary cta" data-act="signOutGo">${t("Sign out")}</button><button class="btn btn-ghost" data-act="closeSheet">${t("Cancel")}</button>`);
A.signOutGo = async () => {
  if (S.dirty && !(await pushState())) return toast(tt("We couldn’t save your latest changes. Check your connection and try again."));
  noSync = true; const lang = S.lang; try { localStorage.removeItem(KEY); } catch (e) {} S = normalize({ lang }); noSync = false; API.card = null; API.subs = null;
  persist(); applyLang(); closeSheet(); U.stack = []; U.page = "home"; draw(); toast(tt("Signed out"));
};
function accountCard() {
  if (!API.accounts) return "";
  if (S.auth) return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Signed in")}</div><div class="h-s" dir="ltr" style="text-align:start">${esc(S.auth.email)}</div><div class="h-s">${S.dirty ? t("Saving…") : t("Your pushka is saved to your account and follows you to any device.")}</div><button class="btn btn-ghost" data-act="signOutAsk">${t("Sign out")}</button></div>`;
  return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Keep your pushka on every device")}</div><div class="h-s">${t("Sign in with your email to have your own pushka that follows you to any phone or computer. No password.")}</div><button class="btn btn-primary cta" data-act="signIn">${t("Sign in")}</button></div>`;
}
const standalone = () => (window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone === true;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); U.installEv = e; if (U.drawn === "profile") draw(); });
window.addEventListener("appinstalled", () => { U.installEv = null; });
function installCard() {
  if (PRACTICE || standalone()) return "";
  return `<div class="card" style="flex-direction:column;align-items:stretch;gap:6px"><div class="card-title">${t("Get the app")}</div><div class="h-s">${t("Add My Pushka to your home screen to open it like an app.")}</div><button class="btn btn-ghost" data-act="install">${t("Install the app")}</button></div>`;
}
A.install = async () => {
  if (U.installEv) { const e = U.installEv; U.installEv = null; try { e.prompt(); await e.userChoice; } catch (x) {} return draw(); }
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
  infoSheet(tt("Install the app"), ios ? t("In Safari, tap the Share button, then “Add to Home Screen.”") : t("In your browser menu, choose “Install app” or “Add to Home Screen.”"));
};

// ---------- start ----------
applyLang();
// From the website's "sponsor in honor / in memory" buttons: /pushka/?go=give&fund=general&amt=180&ded=In%20memory%20of...
try {
  const q = new URLSearchParams(location.search);
  if (q.get("go") === "give" && q.get("fund")) { const f = q.get("fund"), a = parseFloat(q.get("amt")); Object.assign(U, { giveFund: FUNDS.some((x) => x.id === f) ? f : "general", giveAmt: a > 0 && a <= 100000 ? r2(a) : 36, freq: "once", dedication: String(q.get("ded") || "").slice(0, 80) }); }
} catch (e) {}
try { const go = new URLSearchParams(location.search).get("go"); if (go === "coin") { setTimeout(() => A.dropPrimary(), 900); history.replaceState(null, "", location.pathname); } else if (go === "empty") { setTimeout(() => A.openEmpty(), 900); history.replaceState(null, "", location.pathname); } else if (["yahrzeit", "club", "give", "board", "occasions"].includes(go)) { U.page = go; U.stack = [go === "club" ? "give" : go === "give" ? "" : "more"].filter(Boolean); history.replaceState(null, "", location.pathname); } } catch (e) {}
draw();
if (S.bio) { showLock(); A.unlock(); }
initPay().then(() => { pullState(); try { if (API.accounts && !S.auth && new URLSearchParams(location.search).get("signin")) { history.replaceState(null, "", location.pathname); signInSheet(""); } } catch (e) {} }); loadExtras(); loadCandles(); setInterval(tick, 30000); setTimeout(tick, 2000); setTimeout(autoEmpty, 1500); autoCoins();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
